# AMVspace

AMVspace is a modified version of **AMVerge** (https://github.com/AMVerge-team/AMVerge),
originally created by Crptk and maintained by the AMVerge Team.

- Licensed under the **GNU General Public License v3.0** (see LICENSE). This modified version is
  distributed under the same license, and its complete source is in this repository.
- Changes: renamed to AMVspace, new logo, the desktop (Tauri/Rust) layer replaced by a web shim
  (`web/src/shim`) and an online engine (`server/server.py`) that runs on Google Colab and drives the
  AMVerge-CLI (https://github.com/AMVerge-team/AMVerge-CLI, GPL-3.0).
