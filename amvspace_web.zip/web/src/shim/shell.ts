export async function open(url: string) {
  window.open(url, "_blank");
}
export class Command {
  static create() {
    return new Command();
  }
  async execute() {
    return { code: 0, stdout: "", stderr: "" };
  }
}
