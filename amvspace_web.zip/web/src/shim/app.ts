export const getVersion = async () => "2.0.2";
export const getName = async () => "AMVspace";
export const getTauriVersion = async () => "web";
