import { API } from "./core";

const CHUNK = 8 * 1024 * 1024;
const EXPORT_DIR = "/content/amv/exports";

function toast(text: string, done = false) {
  let el = document.getElementById("amv-up");
  if (!el) {
    el = document.createElement("div");
    el.id = "amv-up";
    el.style.cssText =
      "position:fixed;left:12px;right:12px;bottom:14px;z-index:99999;background:#150e22;color:#fff;" +
      "border:1px solid #a855f7;border-radius:12px;padding:10px 14px;font:14px sans-serif;text-align:center";
    document.body.appendChild(el);
  }
  el.textContent = text;
  if (done) setTimeout(() => el && el.remove(), 1500);
}

async function uploadFile(file: File): Promise<string> {
  const uid = Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  const total = Math.max(1, Math.ceil(file.size / CHUNK));
  for (let i = 0; i < total; i++) {
    const blob = file.slice(i * CHUNK, (i + 1) * CHUNK);
    let tries = 0;
    for (;;) {
      try {
        const r = await fetch(`${API}/upload/${uid}/${i}`, { method: "POST", body: blob });
        if (!r.ok) throw new Error("HTTP " + r.status);
        break;
      } catch (e) {
        if (++tries >= 3) throw e;
      }
    }
    toast(`رفع ${file.name}: ${Math.round(((i + 1) / total) * 100)}%`);
  }
  const r = await fetch(`${API}/upload/${uid}/done?name=${encodeURIComponent(file.name)}`, { method: "POST" });
  const j = await r.json();
  return j.path as string;
}

export async function open(options: any = {}): Promise<string | string[] | null> {
  if (options.directory) return EXPORT_DIR;
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.multiple = !!options.multiple;
    const exts = (options.filters ?? []).flatMap((f: any) => (f.extensions ?? []).map((e: string) => "." + e));
    input.accept = ["video/*", "image/*", ...exts].join(",");
    input.style.display = "none";
    input.onchange = async () => {
      const files = Array.from(input.files ?? []);
      input.remove();
      if (!files.length) return resolve(null);
      try {
        const paths: string[] = [];
        for (const f of files) paths.push(await uploadFile(f));
        toast("تم الرفع ✓", true);
        resolve(options.multiple ? paths : paths[0]);
      } catch (e) {
        toast("فشل الرفع: " + e);
        resolve(null);
      }
    };
    input.addEventListener("cancel", () => {
      input.remove();
      resolve(null);
    });
    document.body.appendChild(input);
    input.click();
  });
}

export async function save(options: any = {}): Promise<string | null> {
  const name = String(options.defaultPath ?? "export.mp4").split(/[\\/]/).pop();
  return `${EXPORT_DIR}/${name}`;
}
export async function message(msg: string) {
  alert(msg);
}
export async function ask(msg: string) {
  return confirm(msg);
}
export async function confirm_(msg: string) {
  return confirm(msg);
}
