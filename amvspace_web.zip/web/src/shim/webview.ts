const base: Record<string, any> = { onDragDropEvent: async () => () => {}, label: "main" };
const wv: any = new Proxy(base, { get: (t, k: string) => (k in t ? t[k] : async () => {}) });
export function getCurrentWebview() {
  return wv;
}
export class Webview {
  static getCurrent() {
    return wv;
  }
}
