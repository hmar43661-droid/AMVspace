import { API } from "./core";

export type Event<T> = { event: string; id: number; payload: T };
export type EventCallback<T> = (event: Event<T>) => void;
export type UnlistenFn = () => void;

const handlers = new Map<string, Set<EventCallback<any>>>();
let es: EventSource | null = null;

function ensure() {
  if (es) return;
  es = new EventSource(`${API}/events`);
  es.onmessage = (m) => {
    try {
      const d = JSON.parse(m.data);
      handlers.get(d.event)?.forEach((h) => h({ event: d.event, id: 0, payload: d.payload }));
    } catch {
      /* ignore */
    }
  };
}

export async function listen<T>(event: string, handler: EventCallback<T>): Promise<UnlistenFn> {
  ensure();
  if (!handlers.has(event)) handlers.set(event, new Set());
  handlers.get(event)!.add(handler);
  return () => handlers.get(event)?.delete(handler);
}
export async function once<T>(event: string, handler: EventCallback<T>): Promise<UnlistenFn> {
  const un = await listen<T>(event, (e) => {
    un();
    handler(e);
  });
  return un;
}
export async function emit(_event: string, _payload?: unknown): Promise<void> {}
export const Event: any = undefined;
