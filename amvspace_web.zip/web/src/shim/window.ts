const noop = async () => {};
const base: Record<string, any> = {
  isMaximized: async () => false,
  isFullscreen: async () => false,
  onResized: async () => () => {},
  onMoved: async () => () => {},
  onCloseRequested: async () => () => {},
  onFocusChanged: async () => () => {},
  listen: async () => () => {},
  innerSize: async () => ({ width: window.innerWidth, height: window.innerHeight }),
  label: "main",
};
const win: any = new Proxy(base, { get: (t, k: string) => (k in t ? t[k] : noop) });
export function getCurrentWindow() {
  return win;
}
export const getCurrent = getCurrentWindow;
export class Window {
  constructor() {
    return win;
  }
  static getCurrent() {
    return win;
  }
}
export const currentMonitor = async () => null;
