// AMVspace web shim: Tauri `invoke` -> HTTP call to the online engine (Colab).
export const API = location.origin;

export function convertFileSrc(path: string): string {
  const p = String(path).replace(/\\/g, "/");
  return API + "/f" + (p.startsWith("/") ? "" : "/") + p.split("/").map(encodeURIComponent).join("/");
}
export function downloadUrl(path: string): string {
  const p = String(path).replace(/\\/g, "/");
  return API + "/d" + (p.startsWith("/") ? "" : "/") + p.split("/").map(encodeURIComponent).join("/");
}

function triggerDownloads(paths: unknown) {
  if (!Array.isArray(paths)) return;
  paths.filter((p) => typeof p === "string").forEach((p, i) => {
    setTimeout(() => {
      const a = document.createElement("a");
      a.href = downloadUrl(p as string);
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();
    }, i * 900);
  });
}

export async function invoke<T = unknown>(cmd: string, args: Record<string, unknown> = {}): Promise<T> {
  const r = await fetch(`${API}/rpc/${cmd}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(args ?? {}),
  });
  const text = await r.text();
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!r.ok) throw (data && data.error ? String(data.error) : text || `HTTP ${r.status}`);
  if (cmd === "export_clips") triggerDownloads(data);
  return data as T;
}

export class Channel<T = unknown> {
  onmessage: (m: T) => void = () => {};
}
export function isTauri() {
  return true;
}
