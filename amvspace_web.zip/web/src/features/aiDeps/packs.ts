// optional AI dependency packs.
//
// torch features install on demand into an app-managed env; this is the source of truth for each pack's name, unlocks and size

export type AiPackId = "ml" | "depth" | "upscale" | "scout";
export type AiInstallTarget = AiPackId | "all";

export type TorchVariant = "cuda" | "cpu";

/** the NVIDIA probe result; "unknown" means it couldn't run, so never claim no GPU from it */
export type GpuProbe = "detected" | "absent" | "unknown";

/** mirrors `AiEnvStatus` in src-tauri/src/commands/deps.rs */
export type AiEnvStatus = {
  envReady: boolean;
  uvAvailable: boolean;
  packs: Record<string, boolean>;
  torchVariant: TorchVariant | null;
  torchVersion: string | null;
  envCliVersion: string | null;
  bundledCliVersion: string | null;
  /** true only when a GPU was positively found. false covers both "none" and
   *  "could not tell", so read `gpuProbe` for anything user-facing */
  gpuAvailable: boolean;
  gpuProbe: GpuProbe;
  /** the GPU is Turing or newer, so it can run the CUDA 13 build NVDEC decode
   *  needs. older cards are excluded by CUDA 13, not by us */
  gpuDecodeSupported: boolean;
  /** nelux is installed, so the env is on the GPU-decode profile */
  gpuDecodeInstalled: boolean;
  /** `major.minor` of the env's interpreter, null when there is no env */
  envPythonVersion: string | null;
  /** set when the environment could not be inspected; pack fields are then
   *  unreliable, but the GPU fields are still good */
  statusError: string | null;
  /** Apple Silicon: torch's MPS backend works without a special wheel, so this
   *  holds even when `gpuAvailable`/`torchVariant` (both NVIDIA-only) don't */
  mpsAvailable: boolean;
  /** the AI venv: torch and every pack's packages */
  envSizeBytes: number;
  /** the standalone Python interpreter uv downloaded for that venv */
  pythonSizeBytes: number;
  /** depth / upscale weights in the cli's config folder */
  modelsSizeBytes: number;
  /** Scene Scout's SigLIP 2 checkpoint in the shared Hugging Face cache */
  scoutModelSizeBytes: number;
  /// false in dev builds, where the CLI checkout's venv is used as-is
  managed: boolean;
  /// active folder where AI runtime/models/HF cache live (or will be placed on first install)
  aiRootPath: string;
  /// where AI storage defaults for this install location (e.g. `<install_dir>/ai`)
  aiDefaultPath: string;
  /// non-null when the user chose a custom AI location in Settings > Storage
  aiCustomPath: string | null;
};

export type AiPack = {
  id: AiPackId;
  /// what the user knows the feature as
  label: string;
  /// named in the "You don't have ___ installed" prompt
  dependencyName: string;
  description: string;
  /// rough download for the pack's own wheels, torch excluded (MB)
  extraSizeMb: number;
};

export const AI_PACKS: Record<AiPackId, AiPack> = {
  ml: {
    id: "ml",
    label: "AI scene detection",
    dependencyName: "TransNetV2",
    description:
      "Finds scene cuts with AI. The most accurate option, and fast on an NVIDIA GPU.",
    extraSizeMb: 60,
  },
  depth: {
    id: "depth",
    label: "Depth map",
    dependencyName: "Depth-Anything-V2",
    description: "Creates a depth map of each exported file.",
    extraSizeMb: 60,
  },
  scout: {
    id: "scout",
    label: "Scene Scout",
    dependencyName: "SigLIP 2",
    description:
      "Search your indexed episodes by describing a scene instead of naming a file.",
    // transformers plus the SigLIP 2 weights, which are downloaded on first use
    extraSizeMb: 900,
  },
  upscale: {
    id: "upscale",
    label: "Upscaling",
    dependencyName: "Spandrel / ONNX Runtime",
    description: "Creates a higher resolution copy of each exported file.",
    extraSizeMb: 120,
  },
};

/// packs shown in the UI
export const VISIBLE_PACK_IDS: AiPackId[] = ["ml", "depth", "upscale", "scout"];

const TORCH_SIZE_MB: Record<TorchVariant, number> = {
  cuda: 2700,
  cpu: 250,
};

export function isPackInstalled(status: AiEnvStatus | null, id: AiPackId): boolean {
  return Boolean(status?.packs?.[id]);
}

/// what the user has forced, when they disagree with the probe
export type GpuPreference = "auto" | "cuda" | "cpu";

const GPU_PREFERENCE_KEY = "amverge.gpuPreference";

export function loadGpuPreference(): GpuPreference {
  try {
    const raw = localStorage.getItem(GPU_PREFERENCE_KEY);
    if (raw === "cuda" || raw === "cpu") return raw;
  } catch {
    // private windows and blocked site data both throw here
  }
  return "auto";
}

export function saveGpuPreference(preference: GpuPreference): void {
  try {
    if (preference === "auto") localStorage.removeItem(GPU_PREFERENCE_KEY);
    else localStorage.setItem(GPU_PREFERENCE_KEY, preference);
  } catch {
    // a preference that cannot be stored is not worth failing an install over
  }
}

/// an explicit preference always wins, since the probe can be wrong
export function wantsCudaWheel(
  status: AiEnvStatus | null,
  preference: GpuPreference = "auto",
): boolean {
  if (preference === "cuda") return true;
  if (preference === "cpu") return false;
  return status?.gpuProbe === "detected";
}

/// an env that already has torch keeps it, so later packs never re-download
export function plannedTorchVariant(
  status: AiEnvStatus | null,
  preference: GpuPreference = "auto",
): TorchVariant {
  if (status?.torchVariant) return status.torchVariant;
  return wantsCudaWheel(status, preference) ? "cuda" : "cpu";
}

/// estimated download for installing `id` (or all missing packs) right now, in MB
export function estimateDownloadMb(
  status: AiEnvStatus | null,
  id: AiInstallTarget,
  preference: GpuPreference = "auto",
): number {
  const variant = plannedTorchVariant(status, preference);
  const torchPresent = Boolean(status?.torchVersion) && status?.torchVariant === variant;
  const extraMb =
    id === "all"
      ? VISIBLE_PACK_IDS.filter((packId) => !isPackInstalled(status, packId)).reduce(
          (sum, packId) => sum + AI_PACKS[packId].extraSizeMb,
          0,
        )
      : AI_PACKS[id].extraSizeMb;
  return extraMb + (torchPresent ? 0 : TORCH_SIZE_MB[variant]);
}

export function formatSizeMb(mb: number): string {
  return mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.round(mb)} MB`;
}

export function formatBytes(bytes: number): string {
  if (bytes <= 0) return "0 MB";
  return formatSizeMb(bytes / (1024 * 1024));
}
