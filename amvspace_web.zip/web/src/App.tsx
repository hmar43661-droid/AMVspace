import { lazy, Suspense, useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { Event, listen } from "@tauri-apps/api/event";
import { DEFAULT_GENERAL_SETTINGS } from "./stores/settingsStore";

import AppLayout from "./components/AppLayout";
import HomePage from "./pages/HomePage";
import { AppNotice } from "./components/AppNotice";
import { errorText, showNotice } from "./features/notice/notice";
import type { StartupNotification } from "./components/StartupNotificationModal";
import ImportTerminal from "./components/ImportTerminal";
import BgProgressBar from "./components/BgProgressBar";
import SplashScreen from "./components/SplashScreen";
import { useIntroStore } from "./features/intro/introStore";
import ProcessConflictModal from "./components/ProcessConflictModal";
import { registerProcessAbort } from "./features/processes/singleProcess";
import { clearReencodeQueue, resumeBackgroundCuts } from "./features/import/reencodeQueue";
import { importAbortRef } from "./features/import/importPipeline";

const SettingsModal = lazy(() => import("./components/settings/SettingsModal"));
const QuickMenu = lazy(() => import("./components/QuickMenu"));
const CommandPalette = lazy(() => import("./components/CommandPalette"));
const MenuModal = lazy(() => import("./components/menu/MenuModal"));
const ToolsModal = lazy(() => import("./components/tools/ToolsModal"));
const FlowDatabasePrompt = lazy(() =>
  import("./components/sceneScout/FlowDatabasePrompt").then((m) => ({ default: m.FlowDatabasePrompt }))
);
const EventsPage = lazy(() => import("./pages/EventsPage"));
const HostEventModal = lazy(() => import("./components/events/HostEventModal"));
const BanNoticeModal = lazy(() => import("./components/events/BanNoticeModal"));
const DenialNoticeModal = lazy(() => import("./components/events/DenialNoticeModal"));
const ApprovalNoticeModal = lazy(() => import("./components/events/ApprovalNoticeModal"));
const ScenepacksPage = lazy(() => import("./pages/ScenepacksPage"));
const SceneScoutPage = lazy(() => import("./pages/SceneScoutPage"));
const StartupNotificationModal = lazy(() => import("./components/StartupNotificationModal"));
const V1ImportNotice = lazy(() =>
  import("./components/V1ImportNotice").then((m) => ({ default: m.V1ImportNotice }))
);
const PostExportPassesModal = lazy(() => import("./components/PostExportPassesModal"));
const PassTargetsModal = lazy(() => import("./components/PassTargetsModal"));
const AiInstallModal = lazy(() => import("./components/AiInstallModal"));
const StorageMoveModal = lazy(() => import("./components/StorageMoveModal"));
const GettingStartedTour = lazy(() => import("./components/GettingStartedTour"));

import useDiscordRPC from "./hooks/useDiscordRPC";
import useHEVCSupport from "./hooks/useHEVCSupport";
import useDragDropImport from "./hooks/useDragDropImport";
import useImportExport from "./hooks/useImportExport";
import useStartupUpdateNotification from "./hooks/useStartupUpdateNotification";
import useExtensionSync from "./hooks/useExtensionSync";
import useDiscordAuth from "./hooks/useDiscordAuth";
import useEventsWatch from "./hooks/useEventsWatch";
import useContextMenuCloseOnScroll from "./hooks/useContextMenuCloseOnScroll";

import { rebaseStoragePaths, restoreOpenedEpisodeGrid } from "./features/storage/rebaseStoragePaths";

import { useAiDepsStore } from "./stores/aiDepsStore";
import { useAppStateStore } from "./stores/appStore";
import { useWebpLoadingStore } from "./stores/webpLoadingStore";
import { useSceneScoutStore } from "./stores/sceneScoutStore";
import { useUIStateStore } from "./stores/UIStore";
import { applyThemeSettings, useGeneralSettingsStore, useThemeSettingsStore } from "./stores/settingsStore";
import { useEpisodePanelRuntimeStore } from "./stores/episodeStore";

/** dragging the sidebar divider past this folds the sidebar away, well under its 220px minimum */
const SIDEBAR_COLLAPSE_BELOW_PX = 140;


function App() {
  const loading = useAppStateStore((s) => s.loading);
  const progress = useAppStateStore((s) => s.progress);
  const progressMsg = useAppStateStore((s) => s.progressMsg);
  const batchTotal = useAppStateStore((s) => s.batchTotal);
  const batchDone = useAppStateStore((s) => s.batchDone);
  const batchCurrentFile = useAppStateStore((s) => s.batchCurrentFile);
  const exportMerges = useAppStateStore((s) => s.exportMerges);
  const bgProgress = useAppStateStore((s) => s.bgProgress);
  const bgImportProgress = useAppStateStore((s) => s.bgImportProgress);
  const reencodeProgress = useAppStateStore((s) => s.reencodeProgress);
  const reencodeQueueLength = useAppStateStore((s) => s.reencodeQueue.length);
  // scene scout indexing reports two counted stages, so the card names whichever is running
  const scoutIndexStage = useSceneScoutStore((s) => s.indexing?.stage);
  const scoutAddLabel = scoutIndexStage === "sampling" ? "Sampling frames" : "Embedding scenes";
  const webpLoadDone = useWebpLoadingStore((s) => s.done);
  const webpLoadTotalRaw = useWebpLoadingStore((s) => s.total);
  const webpDismissed = useWebpLoadingStore((s) => s.dismissed);
  // closing the card hides the preview counter for this episode; the queue keeps filling the cache
  const webpLoadTotal = webpDismissed ? 0 : webpLoadTotalRaw;

  const sceneDetectionMethod = useGeneralSettingsStore((s) => s.sceneDetectionMethod);
  const importMethodSetting = useGeneralSettingsStore((s) => s.importMethod);
  const activeOperation = useAppStateStore((s) => s.activeOperation);
  const clearBgProgress = () => {
    useAppStateStore.setState((s) => ({ ...s, bgProgress: null, bgImportProgress: null, reencodeProgress: null }));
    useWebpLoadingStore.getState().reset();
  };
  const setProgress = useAppStateStore((s) => s.setProgress);
  const setProgressMsg = useAppStateStore((s) => s.setProgressMsg);
  const setVideoIsHEVC = useAppStateStore((s) => s.setVideoIsHEVC);
  const setVideoNeedsProxy = useAppStateStore((s) => s.setVideoNeedsProxy);
  const importedVideoPath = useAppStateStore((s) => s.importedVideoPath);
  const importToken = useAppStateStore((s) => s.importToken);


  const windowWrapperRef = useRef<HTMLDivElement | null>(null);
  const userHasHEVC = useAppStateStore((s) => s.userHasHEVC);

  const scenepacksEnabled = useGeneralSettingsStore((s) => s.scenepacksEnabled);
  const sceneScoutEnabled = useGeneralSettingsStore((s) => s.sceneScoutEnabled);

  const [splashVisible, setSplashVisible] = useState(true);

  // background layers stay hidden under the splash and fade in with the app; before paint, or frame one shows them
  useLayoutEffect(() => {
    document.body.style.setProperty("--app-bg-reveal", "0");
  }, []);

  const handleSplashFinished = useCallback(() => {
    setSplashVisible(false);
    useIntroStore.setState({ splashDone: true });
    // the transition on body carries it the rest of the way
    document.body.style.setProperty("--app-bg-reveal", "1");
  }, []);
  const themeSettings = useThemeSettingsStore();


  const sidebarEnabled = useUIStateStore(s => s.sidebarEnabled);
  const setSidebarEnabled = useUIStateStore(s => s.setSidebarEnabled);
  const activePage = useUIStateStore(s => s.activePage);
  const isDragging = useUIStateStore(s => s.isDragging);
  const gettingStartedSeen = useUIStateStore(s => s.gettingStartedSeen);
  const menuOpen = useUIStateStore(s => s.menuOpen);
  const toolsOpen = useUIStateStore(s => s.toolsOpen);

  const handleResetGeneralSettings = async () => {
    try {
      // release the clip files the grid holds open, or windows blocks moving them
      useAppStateStore.getState().setClips([]);
      useAppStateStore.getState().setSelectedClips(new Set());
      await new Promise((resolve) => setTimeout(resolve, 250));

      await invoke<string>("move_storage_to_new_dir", {
        oldDir: useGeneralSettingsStore.getState().episodesPath,
        newDir: null,
      });

      useGeneralSettingsStore.setState(DEFAULT_GENERAL_SETTINGS);
      // no custom path now, so this resolves to app data's storage root
      await rebaseStoragePaths();
    } catch (err) {
      void showNotice("Reset failed", "Failed to reset episode directory: " + errorText(err));
    } finally {
      restoreOpenedEpisodeGrid();
    }
  };

  const handleResetTheme = async() => {
    useThemeSettingsStore.getState().resetThemeSettings();
  }

  const [startupNotification, setStartupNotification] = useState<StartupNotification | null>(null);
  const [showStartupNotification, setShowStartupNotification] = useState(false);
  const startupUpdateNotification = useStartupUpdateNotification();
  useExtensionSync();
  // app-level, since a login can finish after the events modal closed
  useDiscordAuth();
  // polls so a newly approved event badges the sidebar
  useEventsWatch();
  useContextMenuCloseOnScroll();

  const parseThumbnailProgress = (message: string): { done: number; total: number } | null => {
    const match = message.match(/generating thumbnails\.\.\.\s*(\d+)\s*\/\s*(\d+)/i);
    if (!match) return null;

    const done = Number.parseInt(match[1], 10);
    const total = Number.parseInt(match[2], 10);
    if (!Number.isFinite(done) || !Number.isFinite(total) || total <= 0) return null;

    return { done: Math.max(0, done), total };
  };

  const sidebarWidthPx = useUIStateStore(s => s.sidebarWidthPx);
  const setSidebarWidthPx = useUIStateStore(s => s.setSidebarWidthPx);

  function startSidebarResize(e: React.PointerEvent<HTMLDivElement>) {
    const wrapper = windowWrapperRef.current;
    if (!wrapper) return;

    e.preventDefault();
    e.stopPropagation();

    const pointerId = e.pointerId;
    const divider = e.currentTarget;
    divider.setPointerCapture(pointerId);
    document.body.classList.add("is-resizing-sidebar");

    const onPointerMove = (ev: PointerEvent) => {
      const rect = wrapper.getBoundingClientRect();
      const minWidth = 220;
      const maxWidth = Math.max(minWidth, Math.floor(rect.width * 0.6));
      const proposed = Math.round(ev.clientX - rect.left);

      // past the last stop the sidebar folds away live; folded, the divider stays at the left edge to drag back out
      if (proposed < SIDEBAR_COLLAPSE_BELOW_PX) {
        setSidebarEnabled(false);
        return;
      }
      setSidebarEnabled(true);

      setSidebarWidthPx(Math.min(maxWidth, Math.max(minWidth, proposed)));
    };

    const stop = () => {
      document.body.classList.remove("is-resizing-sidebar");
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
    };

    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
  }

  const { updateRPC } = useDiscordRPC();

  const { handleImport, handleBatchImport } = useImportExport({
    onRPCUpdate: updateRPC
  });

  useHEVCSupport();

  useDragDropImport({
    handleImport,
    handleBatchImport
  });

  async function handleAbort() {
    importAbortRef.current = true;
    // emptied first, so the resume stopped below does not start the next episode
    clearReencodeQueue();

    try {
      await Promise.allSettled([
        invoke("abort_detect_scenes"),
        invoke("abort_export"),
        invoke("abort_editor_import"),
        invoke("abort_scout_index"),
        invoke("abort_resume_episode"),
      ]);
    } catch (err) {
      console.error("abort tasks failed:", err);
    }
  }

  // the queue counts between its episodes too, so the mini window does not close and reopen
  const bgActive =
    !!(bgProgress || bgImportProgress || reencodeProgress) || reencodeQueueLength > 0 || webpLoadTotal > 0;
  const [importUiActive, setImportUiActive] = useState(false);
  // null = follow auto behaviour; true/false = user's explicit minimize choice
  const [minimizeOverride, setMinimizeOverride] = useState<boolean | null>(null);

  useEffect(() => {
    void useAiDepsStore.getState().refresh();
    // scene scout's library cuts from earlier sessions go on in the background
    resumeBackgroundCuts();
  }, []);

  const resumingEpisodeId = useAppStateStore((s) => s.resumingEpisodeId);
  const resumingEpisodeName = useEpisodePanelRuntimeStore(
    (s) => s.episodes.find((e) => e.id === resumingEpisodeId)?.displayName
  );

  useEffect(() => {
    if (loading) setImportUiActive(true);
  }, [loading]);
  // a resumed episode brings the CLI mini window back (minimized, since only background work runs)
  useEffect(() => {
    if (resumingEpisodeId) setImportUiActive(true);
  }, [resumingEpisodeId]);
  // a webp episode's previews show in the same window, not the old standalone card
  useEffect(() => {
    if (webpLoadTotal > 0) setImportUiActive(true);
  }, [webpLoadTotal]);

  // previews are the only work left: the window reports them as its own job
  const previewsOnly =
    webpLoadTotal > 0 &&
    !loading &&
    !activeOperation &&
    !resumingEpisodeId &&
    !bgProgress &&
    !bgImportProgress &&
    !reencodeProgress &&
    reencodeQueueLength === 0;
  const openedEpisodeName = useEpisodePanelRuntimeStore(
    (s) => s.episodes.find((e) => e.id === s.openedEpisodeId)?.displayName
  );
  useEffect(() => {
    if (!loading && !bgActive) {
      setImportUiActive(false);
      setMinimizeOverride(null);
    }
  }, [loading, bgActive]);

  // auto-minimize once only background thumbnail, re-encode and preview work remains
  const scoutOperation =
    activeOperation === "scout_add" ||
    activeOperation === "scout_open" ||
    activeOperation === "scout_search" ||
    activeOperation === "scout_thumbnails";
  const autoMinimized = scoutOperation || (!loading && bgActive);
  const overlayMinimized = minimizeOverride !== null ? minimizeOverride : autoMinimized;

  async function handleAbortAndCloseBgProgress() {
    const { bgProgress: bg, bgImportProgress: bgImport, reencodeProgress: reenc, activeOperation: op } =
      useAppStateStore.getState();
    if (bg || bgImport || reenc || op === "scout_add" || op === "scout_open" || op === "scout_search" || op === "scout_thumbnails") {
      await handleAbort();
    }
    const pauseWebps = pauseWebpGeneration();
    clearBgProgress();
    pauseWebps();
  }

  // closing the card pauses webp previews still to make, like closing an import; the episode row resumes them
  function pauseWebpGeneration(): () => void {
    const { total, done } = useWebpLoadingStore.getState();
    const episodeId = useEpisodePanelRuntimeStore.getState().openedEpisodeId;
    return () => {
      if (total > done) useWebpLoadingStore.getState().pause(episodeId);
    };
  }

  // "stop it and continue" in ProcessConflictModal: the same stop the progress window's ✕ does
  useEffect(() => {
    registerProcessAbort(async () => {
      await handleAbort();
      const pauseWebps = pauseWebpGeneration();
      clearBgProgress();
      pauseWebps();
    });
  });

  useEffect(() => {
    applyThemeSettings(themeSettings);
    void invoke("write_app_theme", { themeJson: JSON.stringify(themeSettings) }).catch(() => {});
  }, [themeSettings]);

  // keeps the AI env's cli on the newest compatible patch; delayed so it never competes with startup
  useEffect(() => {
    if (!import.meta.env.PROD) return;
    const timer = window.setTimeout(() => {
      invoke<{ status: string; installed?: string | null; latest?: string | null; message?: string | null }>(
        "update_ai_cli"
      )
        .then((r) => {
          if (r.status === "updated") {
            console.info(`AI CLI updated ${r.installed ?? "?"} -> ${r.latest ?? "?"}`);
          } else if (r.status === "failed") {
            console.warn(`AI CLI update failed, staying on ${r.installed ?? "?"}: ${r.message ?? ""}`);
          }
        })
        .catch((err) => console.warn("AI CLI update check failed", err));
    }, 20_000);
    return () => window.clearTimeout(timer);
  }, []);

  // a page whose feature was switched off in Settings > Features sends the user back to the library
  useEffect(() => {
    if ((activePage === "scenepacks" && !scenepacksEnabled) || (activePage === "sceneScout" && !sceneScoutEnabled)) {
      useUIStateStore.getState().setActivePage("home");
    }
  }, [activePage, scenepacksEnabled, sceneScoutEnabled]);

  useEffect(() => {
    if (!startupUpdateNotification) {
      return;
    }

    setStartupNotification(startupUpdateNotification);
    setShowStartupNotification(true);
  }, [startupUpdateNotification]);

  const handleCloseStartupNotification = (_doNotShowAgain: boolean) => {
    setShowStartupNotification(false);
  };

  useEffect(() => {
    let unlisten: (() => void) | null = null;

    (async () => {
      const stop = await listen<{ percent: number; message: string }>(
        "scene_progress",
        (event: Event<{ percent: number; message: string }>) => {
          setProgress(event.payload.percent);
          setProgressMsg(event.payload.message);

          const parsed = parseThumbnailProgress(event.payload.message);
          if (!parsed) return;

          useAppStateStore.setState((s) => {
            const nextTotal = parsed.total;
            const nextDone = Math.min(
              nextTotal,
              Math.max(s.bgProgress?.done ?? 0, parsed.done)
            );

            if (s.bgProgress?.done === nextDone && s.bgProgress?.total === nextTotal) {
              return s;
            }

            return { ...s, bgProgress: { done: nextDone, total: nextTotal } };
          });
        }
      );

      unlisten = stop;
    })();

    return () => {
      if (unlisten) unlisten();
    };
  }, []);

  useEffect(() => {
    setVideoNeedsProxy(false);
    if (!importedVideoPath) {
      setVideoIsHEVC(null);
      return;
    }

    let cancelled = false;

    setVideoIsHEVC(null);

    (async () => {
      try {
        const codec = await invoke<{ hevc: boolean; browserPlayable: boolean }>("check_video_codec", {
          videoPath: importedVideoPath,
        });

        if (!cancelled) {
          setVideoIsHEVC(codec.hevc);
          setVideoNeedsProxy(!codec.browserPlayable);
        }
      } catch (err) {
        console.error("codec probe failed:", err);

        if (!cancelled) {
          setVideoIsHEVC(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [importedVideoPath, importToken, setVideoIsHEVC, setVideoNeedsProxy]);

  // shared by the bar attached to the mini window and the standalone one
  const clipProgress = reencodeProgress ?? bgProgress;
  const clipLabel =
    activeOperation === "scout_add" ? scoutAddLabel
    : activeOperation === "scout_search" ? "Searching scenes"
    : activeOperation === "scout_thumbnails" ? "Generating thumbnails"
    : reencodeProgress ? "Reencoding"
    : "Processing clips";

  return (
      <AppLayout
      windowWrapperRef={windowWrapperRef}
      isDragging={isDragging}
      loadingOverlay={
        importUiActive ? (
          <ImportTerminal
            progress={previewsOnly ? Math.round((webpLoadDone / webpLoadTotal) * 100) : progress}
            progressMsg={previewsOnly ? `Generating previews ${webpLoadDone}/${webpLoadTotal}` : progressMsg}
            batchTotal={batchTotal}
            batchDone={batchDone}
            batchCurrentFile={batchCurrentFile || ""}
            // abort on previews pauses them, the same as closing the window
            onAbort={previewsOnly ? handleAbortAndCloseBgProgress : handleAbort}
            commandLabel={batchCurrentFile || resumingEpisodeName || (previewsOnly ? openedEpisodeName : undefined) || undefined}
            operation={activeOperation ?? (resumingEpisodeId ? "resume" : previewsOnly ? "previews" : "import")}
            detectionMethod={sceneDetectionMethod}
            importMethod={importMethodSetting}
            exportMerges={exportMerges}
            minimized={overlayMinimized}
            onToggleMinimize={() =>
              setMinimizeOverride((prev) => !(prev ?? autoMinimized))
            }
            onClose={handleAbortAndCloseBgProgress}
            bgBar={
              <BgProgressBar
                clipDone={clipProgress?.done ?? 0}
                clipTotal={clipProgress?.total ?? 0}
                clipLabel={clipLabel}
                importDone={bgImportProgress?.done ?? 0}
                importTotal={bgImportProgress?.total ?? 0}
                webpDone={webpLoadDone}
                // the window's own bar already shows previews when they are the job
                webpTotal={previewsOnly ? 0 : webpLoadTotal}
                onClose={handleAbortAndCloseBgProgress}
                attached
              />
            }
          />
        ) : (bgProgress || bgImportProgress || reencodeProgress || webpLoadTotal > 0) ? (
          <BgProgressBar
            clipDone={clipProgress?.done ?? 0}
            clipTotal={clipProgress?.total ?? 0}
            clipLabel={clipLabel}
            importDone={bgImportProgress?.done ?? 0}
            importTotal={bgImportProgress?.total ?? 0}
            webpDone={webpLoadDone}
            webpTotal={webpLoadTotal}
            onClose={handleAbortAndCloseBgProgress}
          />
        ) : null
      }
      sidebarEnabled={sidebarEnabled}
      navbarProps={{
        userHasHEVC,
        videoIsHEVC: useAppStateStore(s => s.videoIsHEVC),
      }}
      dividerProps={{
        onPointerDown: startSidebarResize,
        sidebarWidthPx,
      }}
    >
      <div className="main-content">
        <div style={{ display: activePage === "home" ? "contents" : "none" }}>
          <HomePage />
        </div>
        <Suspense fallback={null}>
          {activePage === "scenepacks" && scenepacksEnabled && <ScenepacksPage />}
          {activePage === "sceneScout" && sceneScoutEnabled && <SceneScoutPage />}
          {activePage === "events" && <EventsPage />}
        </Suspense>
      </div>
      <AppNotice />
      <ProcessConflictModal />
      <Suspense fallback={null}>
        <QuickMenu />
        <CommandPalette />
        <MenuModal />
        <ToolsModal />
        <FlowDatabasePrompt />
        <HostEventModal />
        <BanNoticeModal />
        <DenialNoticeModal />
        <ApprovalNoticeModal />
        <SettingsModal
          onGeneralSettingsReset={handleResetGeneralSettings}
          onThemeReset={handleResetTheme}
        />
        {showStartupNotification && startupNotification ? (
          <StartupNotificationModal
            notification={startupNotification}
            onClose={handleCloseStartupNotification}
          />
        ) : null}
        <PostExportPassesModal />
        <PassTargetsModal />
        <AiInstallModal />
        <StorageMoveModal />
        {splashVisible ? null : <V1ImportNotice />}
        {!splashVisible && !showStartupNotification && !gettingStartedSeen && !menuOpen && !toolsOpen && (
          <GettingStartedTour />
        )}
      </Suspense>
      {splashVisible ? <SplashScreen onFinished={handleSplashFinished} /> : null}
      </AppLayout>
  );
}

export default App;
