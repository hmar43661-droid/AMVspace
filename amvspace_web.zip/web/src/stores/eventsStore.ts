import { create } from "zustand";
import { persist } from "zustand/middleware";
import { open } from "@tauri-apps/plugin-shell";

import {
  acknowledgeEventApproval,
  acknowledgeBanNotice,
  acknowledgeEventDenial,
  beginDiscordLogin,
  cancelDiscordLogin,
  deleteEventRequest,
  discordLogout,
  fetchEvents,
  fetchHyettaEvents,
  fetchMyEvents,
  readDiscordSession,
  submitEventRequest,
  updateEventRequest,
} from "../utils/eventsApi";
import type {
  CommunityEvent,
  HostBan,
  DiscordProfile,
  EventSubmission,
} from "../components/events/types";
import { hasEnded } from "../components/events/format";
import { listedHyettaEvents } from "../components/events/hyetta";

// not persisted: events are server state and the Discord session lives in the OS credential store
/** Which slice of the catalogue the grid is showing */
export type EventFilter = "all" | "mine" | "hc" | "ec";

export type EventSort = "date-asc" | "date-desc" | "prize-desc" | "prize-asc";

export type EventsState = {
  active: CommunityEvent[];
  past: CommunityEvent[];
  mine: CommunityEvent[];
  /** events listed on hyetta, past ones included; loaded apart so either source can fail alone */
  hyetta: CommunityEvent[];
  loading: boolean;
  error: string | null;

  search: string;
  filter: EventFilter;
  sort: EventSort;

  /** event shown in the detail view, by id */
  detailId: string | null;
  hostFormOpen: boolean;
  /** Set while the host form is editing one of the user's own events */
  editingId: string | null;

  profile: DiscordProfile | null;
  loginPending: boolean;
  loginError: string | null;

  /** approved events already shown, so the badge counts new ones; persisted */
  seenEventIds: string[];
  /** false until the first successful load establishes the baseline */
  hasSeededSeenEvents: boolean;
  /** ids flagged NEW! this visit; not persisted, so the flags clear next visit */
  highlightedEventIds: string[];
  /** when the host may submit again, from server seconds plus the local clock, so skew can't break it */
  submitCooldownUntil: number | null;
  /** set while the account is banned from hosting; carries reason and expiry */
  ban: HostBan | null;
  /** true while the user is reading why they were banned */
  banNoticeOpen: boolean;
  /** hides the sidebar's new-event badge; persisted */
  notificationsMuted: boolean;
};

export type EventsStore = EventsState & {
  setSearch: (search: string) => void;
  setFilter: (filter: EventFilter) => void;
  setSort: (sort: EventSort) => void;
  loadEvents: () => Promise<void>;
  refreshEvents: () => Promise<void>;
  loadHyetta: () => Promise<void>;
  loadMine: () => Promise<void>;
  refreshSession: () => Promise<void>;
  startLogin: () => Promise<void>;
  finishLogin: (profile: DiscordProfile | null, message: string | null) => void;
  logout: () => Promise<void>;
  openDetail: (id: string) => void;
  closeDetail: () => void;
  openHostForm: (editingId?: string | null) => void;
  closeHostForm: () => void;
  saveEvent: (submission: EventSubmission) => Promise<{ ok: boolean; message: string | null }>;
  deleteEvent: (eventId: string) => Promise<{ ok: boolean; message: string | null }>;
  dismissDenialNotice: () => void;
  openBanNotice: () => void;
  dismissBanNotice: () => void;
  dismissApprovalNotice: () => void;
  markEventsSeen: () => void;
  /** drops this visit's NEW! flags when leaving Events */
  clearEventHighlights: () => void;
  /** starts the countdown from a server-supplied number of seconds */
  startSubmitCooldown: (seconds: number) => void;
  setNotificationsMuted: (muted: boolean) => void;
};

/** plenty for any realistic catalogue, and bounds the persisted payload */
const SEEN_ID_LIMIT = 500;

/** background polls hit a third party's api from every install, so they stay rarer than our own */
const HYETTA_POLL_MS = 5 * 60_000;
let lastHyettaLoad = 0;

/** approved, unfinished events a badge may count, excluding the host's own */
function visibleEventIds(state: Pick<EventsState, "active" | "hyetta" | "mine">): string[] {
  // public copies carry no host id, so the host's own are recognised from their own list
  const own = new Set(state.mine.map((event) => event.id));
  return [...state.active, ...state.hyetta.filter((event) => !hasEnded(event))]
    .map((event) => event.id)
    .filter((id) => !own.has(id));
}

/** ids that are visible but not yet seen. drives the sidebar badge */
export function selectNewEventIds(state: EventsState): string[] {
  const seen = new Set(state.seenEventIds);
  return visibleEventIds(state).filter((id) => !seen.has(id));
}

const INITIAL_STATE: EventsState = {
  active: [],
  past: [],
  mine: [],
  hyetta: [],
  loading: false,
  error: null,
  search: "",
  filter: "all",
  sort: "date-asc",
  detailId: null,
  hostFormOpen: false,
  editingId: null,
  profile: null,
  loginPending: false,
  loginError: null,
  seenEventIds: [],
  hasSeededSeenEvents: false,
  highlightedEventIds: [],
  submitCooldownUntil: null,
  ban: null,
  banNoticeOpen: false,
  notificationsMuted: false,
};

export const useEventsStore = create<EventsStore>()(
  persist(
    (set, get) => ({
  ...INITIAL_STATE,

  setSearch: (search) => set({ search }),
  setFilter: (filter) => set({ filter }),
  setSort: (sort) => set({ sort }),
  setNotificationsMuted: (notificationsMuted) => set({ notificationsMuted }),

  /** background refresh: same fetch, but never touches `loading` or `error`,
   *  so a poll cannot flash the grid or surface a transient network blip */
  refreshEvents: async () => {
    try {
      const hyettaDue = Date.now() - lastHyettaLoad >= HYETTA_POLL_MS;
      const [active, past] = await Promise.all([
        fetchEvents("active"),
        fetchEvents("past"),
        hyettaDue ? get().loadHyetta() : undefined,
      ]);
      if (!active.ok || !past.ok) return;

      set({ active: active.events, past: past.events });

      if (!get().hasSeededSeenEvents) {
        set({
          hasSeededSeenEvents: true,
          seenEventIds: visibleEventIds(get()).slice(-SEEN_ID_LIMIT),
        });
      }

      if (get().profile) await get().loadMine();
    } catch {
      // a failed poll just means the next one tries again
    }
  },

  loadEvents: async () => {
    set({ loading: true, error: null });

    try {
      const [active, past] = await Promise.all([
        fetchEvents("active"),
        fetchEvents("past"),
        get().loadHyetta(),
        get().profile ? get().loadMine() : undefined,
      ]);

      if (!active.ok || !past.ok) {
        set({
          loading: false,
          error: active.message || past.message || "Could not load events.",
        });
        return;
      }

      set({ active: active.events, past: past.events, loading: false, error: null });

      // a fresh install's first load is the baseline, or the whole catalogue would badge as new
      if (!get().hasSeededSeenEvents) {
        set({
          hasSeededSeenEvents: true,
          seenEventIds: visibleEventIds(get()).slice(-SEEN_ID_LIMIT),
        });
      }
    } catch (err) {
      set({ loading: false, error: err instanceof Error ? err.message : String(err) });
    }
  },

  loadHyetta: async () => {
    lastHyettaLoad = Date.now();

    try {
      set({ hyetta: listedHyettaEvents(await fetchHyettaEvents()) });
    } catch {
      // keeps the last list: hyetta being down must not touch amverge's own events
    }
  },

  loadMine: async () => {
    if (!get().profile) {
      set({ mine: [] });
      return;
    }

    try {
      const result = await fetchMyEvents();
      set({
        mine: result.ok ? result.events : [],
        submitCooldownUntil:
          result.ok && result.submitCooldownSeconds
            ? Date.now() + result.submitCooldownSeconds * 1000
            : null,
        ban: result.ban ?? null,
      });
    } catch {
      // the host's own list is extra; failing it must not blank the public grid
      set({ mine: [] });
    }
  },

  refreshSession: async () => {
    try {
      const profile = await readDiscordSession();
      set({ profile });
      if (profile) await get().loadMine();
    } catch {
      set({ profile: null });
    }
  },

  startLogin: async () => {
    set({ loginPending: true, loginError: null });

    try {
      const url = await beginDiscordLogin();
      await open(url);
    } catch (err) {
      set({
        loginPending: false,
        loginError: err instanceof Error ? err.message : String(err),
      });
    }
  },

  finishLogin: (profile, message) => {
    set({ loginPending: false, profile, loginError: profile ? null : message });
    if (profile) void get().loadMine();
  },

  logout: async () => {
    set({ submitCooldownUntil: null, ban: null, banNoticeOpen: false });
    await discordLogout();
    set({ profile: null, mine: [], editingId: null, hostFormOpen: false });
  },

  openDetail: (detailId) => set({ detailId }),
  closeDetail: () => set({ detailId: null }),

  openHostForm: (editingId = null) => set({ hostFormOpen: true, editingId }),

  startSubmitCooldown: (seconds) =>
    set({ submitCooldownUntil: seconds > 0 ? Date.now() + seconds * 1000 : null }),
  closeHostForm: () => {
    if (useEventsStore.getState().loginPending) {
      void cancelDiscordLogin().catch(() => {});
    }
    set({ hostFormOpen: false, editingId: null, loginPending: false });
  },

  saveEvent: async (submission) => {
    const editingId = get().editingId;

    try {
      const result = editingId
        ? await updateEventRequest(editingId, submission)
        : await submitEventRequest(submission);

      if (!result.ok) {
        // a cooldown refusal says how long is left, so the button greys at once
        if (!editingId && result.retryAfterSeconds) {
          get().startSubmitCooldown(result.retryAfterSeconds);
        }
        void get().loadEvents();
        void get().loadMine();
        return { ok: false, message: result.message };
      }

      await get().loadMine();
      return { ok: true, message: null };
    } catch (err) {
      return { ok: false, message: err instanceof Error ? err.message : String(err) };
    }
  },

  deleteEvent: async (eventId) => {
    try {
      const result = await deleteEventRequest(eventId);

      // refetch either way: success drops the row, failure means the list was stale
      await Promise.all([get().loadEvents(), get().loadMine()]);

      if (!result.ok) return { ok: false, message: result.message };

      // the detail view may be showing the event that just went away
      if (get().detailId === eventId) set({ detailId: null });
      return { ok: true, message: null };
    } catch (err) {
      return { ok: false, message: err instanceof Error ? err.message : String(err) };
    }
  },

  /** reopens the ban reason on demand, after the one-shot notice was dismissed */
  openBanNotice: () => set({ banNoticeOpen: true }),

  /** closes the ban notice and marks it seen, locally first so it can't reappear mid-request */
  dismissBanNotice: () => {
    const ban = get().ban;
    set({
      banNoticeOpen: false,
      ban: ban ? { ...ban, noticeSeen: true } : null,
    });
    if (ban && !ban.noticeSeen) void acknowledgeBanNotice().catch(() => {});
  },

  /** marks unseen denials seen, locally first so the notice can't reappear mid-request */
  dismissDenialNotice: () => {
    const unseen = get().mine.filter(
      (event) => event.status === "denied" && event.denialSeen === false
    );
    if (unseen.length === 0) return;

    set({
      mine: get().mine.map((event) =>
        event.status === "denied" ? { ...event, denialSeen: true } : event
      ),
    });

    for (const event of unseen) {
      void acknowledgeEventDenial(event.id).catch(() => {});
    }
  },

  /** the approval counterpart, same one-shot behaviour as the denial notice */
  dismissApprovalNotice: () => {
    const unseen = get().mine.filter(
      (event) => event.status === "approved" && event.approvalSeen === false
    );
    if (unseen.length === 0) return;

    set({
      mine: get().mine.map((event) =>
        event.status === "approved" ? { ...event, approvalSeen: true } : event
      ),
    });

    for (const event of unseen) {
      void acknowledgeEventApproval(event.id).catch(() => {});
    }
  },

  /** on opening Events: new ones are highlighted this visit and recorded as seen, clearing the badge */
  markEventsSeen: () => {
    const visible = visibleEventIds(get());
    const seen = new Set(get().seenEventIds);
    const fresh = visible.filter((id) => !seen.has(id));

    if (fresh.length === 0) return;

    for (const id of visible) seen.add(id);

    set({
      // reruns on every list refresh, so earlier flags this visit are kept
      highlightedEventIds: [...get().highlightedEventIds, ...fresh],
      // bounded; ids that fall off are old events no longer listed
      seenEventIds: Array.from(seen).slice(-SEEN_ID_LIMIT),
    });
  },

  clearEventHighlights: () => set({ highlightedEventIds: [] }),
    }),
    {
      name: "amverge.events.v1",
      // only the seen set persists; lists are server state, highlights last one visit
      partialize: (state) => ({
        seenEventIds: state.seenEventIds,
        hasSeededSeenEvents: state.hasSeededSeenEvents,
        // an absolute deadline, so the button is grey on first paint; loadMine still overwrites it
        submitCooldownUntil: state.submitCooldownUntil,
        notificationsMuted: state.notificationsMuted,
      }),
    }
  )
);
