import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ClipItem } from "../types/domain";

type SetterValue<T> = T | ((prev: T) => T);

function resolveSetterValue<T>(prev: T, value: SetterValue<T>): T {
  return typeof value === "function" ? (value as (current: T) => T)(prev) : value;
}

export type AppState = {
  focusedClip: string | null;
  focusedClipId: string | null;
  selectedClips: Set<string>;
  clips: ClipItem[];
  videoIsHEVC: boolean | null;
  /** the episode's codec is one no webview decodes (xvid, mpeg-2...), so previews always go through a proxy */
  videoNeedsProxy: boolean;
  userHasHEVC: boolean;
  importedVideoPath: string | null;
  
  loading: boolean;
  // the cli operation the loading overlay shows; null when idle
  activeOperation: "import" | "export" | "scout_add" | "scout_open" | "scout_search" | "scout_thumbnails" | null;
  progress: number;
  progressMsg: string;
  bgProgress: { done: number; total: number } | null;
  bgImportProgress: { done: number; total: number } | null;
  // the running re-encode's progress (features/import/reencodeQueue.ts)
  reencodeProgress: { done: number; total: number } | null;
  // episodes a live import is still streaming into
  liveImportEpisodeIds: string[];
  // episodes waiting for their clips to be finished, the running one included, in order
  reencodeQueue: string[];
  // the episode whose clips are being finished right now (one at a time)
  resumingEpisodeId: string | null;
  importToken: string;
  batchTotal: number;
  batchDone: number;
  batchCurrentFile: string | null;
  /** whether the running export merges, for the terminal's command line */
  exportMerges: boolean;
  showLoaderCancel: boolean;
  loaderCancelLabel: string;
};

export type AppStateStore = AppState & {
  setFocusedClip: (clip: SetterValue<string | null>) => void;
  setFocusedClipId: (clipId: SetterValue<string | null>) => void;
  setSelectedClips: (clips: SetterValue<Set<string>>) => void;
  setClips: (clips: SetterValue<ClipItem[]>) => void;
  setVideoIsHEVC: (isHEVC: SetterValue<boolean | null>) => void;
  setVideoNeedsProxy: (needsProxy: boolean) => void;
  setUserHasHEVC: (hasHEVC: boolean) => void;
  setImportedVideoPath: (path: SetterValue<string | null>) => void;
  
  setLoading: (loading: boolean) => void;
  setActiveOperation: (op: "import" | "export" | "scout_add" | "scout_open" | "scout_search" | "scout_thumbnails" | null) => void;
  setProgress: (progress: number) => void;
  setProgressMsg: (msg: string) => void;
  setBgImportProgress: (progress: SetterValue<{ done: number; total: number } | null>) => void;
  setReencodeProgress: (progress: SetterValue<{ done: number; total: number } | null>) => void;
  setImportToken: (token: SetterValue<string>) => void;
  setBatchTotal: (total: SetterValue<number>) => void;
  setBatchDone: (done: SetterValue<number>) => void;
  setBatchCurrentFile: (file: SetterValue<string | null>) => void;
  setShowLoaderCancel: (show: boolean) => void;
  setLoaderCancelLabel: (label: string) => void;
};

export const DEFAULT_APP_STATE: AppState = {
  focusedClip: null,
  focusedClipId: null,
  selectedClips: new Set(),
  clips: [],
  videoIsHEVC: null,
  videoNeedsProxy: false,
  userHasHEVC: false,
  importedVideoPath: null,
  
  loading: false,
  activeOperation: null,
  progress: 0,
  progressMsg: "",
  bgProgress: null,
  bgImportProgress: null,
  reencodeProgress: null,
  liveImportEpisodeIds: [],
  reencodeQueue: [],
  resumingEpisodeId: null,
  importToken: "",
  batchTotal: 0,
  batchDone: 0,
  batchCurrentFile: null,
  exportMerges: false,
  showLoaderCancel: false,
  loaderCancelLabel: "Cancel",
};

export const useAppStateStore = create<AppStateStore>()((set) => ({
  ...DEFAULT_APP_STATE,

  setFocusedClip: (val) => set((s) => ({ focusedClip: resolveSetterValue(s.focusedClip, val) })),
  setFocusedClipId: (val) => set((s) => ({ focusedClipId: resolveSetterValue(s.focusedClipId, val) })),
  setSelectedClips: (val) => set((s) => ({ selectedClips: resolveSetterValue(s.selectedClips, val) })),
  setClips: (val) => set((s) => ({ clips: resolveSetterValue(s.clips, val) })),
  setVideoIsHEVC: (val) => set((s) => ({ videoIsHEVC: resolveSetterValue(s.videoIsHEVC, val) })),
  setVideoNeedsProxy: (videoNeedsProxy) => set({ videoNeedsProxy }),
  setUserHasHEVC: (hasHEVC) => set({ userHasHEVC: hasHEVC }),
  setImportedVideoPath: (val) => set((s) => ({ importedVideoPath: resolveSetterValue(s.importedVideoPath, val) })),
  
  setLoading: (loading) => set({ loading }),
  setActiveOperation: (op) => set({ activeOperation: op }),
  setProgress: (progress) => set({ progress }),
  setProgressMsg: (progressMsg) => set({ progressMsg }),
  setBgImportProgress: (val) => set((s) => ({ bgImportProgress: resolveSetterValue(s.bgImportProgress, val) })),
  setReencodeProgress: (val) => set((s) => ({ reencodeProgress: resolveSetterValue(s.reencodeProgress, val) })),
  setImportToken: (val) => set((s) => ({ importToken: resolveSetterValue(s.importToken, val) })),
  setBatchTotal: (val) => set((s) => ({ batchTotal: resolveSetterValue(s.batchTotal, val) })),
  setBatchDone: (val) => set((s) => ({ batchDone: resolveSetterValue(s.batchDone, val) })),
  setBatchCurrentFile: (val) => set((s) => ({ batchCurrentFile: resolveSetterValue(s.batchCurrentFile, val) })),
  setShowLoaderCancel: (showLoaderCancel) => set({ showLoaderCancel }),
  setLoaderCancelLabel: (loaderCancelLabel) => set({ loaderCancelLabel }),
}));

type AppPersistedState = {
  exportDir: string | null;
  dismissedNotificationIds: string[];
};

type AppPersistedStore = AppPersistedState & {
  setExportDir: (dir: SetterValue<string | null>) => void;
  dismissNotificationId: (notificationId: string) => void;
};

export const useAppPersistedStore = create<AppPersistedStore>()(
  persist(
    (set) => ({
      exportDir: null,
      dismissedNotificationIds: [],
      setExportDir: (val) => set((s) => ({ exportDir: resolveSetterValue(s.exportDir, val) })),
      dismissNotificationId: (notificationId) =>
        set((s) => {
          const id = notificationId.trim();
          if (!id || s.dismissedNotificationIds.includes(id)) {
            return s;
          }
          return { dismissedNotificationIds: [...s.dismissedNotificationIds, id] };
        }),
    }),
    {
      name: "amverge_export_dir_v1",
    }
  )
);