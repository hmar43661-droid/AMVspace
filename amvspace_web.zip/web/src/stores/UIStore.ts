import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ClipPage, Page } from "../components/sidebar/types";

export type UIState = {
    cols: number;
    gridPreview: boolean;
    sidebarEnabled: boolean;
    sidebarWidthPx: number;
    dividerOffsetPx: number;
    isDragging: boolean;
    activePage: Page;
    /** last clip page visited. the Events page has no panel of its own, so the
     *  sidebar keeps showing whichever panel was up before the user left */
    panelPage: ClipPage;
    settingsTab: string;
    settingsOpen: boolean;
    menuOpen: boolean;
    /** the Tools modal: one clip in, one upscale or depth map out */
    toolsOpen: boolean;
    quickMenuOpen: boolean;
    commandPaletteOpen: boolean;
    previewCollapsed: boolean;
    /** grid's share of the split, in percent. the import row reads it too, to
     *  keep the preview toggle above the grid's right edge */
    previewSplitPct: number;
    pinned: boolean;
    /** the preview pane's How to use guide, open or folded */
    howToUseExpanded: boolean;
    /** where each episode's clip grid was left, by episode id; only non-zero offsets are kept */
    episodeScrollTops: Record<string, number>;
    /** height of scene scout flow's input clip area, set by dragging the bar under it */
    flowPlayerHeightPx: number;
    /** the scene scout walkthrough was finished or skipped, so it no longer opens on its own */
    sceneScoutTourSeen: boolean;
    /** the app-wide Getting Started tour was finished or skipped */
    gettingStartedSeen: boolean;
    /** transient target when jumping from Scene Scout ("Show in episode") to a Home clip */
    pendingEpisodeJump: { episodeId: string; clipId: string } | null;
};

export type UIStateStore = UIState & {
    setCols: (cols: number | ((prev: number) => number)) => void;
    incrementCols: () => void;
    decrementCols: () => void;
    setGridPreview: (
        previewEnabled: boolean | ((prev: boolean) => boolean)
    ) => void;
    setSidebarEnabled: (
        sideBarEnabled: boolean | ((prev: boolean) => boolean)
    ) => void;
    setSidebarWidthPx: (sideBarWidthPx: number) => void;
    setDividerOffsetPx: (
        dividerOffsetPx: number | ((prev: number) => number)
    ) => void;
    setIsDragging: (isDragging: boolean) => void;
    setActivePage: (activePage: Page | ((prev: Page) => Page)) => void;
    setSettingsTab: (tab: string) => void;
    openSettings: (tab?: string) => void;
    closeSettings: () => void;
    openMenu: () => void;
    closeMenu: () => void;
    openTools: () => void;
    closeTools: () => void;
    setQuickMenuOpen: (open: boolean) => void;
    setCommandPaletteOpen: (open: boolean) => void;
    setPreviewCollapsed: (collapsed: boolean) => void;
    setPreviewSplitPct: (pct: number) => void;
    togglePinned: () => void;
    setHowToUseExpanded: (expanded: boolean) => void;
    setEpisodeScrollTops: (scrollTops: Record<string, number>) => void;
    setFlowPlayerHeightPx: (px: number) => void;
    setSceneScoutTourSeen: (seen: boolean) => void;
    setGettingStartedSeen: (seen: boolean) => void;
    setPendingEpisodeJump: (jump: { episodeId: string; clipId: string } | null) => void;
};

/** true while a full-screen modal covers the app, so previews can stand down */
export const selectOverlayOpen = (state: UIState) =>
    state.settingsOpen || state.menuOpen || state.toolsOpen;

export const DEFAULT_UI_STATE: UIState = {
    cols: 6,
    gridPreview: false,
    sidebarEnabled: true,
    sidebarWidthPx: 280,
    dividerOffsetPx: 0,
    isDragging: false,
    activePage: "home",
    panelPage: "home",
    settingsTab: "general",
    settingsOpen: false,
    menuOpen: false,
    toolsOpen: false,
    quickMenuOpen: false,
    commandPaletteOpen: false,
    previewCollapsed: false,
    previewSplitPct: 65,
    pinned: false,
    howToUseExpanded: true,
    episodeScrollTops: {},
    flowPlayerHeightPx: 300,
    sceneScoutTourSeen: false,
    gettingStartedSeen: false,
    pendingEpisodeJump: null,
};

export const useUIStateStore = create<UIStateStore>()(
    persist(
        (set) => ({
            ...DEFAULT_UI_STATE,

            setCols: (cols) =>
                set((state) => ({
                    cols: typeof cols === "function" ? cols(state.cols) : cols,
                })),

            incrementCols: () =>
                set((state) => ({ cols: Math.min(12, state.cols + 1) })),

            decrementCols: () =>
                set((state) => ({ cols: Math.max(1, state.cols - 1) })),

            setGridPreview: (previewEnabled) =>
                set((state) => ({
                    gridPreview:
                        typeof previewEnabled === "function"
                            ? previewEnabled(state.gridPreview)
                            : previewEnabled,
                })),
            setSidebarEnabled: (sidebarEnabled) =>
                set((state) => ({
                    sidebarEnabled:
                        typeof sidebarEnabled === "function"
                            ? sidebarEnabled(state.sidebarEnabled)
                            : sidebarEnabled,
                })),
            setSidebarWidthPx: (sidebarWidthPx) => set({ sidebarWidthPx }),
            setDividerOffsetPx: (dividerOffsetPx) =>
                set((state) => ({
                    dividerOffsetPx:
                        typeof dividerOffsetPx === "function"
                            ? dividerOffsetPx(state.dividerOffsetPx)
                            : dividerOffsetPx,
                })),
            setIsDragging: (isDragging) => set({ isDragging }),
            setActivePage: (activePage) =>
                set((state) => {
                    const next =
                        typeof activePage === "function" ? activePage(state.activePage) : activePage;
                    // Events borrows the open panel, so it doesn't overwrite the remembered one
                    return next === "events"
                        ? { activePage: next }
                        : { activePage: next, panelPage: next };
                }),
            setSettingsTab: (settingsTab) => set({ settingsTab }),
            openSettings: (tab) =>
                set(tab
                    ? { settingsOpen: true, settingsTab: tab, quickMenuOpen: false, commandPaletteOpen: false }
                    : { settingsOpen: true, quickMenuOpen: false, commandPaletteOpen: false }),
            closeSettings: () => set({ settingsOpen: false }),
            openMenu: () => set({ menuOpen: true, quickMenuOpen: false, commandPaletteOpen: false }),
            closeMenu: () => set({ menuOpen: false }),
            openTools: () =>
                set({ toolsOpen: true, menuOpen: false, settingsOpen: false, quickMenuOpen: false, commandPaletteOpen: false }),
            closeTools: () => set({ toolsOpen: false }),
            setQuickMenuOpen: (quickMenuOpen) => set({ quickMenuOpen }),
            setCommandPaletteOpen: (commandPaletteOpen) => set({ commandPaletteOpen }),
            setPreviewCollapsed: (previewCollapsed) => set({ previewCollapsed }),
            setPreviewSplitPct: (previewSplitPct) => set({ previewSplitPct }),
            togglePinned: () => set((state) => ({ pinned: !state.pinned })),
            setHowToUseExpanded: (howToUseExpanded) => set({ howToUseExpanded }),
            setEpisodeScrollTops: (episodeScrollTops) => set({ episodeScrollTops }),
            setFlowPlayerHeightPx: (flowPlayerHeightPx) => set({ flowPlayerHeightPx }),
            setSceneScoutTourSeen: (sceneScoutTourSeen) => set({ sceneScoutTourSeen }),
            setGettingStartedSeen: (gettingStartedSeen) => set({ gettingStartedSeen }),
            setPendingEpisodeJump: (pendingEpisodeJump) => set({ pendingEpisodeJump }),
        }),
        {
            name: "amverge.ui.v1",
            partialize: (state) => ({
                // persisted fields (gridPreview isn't: Preview All starts off each launch)
                sidebarWidthPx: state.sidebarWidthPx,
                cols: state.cols,
                sidebarEnabled: state.sidebarEnabled,
                previewCollapsed: state.previewCollapsed,
                previewSplitPct: state.previewSplitPct,
                // persisted; the window state isn't, so Navbar re-applies it
                pinned: state.pinned,
                howToUseExpanded: state.howToUseExpanded,
                episodeScrollTops: state.episodeScrollTops,
                flowPlayerHeightPx: state.flowPlayerHeightPx,
                sceneScoutTourSeen: state.sceneScoutTourSeen,
                gettingStartedSeen: state.gettingStartedSeen,
            }),
        }
    )
);