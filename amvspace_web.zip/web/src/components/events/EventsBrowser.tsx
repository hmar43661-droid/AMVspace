import { useEffect, useMemo, useRef, useState } from "react";
import { askNotice } from "../../features/notice/notice";
import { FaChevronDown } from '../icons/animated';

import EventCard from "./EventCard";
import EventDetail from "./EventDetail";
import DeleteEventModal from "./DeleteEventModal";
import {
  canDelete,
  compareEvents,
  dedupeById,
  hasEnded,
  isLive,
  matchesSearch,
  needsDeleteConfirmation,
} from "./format";
import { useEventsStore } from "../../stores/eventsStore";
import { useUIStateStore } from "../../stores/UIStore";
import type { CommunityEvent } from "./types";

/** event cards stop being readable past four across; the shared `cols` is only clamped here */
export const MAX_EVENT_COLUMNS = 4;

let clearHighlightsTimer: number | undefined;

function Section({
  title,
  events,
  onOpen,
  cols,
  deletable,
  onDelete,
  collapsed,
  onToggle,
  highlighted,
  ownId,
}: {
  title: string;
  events: CommunityEvent[];
  onOpen: (id: string) => void;
  cols: number;
  deletable: (event: CommunityEvent) => boolean;
  onDelete: (event: CommunityEvent) => void;
  collapsed: boolean;
  onToggle: (title: string) => void;
  highlighted: Set<string>;
  ownId: string | undefined;
}) {
  if (events.length === 0) return null;

  // one column count for every section so tiles stay one size; short sections leave columns empty
  const gridStyle = {
    gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
  };

  return (
    <section className="events-section">
      <button
        type="button"
        className="events-section-title"
        onClick={() => onToggle(title)}
        aria-expanded={!collapsed}
      >
        <FaChevronDown
          aria-hidden="true"
          className={`events-section-chevron${collapsed ? " is-collapsed" : ""}`}
        />
        {title} <span className="events-section-count">{events.length}</span>
      </button>

      {!collapsed && (
        <div className="events-grid" style={gridStyle}>
          {events.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              onOpen={onOpen}
              onDelete={deletable(event) ? () => onDelete(event) : undefined}
              isNew={highlighted.has(event.id)}
              isOwn={Boolean(ownId) && event.hostDiscordId === ownId}
            />
          ))}
        </div>
      )}
    </section>
  );
}

/** the Events page's left pane: the grid, or the open event's detail */
export default function EventsBrowser() {
  const active = useEventsStore((s) => s.active);
  const past = useEventsStore((s) => s.past);
  const mine = useEventsStore((s) => s.mine);
  const hyetta = useEventsStore((s) => s.hyetta);
  const loading = useEventsStore((s) => s.loading);
  const error = useEventsStore((s) => s.error);
  const search = useEventsStore((s) => s.search);
  const filter = useEventsStore((s) => s.filter);
  const sort = useEventsStore((s) => s.sort);
  const detailId = useEventsStore((s) => s.detailId);
  const profile = useEventsStore((s) => s.profile);
  // the toolbar can't report a sign-in failure, so it surfaces here
  const loginError = useEventsStore((s) => s.loginError);
  // the clip grid's column count, capped for these wider cards
  const cols = useUIStateStore((s) => Math.min(MAX_EVENT_COLUMNS, Math.max(1, s.cols)));

  const openDetail = useEventsStore((s) => s.openDetail);
  const closeDetail = useEventsStore((s) => s.closeDetail);
  const openHostForm = useEventsStore((s) => s.openHostForm);

  // ctrl+wheel adjusts columns with the clip grid's 40px threshold
  const setStoreCols = useUIStateStore((s) => s.setCols);
  const paneRef = useRef<HTMLDivElement | null>(null);
  const wheelAccumRef = useRef(0);

  useEffect(() => {
    const el = paneRef.current;
    if (!el) return;

    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();

      wheelAccumRef.current += e.deltaY;
      if (Math.abs(wheelAccumRef.current) < 40) return;

      const direction = wheelAccumRef.current > 0 ? 1 : -1;
      wheelAccumRef.current = 0;

      setStoreCols((prev) => Math.max(1, Math.min(MAX_EVENT_COLUMNS, prev + direction)));
    };

    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [setStoreCols]);

  const deleteEvent = useEventsStore((s) => s.deleteEvent);

  // NEW! flags captured on mount: marking seen clears the badge while the flags last the visit
  const markEventsSeen = useEventsStore((s) => s.markEventsSeen);
  const highlightedEventIds = useEventsStore((s) => s.highlightedEventIds);
  const highlighted = useMemo(() => new Set(highlightedEventIds), [highlightedEventIds]);

  const clearEventHighlights = useEventsStore((s) => s.clearEventHighlights);

  useEffect(() => {
    markEventsSeen();
  }, [markEventsSeen, active, hyetta]);

  // deferred so strict mode's instant remount keeps the flags
  useEffect(() => {
    window.clearTimeout(clearHighlightsTimer);
    return () => {
      clearHighlightsTimer = window.setTimeout(clearEventHighlights, 0);
    };
  }, [clearEventHighlights]);

  //
  // collapsed sections by title, not persisted; "Requested events" starts folded
  const [collapsed, setCollapsed] = useState<Set<string>>(() => new Set(["Requested events"]));
  const toggleSection = (title: string) =>
    setCollapsed((previous) => {
      const next = new Set(previous);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });

  // deletion graded by stakes: live asks for a typed phrase, unreviewed a confirm, finished goes at once
  const [pendingDelete, setPendingDelete] = useState<CommunityEvent | null>(null);

  const requestDelete = (event: CommunityEvent) => {
    if (!needsDeleteConfirmation(event)) {
      void deleteEvent(event.id);
      return;
    }

    if (isLive(event)) {
      setPendingDelete(event);
      return;
    }

    void askNotice("Delete event", "Are you sure you want to delete this event?", "Delete").then((ok) => {
      if (ok) void deleteEvent(event.id);
    });
  };

  const confirmDelete = (event: CommunityEvent) => {
    setPendingDelete(null);
    void deleteEvent(event.id);
  };

  const sections = useMemo(() => {
    const ownId = profile?.id;

    /** the filter applies to every section, so it lives in one predicate */
    const passesFilter = (event: CommunityEvent) => {
      if (filter === "mine") return Boolean(ownId) && event.hostDiscordId === ownId;
      if (filter === "hc") return event.eventType === "hour";
      if (filter === "ec") return event.eventType === "contest";
      return true;
    };

    // the public copy of an anonymous event has no host id, so the owner's private copy wins
    const byId = new Map(mine.map((event) => [event.id, event]));
    const withOwnCopy = (list: CommunityEvent[]) =>
      list.map((event) => byId.get(event.id) ?? event);

    const matching = (list: CommunityEvent[]) =>
      dedupeById(withOwnCopy(list))
        .filter((event) => matchesSearch(event, search))
        .filter(passesFilter)
        .sort((a, b) => compareEvents(a, b, sort));

    // pending and denied submissions; approved ones move to the public sections
    const requested = matching(mine).filter((event) => event.status !== "approved");

    // includes your own approved events, or the page looks empty when you host most of it
    const activeSection = matching([...active, ...hyetta]).filter((event) => !hasEnded(event));

    return [
      { title: "Requested events", events: requested },
      { title: "Active & Upcoming", events: activeSection },
      { title: "Past", events: matching([...past, ...hyetta.filter((event) => hasEnded(event))]) },
    ];
  }, [active, past, mine, hyetta, search, filter, sort, profile?.id]);

  const detailEvent = useMemo(() => {
    if (!detailId) return null;
    return [...mine, ...active, ...past, ...hyetta].find((event) => event.id === detailId) ?? null;
  }, [detailId, mine, active, past, hyetta]);

  if (detailEvent) {
    return (
      <div className="events-pane">
        <EventDetail
          event={detailEvent}
          onBack={closeDetail}
          onEdit={
            detailEvent.hostDiscordId === profile?.id ? (id) => openHostForm(id) : undefined
          }
          onDelete={
            canDelete(detailEvent, profile?.id) ? () => requestDelete(detailEvent) : undefined
          }
        />

        <DeleteEventModal
          event={pendingDelete}
          onCancel={() => setPendingDelete(null)}
          onConfirm={confirmDelete}
        />
      </div>
    );
  }

  const total = sections.reduce((sum, section) => sum + section.events.length, 0);

  return (
    <div className="events-pane" ref={paneRef}>
      {error && <p className="events-error">{error}</p>}
      {loginError && <p className="events-error">{loginError}</p>}
      {loading && <p className="events-empty">Loading events...</p>}

      {!loading && total === 0 && (
        <p className="events-empty">
          {search.trim()
            ? `No events match "${search.trim()}".`
            : filter === "mine"
              ? "You are not hosting any events yet."
              : filter === "hc"
                ? "No hour challenges right now."
                : filter === "ec"
                  ? "No long contests right now."
                  : "Nothing running right now. Host the first one."}
        </p>
      )}

      {!loading &&
        sections.map((section) => (
          <Section
            key={section.title}
            title={section.title}
            events={section.events}
            onOpen={openDetail}
            cols={cols}
            deletable={(event) => canDelete(event, profile?.id)}
            onDelete={requestDelete}
            collapsed={collapsed.has(section.title)}
            onToggle={toggleSection}
            highlighted={highlighted}
            ownId={profile?.id}
          />
        ))}

      <DeleteEventModal
        event={pendingDelete}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
