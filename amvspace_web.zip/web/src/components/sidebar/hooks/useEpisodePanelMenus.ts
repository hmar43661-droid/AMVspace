// menu and modal state hook for the Episode Panel. owns context menus, text modals, confirm modals, and close behavior
import { useEffect, useRef, useState } from "react";
import { useContextMenuStore } from "../../../stores/contextMenuStore";
import { useEscapeToClose } from "../../common/useEscapeToClose";
import type React from "react";
import type {
  ConfirmModalState,
  EpisodeContextMenuState,
  EpisodePanelProps,
  FolderContextMenuState,
  PanelContextMenuState,
  TextModalState,
} from "../types";

type UseEpisodePanelMenusArgs = {
  episodes: EpisodePanelProps["episodes"];
  episodeFolders: EpisodePanelProps["episodeFolders"];
  multiSelectedIds: Set<string>;
  setMultiSelectedIds: React.Dispatch<React.SetStateAction<Set<string>>>;
  clearClickGesture: () => void;

  onSelectEpisode: (episodeId: string) => void;
  onSelectFolder: (folderId: string | null) => void;
  onCreateFolder: (name: string, parentFolderId: string | null) => void;
  onRenameEpisode: (episodeId: string, newName: string) => void;
  onRenameFolder: (folderId: string, newName: string) => void;
};

export default function useEpisodePanelMenus({
  episodes,
  episodeFolders,
  multiSelectedIds,
  setMultiSelectedIds,
  clearClickGesture,
  onSelectEpisode,
  onSelectFolder,
  onCreateFolder,
  onRenameEpisode,
  onRenameFolder,
}: UseEpisodePanelMenusArgs) {
  const claimMenu = useContextMenuStore((s) => s.openContextMenu);
  const activeMenu = useContextMenuStore((s) => s.activeMenu);

  const [contextMenu, setContextMenu] = useState<EpisodeContextMenuState | null>(null);
  const [folderContextMenu, setFolderContextMenu] = useState<FolderContextMenuState | null>(null);
  const [panelContextMenu, setPanelContextMenu] = useState<PanelContextMenuState | null>(null);
  const [textModal, setTextModal] = useState<TextModalState | null>(null);
  const [confirmModal, setConfirmModal] = useState<ConfirmModalState | null>(null);
  const [newFolderModal, setNewFolderModal] = useState<{
    parentFolderId: string | null;
  } | null>(null);
  const [newFolderName, setNewFolderName] = useState("");
  const [newFolderParentId, setNewFolderParentId] = useState<string | null>(null);

  const textModalInputRef = useRef<HTMLInputElement | null>(null);

  const anyContextMenu = Boolean(contextMenu || folderContextMenu || panelContextMenu);
  const closeContextMenus = () => {
    setContextMenu(null);
    setFolderContextMenu(null);
    setPanelContextMenu(null);
  };

  useEffect(() => {
    if (!anyContextMenu) return;
    window.addEventListener("click", closeContextMenus);
    window.addEventListener("contextmenu", closeContextMenus);
    return () => {
      window.removeEventListener("click", closeContextMenus);
      window.removeEventListener("contextmenu", closeContextMenus);
    };
  }, [anyContextMenu]);

  // the modals register their own Escape in EpisodePanelModals
  useEscapeToClose(closeContextMenus, anyContextMenu);

  useEffect(() => {
    if (!textModal) return;

    window.setTimeout(() => {
      textModalInputRef.current?.focus();
      textModalInputRef.current?.select();
    }, 0);
  }, [textModal]);

  // another menu took the slot, so whatever this panel had open is stale
  useEffect(() => {
    if (activeMenu === "episode-panel-item" || activeMenu === "episode-panel-empty") return;
    setContextMenu(null);
    setFolderContextMenu(null);
    setPanelContextMenu(null);
  }, [activeMenu]);

  const openContextMenu = (episodeId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    clearClickGesture();

    setFolderContextMenu(null);
    setPanelContextMenu(null);

    if (multiSelectedIds.size > 0 && !multiSelectedIds.has(episodeId)) {
      setMultiSelectedIds(new Set());
    }

    onSelectEpisode(episodeId);

    claimMenu("episode-panel-item");
    setContextMenu({
      episodeId,
      x: e.clientX,
      y: e.clientY,
    });
  };

  const openFolderContextMenu = (folderId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    clearClickGesture();

    setContextMenu(null);
    setPanelContextMenu(null);

    onSelectFolder(folderId);

    claimMenu("episode-panel-item");
    setFolderContextMenu({
      folderId,
      x: e.clientX,
      y: e.clientY,
    });
  };

  const openPanelContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    clearClickGesture();

    setContextMenu(null);
    setFolderContextMenu(null);
    setTextModal(null);
    setConfirmModal(null);

    claimMenu("episode-panel-empty");
    setPanelContextMenu({
      x: e.clientX,
      y: e.clientY,
    });
  };

  const openNewFolderModal = (parentFolderId: string | null) => {
    setPanelContextMenu(null);
    setContextMenu(null);
    setFolderContextMenu(null);

    setNewFolderModal({ parentFolderId });
    setNewFolderName("");
    setNewFolderParentId(parentFolderId);
  };

  const closeNewFolderModal = () => {
    setNewFolderModal(null);
    setNewFolderName("");
    setNewFolderParentId(null);
  };

  const handleCreateNewFolder = () => {
    const name = newFolderName.trim();
    if (!name) return;

    onCreateFolder(name, newFolderParentId);
    closeNewFolderModal();
  };

  const openRenameEpisodeModal = (episodeId: string) => {
    const target = episodes.find((episode) => episode.id === episodeId);
    if (!target) return;

    setPanelContextMenu(null);
    setContextMenu(null);
    setFolderContextMenu(null);

    setTextModal({
      title: "Rename Episode",
      initialValue: target.displayName,
      placeholder: "Episode name",
      confirmLabel: "Rename",
      onConfirm: (value) => {
        onRenameEpisode(episodeId, value);
      },
    });
  };

  const openRenameFolderModal = (folderId: string) => {
    const target = episodeFolders.find((folder) => folder.id === folderId);
    if (!target) return;

    setPanelContextMenu(null);
    setContextMenu(null);
    setFolderContextMenu(null);

    setTextModal({
      title: "Rename Folder",
      initialValue: target.name,
      placeholder: "Folder name",
      confirmLabel: "Rename",
      onConfirm: (value) => {
        onRenameFolder(folderId, value);
      },
    });
  };

  return {
    contextMenu,
    setContextMenu,
    folderContextMenu,
    setFolderContextMenu,
    panelContextMenu,
    setPanelContextMenu,
    textModal,
    setTextModal,
    confirmModal,
    setConfirmModal,
    textModalInputRef,

    newFolderModal,
    newFolderName,
    setNewFolderName,
    newFolderParentId,
    setNewFolderParentId,
    closeNewFolderModal,
    handleCreateNewFolder,

    openContextMenu,
    openFolderContextMenu,
    openPanelContextMenu,
    openNewFolderModal,
    openRenameEpisodeModal,
    openRenameFolderModal,
  };
}