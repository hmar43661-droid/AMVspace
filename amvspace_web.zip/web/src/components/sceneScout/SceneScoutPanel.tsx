import { useEffect, useMemo, useRef, useState } from "react";
import { open } from "@tauri-apps/plugin-dialog";
import { open as openUrl } from "@tauri-apps/plugin-shell";
import { FaChevronRight, FaDatabase, FaEye, FaEyeSlash, FaPlus, FaSearch, FaSpinner, FaTimes, FaTrashAlt, FaVideo } from '../icons/animated';
import { FiDatabase } from '../icons/animated';
import { DatabaseImportIcon } from "../icons/ToolbarIcons";

import ModalShell from "../common/ModalShell";
import Tooltip from "../common/Tooltip";
import { useEscapeToClose } from "../common/useEscapeToClose";
import { samePath, useSceneScoutStore } from "../../stores/sceneScoutStore";
import { useContextMenuStore } from "../../stores/contextMenuStore";
import type { ScoutDatabase, ScoutVideo } from "../../features/sceneScout/types";
import { useScoutDbDrag, type ScoutList } from "./useScoutDbDrag";
import { useCreateScoutDatabase } from "./useCreateScoutDatabase";
import { EpisodeVisibilityPopover } from "./EpisodeVisibilityPopover";

const SONICFREAK_URL = "https://www.youtube.com/@sonicfreak1111";

type DbMenu ={ list: ScoutList; paths: string[]; x: number; y: number };

/** sidebar panel for the databases and their episodes, on the same shell as the episode and Scenepacks panels */
export function SceneScoutPanel() {
  const databases = useSceneScoutStore((s) => s.databases);
  const opened = useSceneScoutStore((s) => s.openedDatabase);
  const videos = useSceneScoutStore((s) => s.videos);
  const videosByDatabase = useSceneScoutStore((s) => s.videosByDatabase);
  const expandedDatabases = useSceneScoutStore((s) => s.expandedDatabases);
  const selectedDatabases = useSceneScoutStore((s) => s.selectedDatabases);
  const hiddenVideos = useSceneScoutStore((s) => s.hiddenVideos);
  const loading = useSceneScoutStore((s) => s.loading);
  const indexing = useSceneScoutStore((s) => s.indexing);
  const loadDatabases = useSceneScoutStore((s) => s.loadDatabases);
  const toggleDatabaseExpanded = useSceneScoutStore((s) => s.toggleDatabaseExpanded);
  const addToSearch = useSceneScoutStore((s) => s.addToSearch);
  const removeFromSearch = useSceneScoutStore((s) => s.removeFromSearch);
  const setActiveDatabase = useSceneScoutStore((s) => s.setActiveDatabase);
  const loadVideos = useSceneScoutStore((s) => s.loadVideos);
  const splitPct = useSceneScoutStore((s) => s.panelSplitPct);
  const setPanelSplitPct = useSceneScoutStore((s) => s.setPanelSplitPct);
  const openExistingDatabase = useSceneScoutStore((s) => s.openExistingDatabase);
  const deleteDatabase = useSceneScoutStore((s) => s.deleteDatabase);
  const deleteVideo = useSceneScoutStore((s) => s.deleteVideo);
  const unloadDatabase = useSceneScoutStore((s) => s.unloadDatabase);
  const displayNames = useSceneScoutStore((s) => s.displayNames);

  const { startCreate, modal: createModal, error: createError } = useCreateScoutDatabase();
  const [panelError, setError] = useState("");
  const error = panelError || createError;
  const [searchQuery, setSearchQuery] = useState("");
  const [isOpening, setIsOpening] = useState(false);
  const [openingName, setOpeningName] = useState<string | null>(null);
  const [databaseToDelete, setDatabaseToDelete] = useState<ScoutDatabase | null>(null);
  const [videosToDelete, setVideosToDelete] = useState<{ videos: ScoutVideo[]; database: ScoutDatabase } | null>(null);
  const [isDeletingVideo, setIsDeletingVideo] = useState(false);
  const [videosDeleted, setVideosDeleted] = useState(0);
  // explorer-style highlight for click, ctrl and shift; separate from which databases are searched
  const [highlight, setHighlight] = useState<{ list: ScoutList; paths: string[] }>({ list: "all", paths: [] });
  const [menu, setMenu] = useState<DbMenu | null>(null);
  // the searching list expands on its own so opening a row there does not also open it below
  const [searchExpanded, setSearchExpanded] = useState<Record<string, boolean>>({});
  // highlighted episodes, for removing several at once; never changes what is searched
  const [picked, setPicked] = useState<{ database: string; paths: string[] }>({ database: "", paths: [] });
  // the searched database whose episode visibility popover is open, and its eye button
  const [visibilityFor, setVisibilityFor] = useState<{ database: ScoutDatabase; anchor: HTMLElement } | null>(null);

  // clicking anywhere but an episode row drops the highlight
  useEffect(() => {
    if (picked.paths.length === 0) return;
    const onDown = (e: MouseEvent) => {
      if ((e.target as Element).closest?.(".scout-video-row")) return;
      setPicked({ database: "", paths: [] });
    };
    window.addEventListener("mousedown", onDown);
    return () => window.removeEventListener("mousedown", onDown);
  }, [picked.paths.length]);

  const pickVideo = (database: string, path: string, e: React.MouseEvent, order: string[]) => {
    setPicked((prev) => {
      const base = prev.database === database ? prev.paths : [];
      if (e.ctrlKey || e.metaKey) {
        const has = base.some((p) => samePath(p, path));
        return { database, paths: has ? base.filter((p) => !samePath(p, path)) : [...base, path] };
      }
      if (e.shiftKey && base.length) {
        const a = order.findIndex((p) => samePath(p, base[base.length - 1]));
        const b = order.findIndex((p) => samePath(p, path));
        if (a >= 0 && b >= 0) return { database, paths: order.slice(Math.min(a, b), Math.max(a, b) + 1) };
      }
      return { database, paths: [path] };
    });
  };

  const claimMenu = useContextMenuStore((s) => s.openContextMenu);
  const activeContextMenu = useContextMenuStore((s) => s.activeMenu);

  const labelFor = (path: string, fallback: string) => displayNames[path] ?? fallback;
  const inSearch = (path: string) => selectedDatabases.some((p) => samePath(p, path));
  const isHighlighted = (list: ScoutList, path: string) =>
    highlight.list === list && highlight.paths.some((p) => samePath(p, path));
  // acts on the whole highlight when the row is part of it, else on that row alone
  const targetsFor = (list: ScoutList, path: string) => (isHighlighted(list, path) ? highlight.paths : [path]);

  const moveTo = (paths: string[], to: ScoutList) => {
    if (to === "search") addToSearch(paths.filter((p) => !inSearch(p)));
    else removeFromSearch(paths);
  };

  const { dropList, ghost, beginDrag, suppressClickRef } = useScoutDbDrag(moveTo);

  useEffect(() => {
    void loadDatabases();
  }, [loadDatabases]);

  // the eye on a searched database shows whether any of its episodes are hidden, which needs its episode list
  useEffect(() => {
    if (hiddenVideos.length === 0) return;
    for (const path of selectedDatabases) {
      if (!useSceneScoutStore.getState().videosByDatabase[path]) void loadVideos(path);
    }
  }, [hiddenVideos.length, selectedDatabases, loadVideos]);

  // another menu took the slot, so this one is stale
  useEffect(() => {
    if (activeContextMenu !== "scene-scout-database") setMenu(null);
  }, [activeContextMenu]);

  // contextmenu as well as click: a right-click fires no click event
  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, [menu]);

  useEscapeToClose(() => setMenu(null), menu !== null);

  // filters the panel's own lists, not scenes
  const visible = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return databases;
    return databases.filter((database) =>
      labelFor(database.path, database.name).toLowerCase().includes(q)
    );
  }, [databases, searchQuery, displayNames]);

  // in the order they were added, which is the order they move up in
  const searchVisible = useMemo(
    () =>
      selectedDatabases
        .map((p) => visible.find((d) => samePath(d.path, p)))
        .filter((d): d is ScoutDatabase => Boolean(d)),
    [selectedDatabases, visible]
  );

  const onRowClick = (list: ScoutList, path: string, order: string[]) => (e: React.MouseEvent) => {
    if (suppressClickRef.current) {
      suppressClickRef.current = false;
      return;
    }
    // the last clicked database is where Add Episode indexes into
    setActiveDatabase(path);
    setHighlight((prev) => {
      const base = prev.list === list ? prev.paths : [];
      if (e.ctrlKey || e.metaKey) {
        const has = base.some((p) => samePath(p, path));
        return { list, paths: has ? base.filter((p) => !samePath(p, path)) : [...base, path] };
      }
      if (e.shiftKey && base.length) {
        const anchor = base[base.length - 1];
        const a = order.findIndex((p) => samePath(p, anchor));
        const b = order.findIndex((p) => samePath(p, path));
        if (a >= 0 && b >= 0) {
          const range = order.slice(Math.min(a, b), Math.max(a, b) + 1);
          // anchor stays last so the next shift-click ranges from the same row
          return { list, paths: [...range.filter((p) => !samePath(p, anchor)), anchor] };
        }
      }
      return { list, paths: [path] };
    });
  };

  const openMenu = (list: ScoutList, path: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const paths = targetsFor(list, path);
    if (!isHighlighted(list, path)) setHighlight({ list, paths: [path] });
    claimMenu("scene-scout-database");
    setMenu({ list, paths, x: e.clientX, y: e.clientY });
  };

  const splitRef = useRef<HTMLDivElement>(null);

  // drag the handle between the two boxes to trade height between them
  const beginResize = (e: React.PointerEvent) => {
    if (e.button !== 0 || !splitRef.current) return;
    e.preventDefault();
    const rect = splitRef.current.getBoundingClientRect();
    const onMove = (ev: PointerEvent) => setPanelSplitPct(((ev.clientY - rect.top) / rect.height) * 100);
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      document.body.classList.remove("scene-scout-resizing");
    };
    document.body.classList.add("scene-scout-resizing");
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
  };

  const toggleSearchExpanded = (path: string) => {
    const opening = !searchExpanded[path];
    setSearchExpanded((prev) => ({ ...prev, [path]: opening }));
    if (opening && !videosByDatabase[path]) void loadVideos(path);
  };

  const startOpen = async () => {
    setError("");

    const picked = await open({
      title: "Open Scene Scout Database",
      multiple: false,
      directory: false,
      filters: [
        {
          name: "Scene Scout Database (*.scoutdb, *.db, *.scdb)",
          extensions: ["scoutdb", "db", "scdb"],
        },
        { name: "All Files (*.*)", extensions: ["*"] },
      ],
    });
    if (!picked || typeof picked !== "string") return;

    const name = picked.split(/[/\\]/).pop() || picked;
    setIsOpening(true);
    setOpeningName(name);
    try {
      const result = await openExistingDatabase(picked);
      if (!result.ok) {
        setError(result.message || "Could not open the database.");
      }
    } finally {
      setIsOpening(false);
      setOpeningName(null);
    }
  };

  // picking episodes only highlights them (e.g. to remove several); the eye decides what is searched
  const renderVideos = (database: ScoutDatabase) => {
    const dbVideos = videosByDatabase[database.path] ?? (samePath(opened, database.path) ? videos : []);
    const allDbVideoPaths = dbVideos.map((v) => v.filepath);
    const isIndexingVideo = (video: ScoutVideo) =>
      video.status === "indexing" || (indexing !== null && samePath(indexing.video, video.filepath));
    const isPicked = (video: ScoutVideo) =>
      samePath(picked.database, database.path) && picked.paths.some((p) => samePath(p, video.filepath));
    const pickedHere = dbVideos.filter((video) => isPicked(video) && !isIndexingVideo(video));
    return dbVideos.map((video) => {
      const isVideoSelected = isPicked(video);
      const isVideoIndexing = isIndexingVideo(video);
      const isHidden = hiddenVideos.some((h) => samePath(h, video.filepath));
      // a selected row's trash takes the whole selection in this database with it
      const deleteTargets = isVideoSelected && pickedHere.length > 1 ? pickedHere : [video];
      let videoRowClass = "episode-panel-row episode-row scout-video-row";
      if (isVideoSelected) videoRowClass += " is-focused is-selected";
      if (isHidden) videoRowClass += " is-search-hidden";

      return (
        <div
          key={video.id}
          className={videoRowClass}
          style={{ paddingLeft: "32px" }}
          title={isHidden ? "Hidden from searches" : undefined}
          onClick={(e) => {
            e.stopPropagation();
            pickVideo(database.path, video.filepath, e, allDbVideoPaths);
          }}
        >
          <FaVideo className="episode-panel-import-icon scene-scout-row-icon" aria-hidden="true" />
          <span className="episode-panel-episode-name">{video.name}</span>
          <span className="episode-panel-count">
            {video.status === "indexing" ? "..." : video.sceneCount}
          </span>
          <Tooltip
            content={
              isVideoIndexing
                ? "Cannot delete while indexing"
                : deleteTargets.length > 1
                ? `Remove ${deleteTargets.length} videos from database`
                : "Remove video from database"
            }
          >
            <button
              type="button"
              className="episode-panel-import-icon episode-folder-btn episode-delete-btn"
              disabled={isVideoIndexing}
              onClick={(e) => {
                e.stopPropagation();
                setVideosToDelete({ videos: deleteTargets, database });
              }}
              aria-label={
                deleteTargets.length > 1
                  ? `Remove ${deleteTargets.length} videos from ${database.name}`
                  : `Remove ${video.name} from ${database.name}`
              }
            >
              <FaTrashAlt aria-hidden="true" />
            </button>
          </Tooltip>
        </div>
      );
    });
  };

  const renderDbRow = (database: ScoutDatabase, list: ScoutList, order: string[]) => {
    const path = database.path;
    const isExpanded = list === "search" ? Boolean(searchExpanded[path]) : Boolean(expandedDatabases[path]);
    const lit = isHighlighted(list, path);
    // stays in the full list while searched, greyed so it reads as already picked
    const searched = list === "all" && inSearch(path);
    const stop = (e: React.SyntheticEvent) => e.stopPropagation();

    let rowClass = "episode-panel-row episode-row scene-scout-db-row";
    if (lit) rowClass += highlight.paths.length > 1 ? " is-multi-selected is-selected" : " is-selected";
    if (isExpanded) rowClass += " is-open";
    if (searched) rowClass += " is-in-search";

    return (
      <div key={path} className="episode-panel-folder">
        <div
          className={rowClass}
          title={searched ? "Already being searched" : undefined}
          onPointerDown={beginDrag(list, () => targetsFor(list, path))}
          onClick={onRowClick(list, path, order)}
          onDoubleClick={() => moveTo(targetsFor(list, path), list === "all" ? "search" : "all")}
          onContextMenu={openMenu(list, path)}
        >
          <button
            type="button"
            className={`episode-panel-caret${isExpanded ? " is-expanded" : ""}`}
            onPointerDown={stop}
            onDoubleClick={stop}
            onClick={(e) => {
              e.stopPropagation();
              if (list === "search") toggleSearchExpanded(path);
              else void toggleDatabaseExpanded(path);
            }}
            aria-label={isExpanded ? "Collapse database" : "Expand database"}
            style={{ marginRight: "6px" }}
          >
            <FaChevronRight className="episode-panel-caret-icon" />
          </button>
          {/* outline marks a database with nothing indexed yet */}
          {database.videoCount === 0 ? (
            <FiDatabase className="episode-panel-import-icon scene-scout-row-icon" aria-hidden="true" />
          ) : (
            <FaDatabase className="episode-panel-import-icon scene-scout-row-icon" aria-hidden="true" />
          )}
          <span className="episode-panel-episode-name">{labelFor(path, database.name)}</span>
          <span className="episode-panel-count">{database.sceneCount}</span>
          {list === "search" && (() => {
            const hiddenHere = (videosByDatabase[path] ?? []).filter((v) =>
              hiddenVideos.some((h) => samePath(h, v.filepath))
            ).length;
            return (
              <Tooltip content={hiddenHere > 0 ? `${hiddenHere} episodes hidden from searches` : "Choose which episodes are searched"}>
                <button
                  type="button"
                  className={`episode-panel-import-icon episode-folder-btn scout-visibility-btn${hiddenHere > 0 ? " has-hidden" : ""}`}
                  onPointerDown={stop}
                  onDoubleClick={stop}
                  onClick={(e) => {
                    e.stopPropagation();
                    const anchor = e.currentTarget;
                    setVisibilityFor((current) =>
                      current && samePath(current.database.path, path) ? null : { database, anchor }
                    );
                  }}
                  aria-label={`Episodes searched in ${database.name}`}
                >
                  {hiddenHere > 0 ? <FaEyeSlash aria-hidden="true" /> : <FaEye aria-hidden="true" />}
                </button>
              </Tooltip>
            );
          })()}
          <Tooltip content="Delete database from disk">
            <button
              type="button"
              className="episode-panel-import-icon episode-folder-btn episode-delete-btn"
              onPointerDown={stop}
              onDoubleClick={stop}
              onClick={(e) => {
                e.stopPropagation();
                setDatabaseToDelete(database);
              }}
              aria-label={`Delete ${database.name}`}
            >
              <FaTrashAlt aria-hidden="true" />
            </button>
          </Tooltip>
        </div>

        {isExpanded && (
          <div className="episode-panel-folder-children">{renderVideos(database)}</div>
        )}
      </div>
    );
  };

  return (
    <div className="eps-container">
      <div className="episode-panel">
        <div className="episode-panel-header">
          <div className="episode-panel-title">
            Scene Scout
            {/* upstream author, credited where the feature actually lives */}
            <span className="scene-scout-credit">
              By{" "}
              <button type="button" className="scene-scout-credit-link" onClick={() => void openUrl(SONICFREAK_URL)}>
                Mark Shun/Sonicfreak
              </button>
            </span>
          </div>
          <div className="episode-panel-actions" data-scout-tour="db-actions">
            <Tooltip content={isOpening ? "Opening database…" : "Import a database file"}>
              <button
                type="button"
                className="episode-panel-action icon-only"
                onClick={() => void startOpen()}
                disabled={isOpening}
                aria-label="Import a database file"
              >
                {isOpening ? <FaSpinner className="spinner" aria-hidden="true" /> : <DatabaseImportIcon />}
              </button>
            </Tooltip>
            <Tooltip content="New database">
              <button
                type="button"
                className="episode-panel-action icon-only"
                onClick={() => void startCreate()}
                aria-label="New database"
              >
                <FaPlus aria-hidden="true" />
              </button>
            </Tooltip>
          </div>
        </div>

        <div className="scenepack-search">
          <FaSearch className="scenepack-search-icon" />
          <input
            type="text"
            className="scenepack-search-input"
            placeholder="Search databases..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <Tooltip content="Clear search">
              <button
                className="scenepack-search-clear"
                onClick={() => setSearchQuery("")}
                aria-label="Clear search"
              >
                <FaTimes />
              </button>
            </Tooltip>
          )}
        </div>

        {error && <p className="events-error scene-scout-panel-error">{error}</p>}

        {databases.length === 0 ? (
        <div className="episode-panel-list" data-scout-tour="db-empty">
          {loading ? (
            <div className="scenepacks-empty-cta">
              <FaSpinner
                className="scenepack-spinner"
                style={{ fontSize: 24, opacity: 0.4 }}
                aria-hidden="true"
              />
              <span style={{ fontSize: 13, opacity: 0.5 }}>Loading databases...</span>
            </div>
          ) : (
            <div className="scenepacks-empty-cta">
              <FaDatabase style={{ fontSize: 28, opacity: 0.3 }} aria-hidden="true" />
              <span style={{ fontSize: 15, opacity: 0.6 }}>No databases yet</span>
              <button
                className="episode-modal-btn primary"
                onClick={() => void startCreate()}
                style={{ marginTop: 6, fontSize: 12, padding: "6px 12px" }}
              >
                Create a Scene Scout Database
              </button>
            </div>
          )}
        </div>
        ) : (
        <div className="scene-scout-split" ref={splitRef}>
          <div
            data-scout-list="search"
            data-scout-tour="searching"
            className={`episode-panel-list scene-scout-db-box${dropList === "search" ? " is-drop-target-root" : ""}`}
            style={{ flex: `0 0 calc(${splitPct}% - 5px)` }}
          >
            <div className="scene-scout-section-label">Searching · {selectedDatabases.length}</div>
            {searchVisible.length === 0 ? (
              <div className="scene-scout-drop-hint">
                {selectedDatabases.length === 0
                  ? "Nothing is searched yet. Double-click, drag or right-click a database below to search it"
                  : "No searched databases match that filter."}
              </div>
            ) : (
              searchVisible.map((database) => renderDbRow(database, "search", searchVisible.map((d) => d.path)))
            )}
          </div>

          <div
            className="scene-scout-split-handle"
            role="separator"
            aria-orientation="horizontal"
            aria-label="Resize lists"
            onPointerDown={beginResize}
          />

          <div
            data-scout-list="all"
            data-scout-tour="all-databases"
            className={`episode-panel-list scene-scout-db-box${dropList === "all" ? " is-drop-target-root" : ""}`}
          >
            <div className="scene-scout-section-label">All databases · {databases.length}</div>
            {isOpening && openingName && (
              <div className="episode-panel-row episode-row" style={{ opacity: 0.75, pointerEvents: "none" }}>
                <FaSpinner className="episode-panel-import-icon spinner" style={{ animation: "spin 1s linear infinite" }} />
                <span className="episode-panel-episode-name">Opening {openingName}…</span>
                <span className="episode-panel-count">loading</span>
              </div>
            )}
            {visible.length === 0 ? (
              // a search that matched nothing, which is not the same as having no databases at all
              <div className="episode-panel-empty">No databases match that search.</div>
            ) : (
              visible.map((database) => renderDbRow(database, "all", visible.map((d) => d.path)))
            )}
          </div>
        </div>
        )}
      </div>

      {visibilityFor && inSearch(visibilityFor.database.path) && (
        <EpisodeVisibilityPopover
          database={visibilityFor.database}
          anchor={visibilityFor.anchor}
          onClose={() => setVisibilityFor(null)}
        />
      )}

      {menu && (() => {
        const n = menu.paths.length;
        const single = n === 1 ? databases.find((d) => samePath(d.path, menu.paths[0])) ?? null : null;
        const toAdd = menu.paths.filter((p) => !inSearch(p));
        const close = () => setMenu(null);
        return (
          <div
            className="episode-context-menu scene-scout-db-menu"
            style={{ left: menu.x, top: menu.y }}
            onClick={(e) => e.stopPropagation()}
          >
            {menu.list === "all" ? (
              <button
                type="button"
                className="episode-context-menu-item"
                disabled={toAdd.length === 0}
                onClick={() => {
                  moveTo(toAdd, "search");
                  close();
                }}
              >
                {toAdd.length === 0 ? "Already selected" : toAdd.length > 1 ? `Select ${toAdd.length} databases` : "Select this database"}
              </button>
            ) : (
              <button
                type="button"
                className="episode-context-menu-item"
                onClick={() => {
                  moveTo(menu.paths, "all");
                  close();
                }}
              >
                {n > 1 ? `Deselect ${n} databases` : "Deselect this database"}
              </button>
            )}
            <div className="episode-context-menu-separator" />
            <button
              type="button"
              className="episode-context-menu-item"
              onClick={() => {
                menu.paths.forEach((p) => unloadDatabase(p));
                setHighlight({ list: menu.list, paths: [] });
                close();
              }}
            >
              {n > 1 ? `Remove ${n} databases from list` : "Remove from list"}
            </button>
            {single && (
              <button
                type="button"
                className="episode-context-menu-item scene-scout-menu-danger"
                onClick={() => {
                  setDatabaseToDelete(single);
                  close();
                }}
              >
                Delete from disk…
              </button>
            )}
          </div>
        );
      })()}

      {ghost && (
        <div className="scene-scout-drag-ghost" style={{ left: ghost.x + 14, top: ghost.y + 10 }}>
          {ghost.count > 1 ? `${ghost.count} databases` : "1 database"}
        </div>
      )}

      {createModal}

      {databaseToDelete && (
        <ModalShell
          open
          onClose={() => setDatabaseToDelete(null)}
          label="Delete database"
          className="scene-scout-delete-modal"
        >
          <div className="denial-notice">
            <FaTrashAlt aria-hidden="true" className="denial-notice-icon" style={{ color: "#ef4444" }} />
            <h2>Delete Database from System?</h2>

            <p className="events-subtitle ban-notice-note scene-scout-delete-question" style={{ color: "rgba(255,255,255,0.85)" }}>
              Are you sure you want to permanently delete <strong>{databaseToDelete.name}</strong> from your system?
            </p>

            <div className="scene-scout-delete-details">
              <div style={{ color: "rgba(255,255,255,0.5)", marginBottom: "4px" }}>File path:</div>
              <div style={{ fontFamily: "monospace", color: "rgba(255,255,255,0.9)" }}>{databaseToDelete.path}</div>
              <div style={{ marginTop: "6px", color: "rgba(255,255,255,0.6)" }}>
                {databaseToDelete.videoCount} {databaseToDelete.videoCount === 1 ? "video" : "videos"} · {databaseToDelete.sceneCount} indexed {databaseToDelete.sceneCount === 1 ? "scene" : "scenes"}
              </div>
            </div>

            <p className="scene-scout-delete-warning">
              This will permanently erase the database file and its embeddings from disk. This action cannot be undone. If you only want to remove it from this list, right-click it and choose Remove from list instead.
            </p>

            <div className="denial-notice-actions">
              <button
                type="button"
                className="event-host-btn"
                style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)" }}
                onClick={() => setDatabaseToDelete(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="event-host-btn"
                style={{ background: "#ef4444", borderColor: "#ef4444", color: "white" }}
                onClick={async () => {
                  const db = databaseToDelete;
                  setDatabaseToDelete(null);
                  await deleteDatabase(db.path);
                }}
              >
                Delete Database
              </button>
            </div>
          </div>
        </ModalShell>
      )}

      {videosToDelete && (
        <ModalShell
          open
          onClose={() => !isDeletingVideo && setVideosToDelete(null)}
          label={videosToDelete.videos.length > 1 ? "Remove videos from database" : "Remove video from database"}
          className="scene-scout-delete-modal"
        >
          <div className="denial-notice">
            <FaTrashAlt aria-hidden="true" className="denial-notice-icon" style={{ color: "#ef4444" }} />
            <h2>{videosToDelete.videos.length > 1 ? `Remove ${videosToDelete.videos.length} Videos from Database?` : "Remove Video from Database?"}</h2>

            <p className="events-subtitle ban-notice-note scene-scout-delete-question" style={{ color: "rgba(255,255,255,0.85)" }}>
              Are you sure you want to remove{" "}
              <strong>
                {videosToDelete.videos.length > 1 ? `${videosToDelete.videos.length} videos` : videosToDelete.videos[0].name}
              </strong>{" "}
              from <strong>{videosToDelete.database.name}</strong>?
            </p>

            <div className="scene-scout-delete-details">
              {videosToDelete.videos.length > 1 ? (
                <div className="scene-scout-delete-list">
                  {videosToDelete.videos.map((video) => (
                    <div key={video.id} title={video.filepath}>{video.name}</div>
                  ))}
                </div>
              ) : (
                <>
                  <div style={{ color: "rgba(255,255,255,0.5)", marginBottom: "4px" }}>File path:</div>
                  <div style={{ fontFamily: "monospace", color: "rgba(255,255,255,0.9)" }}>{videosToDelete.videos[0].filepath}</div>
                </>
              )}
              <div style={{ marginTop: "6px", color: "rgba(255,255,255,0.6)" }}>
                {(() => {
                  const scenes = videosToDelete.videos.reduce((sum, video) => sum + video.sceneCount, 0);
                  return `${scenes} indexed ${scenes === 1 ? "scene" : "scenes"}`;
                })()}
              </div>
            </div>

            <p className="scene-scout-delete-warning">
              {videosToDelete.videos.length > 1
                ? "This will remove these video entries and all their scene embeddings and thumbnails from this database. The video files on your computer will NOT be deleted."
                : "This will remove the video entry and all its scene embeddings and thumbnails from this database. The video file on your computer will NOT be deleted."}
            </p>

            <div className="denial-notice-actions">
              <button
                type="button"
                className="event-host-btn"
                style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)" }}
                onClick={() => setVideosToDelete(null)}
                disabled={isDeletingVideo}
              >
                Cancel
              </button>
              <button
                type="button"
                className="event-host-btn"
                style={{ background: "#ef4444", borderColor: "#ef4444", color: "white" }}
                disabled={isDeletingVideo}
                onClick={async () => {
                  const target = videosToDelete;
                  setIsDeletingVideo(true);
                  setVideosDeleted(0);
                  try {
                    // one at a time: each is its own cli run against the same database file
                    for (const video of target.videos) {
                      await deleteVideo(target.database.path, video.id);
                      setVideosDeleted((count) => count + 1);
                    }
                    setVideosToDelete(null);
                  } finally {
                    setIsDeletingVideo(false);
                  }
                }}
              >
                {isDeletingVideo
                  ? videosToDelete.videos.length > 1
                    ? `Removing ${videosDeleted}/${videosToDelete.videos.length}...`
                    : "Removing..."
                  : videosToDelete.videos.length > 1
                  ? `Remove ${videosToDelete.videos.length} Videos`
                  : "Remove Video"}
              </button>
            </div>
          </div>
        </ModalShell>
      )}
    </div>
  );
}

export default SceneScoutPanel;
