import { useMemo } from "react";
import { FaChevronDown, FaChevronUp, FaQuestionCircle, FaWindows, FaApple, FaLinux } from '../icons/animated';

import Tooltip from "../common/Tooltip";
import { useUIStateStore } from "../../stores/UIStore";
import { useSceneScoutStore } from "../../stores/sceneScoutStore";

type Platform = "windows" | "mac" | "linux";
type Guide = "library" | "scenepacks" | "sceneScoutSearch" | "sceneScoutFlow";

function detectCurrentPlatform(): Platform {
  if (typeof navigator === "undefined") return "windows";
  const ua = navigator.userAgent;
  if (/mac/i.test(ua)) return "mac";
  if (/linux/i.test(ua)) return "linux";
  return "windows";
}

const PLATFORM_INFO: Record<Platform, { label: string; icon: React.ReactNode; mod: string }> = {
  windows: { label: "Windows", icon: <FaWindows />, mod: "Ctrl" },
  linux: { label: "Linux", icon: <FaLinux />, mod: "Ctrl" },
  mac: { label: "macOS", icon: <FaApple />, mod: "Cmd" },
};

const TITLES: Record<Guide, string> = {
  library: "HOW TO USE",
  scenepacks: "HOW TO USE SCENEPACKS",
  sceneScoutSearch: "HOW TO USE SCENE SCOUT",
  sceneScoutFlow: "HOW TO USE MATCH",
};

// `mod` is the multi-select key for the chosen platform
function steps(guide: Guide, mod: string): React.ReactNode[] {
  const select = <>Select clips with <b>{mod} + Click</b>, <b>Shift + Click</b>, or <b>Double Click</b></>;
  const exportNow = <>Click <b>Export Now</b> to export what you picked</>;

  switch (guide) {
    case "scenepacks":
      return [
        <>Create a Scenepack in the left panel</>,
        <>In the <b>Library</b>, select clips and click <b>Add to Scenepack</b></>,
        <>Open a Scenepack to see its clips</>,
        select,
        exportNow,
      ];
    case "sceneScoutSearch":
      return [
        <>Create or open a <b>Database</b> in the left panel</>,
        <>Move it into <b>Searching</b>: <b>Double Click</b> it, drag it up, or right click it. Only databases in Searching are searched</>,
        <>Click <b>Add Episode</b> to index episodes into it</>,
        <>Describe a scene in the search bar and press <b>Enter</b></>,
        <>Single click a result to <b>Preview</b> it</>,
        exportNow,
      ];
    case "sceneScoutFlow":
      return [
        <>Click <b>Import</b>, or right-click a clip and pick <b>Find matching clips</b></>,
        <>Matches are scenes that look like they continue from your clip's last frame</>,
        <>Drag the line between your clip and the matches to resize them</>,
        <>Single click a match to <b>Preview</b> it</>,
        exportNow,
      ];
    default:
      return [
        select,
        <>Single click to <b>Focus</b> a clip</>,
        <>Select <b>Export Profile</b> for export settings</>,
        <>Click <b>Export Now</b> to start the process</>,
      ];
  }
}

export default function HowToUse() {
  const platform = useMemo(() => detectCurrentPlatform(), []);
  const currentInfo = PLATFORM_INFO[platform];

  // persisted, so a guide the user folded away stays folded across restarts
  const isExpanded = useUIStateStore((s) => s.howToUseExpanded);
  const setIsExpanded = useUIStateStore((s) => s.setHowToUseExpanded);
  const activePage = useUIStateStore((s) => s.activePage);
  const scoutMode = useSceneScoutStore((s) => s.mode);
  const setTourSeen = useUIStateStore((s) => s.setSceneScoutTourSeen);
  const setGettingStartedSeen = useUIStateStore((s) => s.setGettingStartedSeen);

  // the guide follows the page the preview pane sits beside
  const guide: Guide =
    activePage === "scenepacks"
      ? "scenepacks"
      : activePage === "sceneScout"
        ? scoutMode === "flow" ? "sceneScoutFlow" : "sceneScoutSearch"
        : "library";

  return (
    <div className={`info-panel ${isExpanded ? "expanded" : "collapsed"}`} data-getting-started="how-to-use">
      <div className="info-header" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="info-header-left">
          <FaQuestionCircle className="info-icon" />
          <span className="info-title">{TITLES[guide]}</span>
        </div>
        <Tooltip content={isExpanded ? "Hide the guide" : "Show the guide"}>
          <button
            className="info-toggle"
            type="button"
            aria-label={isExpanded ? "Hide the guide" : "Show the guide"}
            aria-expanded={isExpanded}
          >
            {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
          </button>
        </Tooltip>
      </div>

      {isExpanded && (
        <div className="info-content">
          <div className="platform-switcher">
            <div className="platform-btn active" style={{ cursor: "default", justifyContent: "center" }}>
              {currentInfo.icon} {currentInfo.label}
            </div>
          </div>

          <div className="info-steps">
            <ul className="steps-list">
              {steps(guide, currentInfo.mod).map((step, index) => (
                <li key={index}>
                  <span className="step-text">{step}</span>
                </li>
              ))}
            </ul>
            {guide === "library" && (
              <button type="button" className="info-tour-link" onClick={() => setGettingStartedSeen(false)}>
                Getting started guide
              </button>
            )}
            {guide === "sceneScoutSearch" && (
              <button type="button" className="info-tour-link" onClick={() => setTourSeen(false)}>
                Show the walkthrough again
              </button>
            )}
            {guide === "sceneScoutFlow" && (
              <button type="button" className="info-tour-link" onClick={() => setTourSeen(false)}>
                Show the walkthrough again
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
