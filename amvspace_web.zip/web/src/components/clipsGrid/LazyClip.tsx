import { memo, useCallback, useDeferredValue, useEffect, useRef, useState } from "react";
import { convertFileSrc } from "@tauri-apps/api/core";
import { FaCheck, FaPlus, FaTrashAlt } from '../icons/animated';
import { LazyClipProps } from "./types.ts";
import type { ClipItem } from "../../types/domain.ts";
import { DownloadButton } from "./DownloadButton.tsx";
import Tooltip from "../common/Tooltip.tsx";
import { useWebpPreview } from "./useWebpPreview.ts";
import { useClipStagger } from "./useClipStagger.ts";
import { useClipVideoSource } from "./useClipVideoSource.ts";
import { useClipVideoElement } from "./useClipVideoElement.ts";
import { useDownloadTone } from "./useDownloadTone.ts";
import { formatClipDuration, formatClipTime, formatClipTimeframe, formatScoreWithConfidence } from "./clipFormat.ts";
import { imageThumbnail, mediaSrcVersioned } from "../../utils/mediaSrc.ts";
import { useAppStateStore } from "../../stores/appStore.ts";
import { selectOverlayOpen, useUIStateStore } from "../../stores/UIStore.ts";
import { useGeneralSettingsStore, useThemeSettingsStore } from "../../stores/settingsStore.ts";
import { useScenePreviewStore } from "../../stores/scenePreviewStore.ts";
import { useContextMenuStore } from "../../stores/contextMenuStore.ts";
import { AddToScenepackModal } from "./AddToScenepackModal.tsx";
import { ScenepackPickerMenu } from "./ScenepackPickerMenu.tsx";
import { useEpisodePanelRuntimeStore } from "../../stores/episodeStore.ts";
import { useScenepacksStore } from "../../stores/scenepackStore.ts";
import { removeClipsFromScenepack } from "../../utils/scenepackStorage.ts";
import { canFindFlowFrom, describeMotion, flowSourceForClip } from "../../features/sceneScout/motion.ts";
import { useSceneScoutStore } from "../../stores/sceneScoutStore.ts";
import { isGridScrolling, whenGridScrollSettles } from "./gridScroll.ts";
import { scheduleIdle } from "../../utils/idle.ts";

const VIDEO_THUMB_MAX_RETRIES = 2;

// decodes in idle time once loaded, so an overscan row is ready before it scrolls into view
function predecode(img: HTMLImageElement) {
  scheduleIdle(() => {
    img.decode?.().catch(() => {});
  });
}

// one grid tile; playback, proxying, stagger and tone sampling live in their own hooks
export const LazyClip = memo(function LazyClip({
  clip,
  index,
  videoPreviewMode,
  requestProxySequential,
  reportProxyDemand,
  reportWebpDemand,
  onClipClick,
  onClipDoubleClick,
  onToggleSelection,
  reportStaggerDemand,
  onDownloadClip,
  onClipContextMenu,
  appearDelayMs,
  active = true,
}: LazyClipProps) {
  const importToken = useAppStateStore((s) => s.importToken);
  const previewWebpPath = useScenePreviewStore((s) => s.animatedByClipId[clip.id]);
  const isSelected = useAppStateStore((s) => s.selectedClips.has(clip.id));
  const isFocused = useAppStateStore((s) => s.focusedClipId === clip.id);
  const settingsOpen = useDeferredValue(useUIStateStore(selectOverlayOpen));
  const gridPreview = useUIStateStore((s) => s.gridPreview) && !settingsOpen && active;
  const previewCollapsed = useUIStateStore((s) => s.previewCollapsed);
  const activePage = useUIStateStore((s) => s.activePage);
  const videoIsHEVC = useAppStateStore((s) => s.videoIsHEVC);
  const userHasHEVC = useAppStateStore((s) => s.userHasHEVC);
  const videoNeedsProxy = useAppStateStore((s) => s.videoNeedsProxy);
  const audioPlaybackHover = useGeneralSettingsStore((s) => s.audioPlaybackHover);
  const previewAudioStreamIndex = useGeneralSettingsStore((s) => s.previewAudioStreamIndex);
  const playbackVolume = useGeneralSettingsStore((s) => s.playbackVolume);
  const scenepacksEnabled = useGeneralSettingsStore((s) => s.scenepacksEnabled);
  const sceneScoutEnabled = useGeneralSettingsStore((s) => s.sceneScoutEnabled);
  const gridPreviewSpeed = useThemeSettingsStore((s) => s.gridPreviewSpeed ?? 1);
  const showDownloadButton = useThemeSettingsStore((s) => s.showDownloadButton);
  const showClipTimestamps = useThemeSettingsStore((s) => s.showClipTimestamps);
  const showClipEndTime = useThemeSettingsStore((s) => s.showClipEndTime ?? true);
  const showClipDuration = useThemeSettingsStore((s) => s.showClipDuration ?? false);

  const openedEpisodeId = useEpisodePanelRuntimeStore((s) => s.openedEpisodeId);
  const episodeId = clip.episodeId ?? openedEpisodeId ?? clip.id.split("_").slice(0, -1).join("_");

  const [isVisible, setIsVisible] = useState(false);
  const [hovered, setIsHovered] = useState(false);
  useEffect(() => {
    if (!active) setIsHovered(false);
  }, [active]);
  const isHovered = hovered && !settingsOpen && active;
  // when this tile is actively playing inside VideoPlayer, mute hover audio so two players never echo
  const hoverAudioActive =
    isHovered && audioPlaybackHover && !(isFocused && !previewCollapsed && active);
  const [showScenepackModal, setShowScenepackModal] = useState(false);
  const [scenepackMenu, setScenepackMenu] = useState<{ x: number; y: number } | null>(null);
  // fixed when the menu opens, so the modal it leads to adds the same clips
  const [scenepackTargets, setScenepackTargets] = useState<ClipItem[]>([clip]);
  const [dragOver, setDragOver] = useState(false);
  // the select and download buttons stay invisible until hover, so they mount on first hover or selection and then stay
  const [controlsMounted, setControlsMounted] = useState(false);
  const [videoThumbFailed, setVideoThumbFailed] = useState(false);
  const [videoThumbRetry, setVideoThumbRetry] = useState(0);

  const wrapperRef = useRef<HTMLDivElement>(null);
  const thumbnailRef = useRef<HTMLImageElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  // a hover that arrived mid-scroll, waiting for the scroll to settle
  const pendingHoverRef = useRef<(() => void) | null>(null);
  useEffect(() => () => pendingHoverRef.current?.(), []);

  // another menu claimed the slot, so this tile's menu is stale
  const activeContextMenu = useContextMenuStore((s) => s.activeMenu);
  useEffect(() => {
    if (activeContextMenu !== "clip-scenepack-picker") setScenepackMenu(null);
  }, [activeContextMenu]);

  const isVideoMode = Boolean(clip.clipPath) && clip.clipMode !== "failed";
  const isUncutScene =
    (videoPreviewMode || Boolean(clip.database)) &&
    !clip.clipPath &&
    Boolean(clip.src) &&
    clip.startSec !== undefined &&
    clip.endSec !== undefined &&
    clip.endSec > clip.startSec;
  const isVideoPlayable = (isVideoMode || isUncutScene) && clip.clipMode !== "failed";
  const usesRangePreview = isUncutScene && Boolean(clip.database);
  const isProcessing =
    clip.originalName === "Merging..." ||
    clip.originalName === "Splitting..." ||
    clip.originalName === "Adding...";
  const needsDecodeProxy = (videoIsHEVC === true && userHasHEVC === false) || videoNeedsProxy;
  const resetKey = `${clip.src}::${importToken}::${previewAudioStreamIndex ?? "default"}`;

  useEffect(() => {
    setVideoThumbFailed(false);
    setVideoThumbRetry(0);
  }, [resetKey]);

  const staggerReady = useClipStagger({
    clipId: clip.id,
    index,
    gridPreview,
    isHovered,
    isVisible,
    needsDecodeProxy,
    resetKey,
    reportStaggerDemand,
  });

  const source = useClipVideoSource({
    clip,
    index,
    isVideoMode: isVideoPlayable,
    isVisible,
    isHovered,
    gridPreview,
    staggerReady,
    showVideo: isVideoPlayable,
    importToken,
    needsDecodeProxy,
    audioPlaybackHover,
    previewAudioStreamIndex,
    videoRef,
    requestProxySequential,
    reportProxyDemand,
    rangeStart: usesRangePreview ? clip.startSec : undefined,
    rangeEnd: usesRangePreview ? clip.endSec : undefined,
  });

  // a scout result plays its range preview; seeking the full source is only the hover fallback
  const seekIntoSource = isUncutScene && !source.rangeProxySrc;

  // mount on hover or preview-all only, so live decoders stay bounded; wait for a needed proxy or the clip renders black
  const shouldMountVideo =
    active &&
    isVideoPlayable &&
    (isHovered || (gridPreview && staggerReady)) &&
    (usesRangePreview
      ? Boolean(source.rangeProxySrc) || (source.rangeFailed && !source.sourceMissing && isHovered)
      : !source.needsPreviewTranscode || Boolean(source.videoProxySrc));

  // one source of truth for the src, shared with the media-release effect
  const rawVideoPath = source.rangeProxySrc ?? source.videoProxySrc ?? clip.clipPath ?? clip.src;
  const videoSrcUrl = shouldMountVideo
    ? `${convertFileSrc(rawVideoPath)}?v=${importToken}`
    : null;

  const video = useClipVideoElement({
    clip,
    isVideoMode: isVideoPlayable,
    isHovered,
    gridPreview,
    staggerReady,
    showVideo: isVideoPlayable,
    shouldMountVideo,
    videoSrcUrl,
    effectiveSrc: source.effectiveSrc,
    originalPath: source.originalPath,
    videoIsHEVC,
    audioPlaybackHover: hoverAudioActive,
    playbackVolume,
    gridPreviewSpeed,
    resetKey,
    videoRef,
    setEffectiveSrc: source.setEffectiveSrc,
    ensurePreviewProxyPath: source.ensurePreviewProxyPath,
    proxyInFlightRef: source.proxyInFlightRef,
    restartPlayback: source.restartPlayback,
    startTime: seekIntoSource ? clip.startSec : undefined,
    endTime: seekIntoSource ? clip.endSec : undefined,
  });

  const { tone: downloadTone, sample: sampleDownloadTone } = useDownloadTone();

  // all thumbnail and animated-WebP state lives in this hook
  const webp = useWebpPreview({
    clip,
    index,
    importToken,
    isVisible,
    isHovered,
    videoPreviewMode,
    isVideoMode: isVideoPlayable,
    episodeId,
    previewWebpPath,
    reportWebpDemand,
  });

  // gated on visibility: WebP mode forces preview-all, and animating every clip kills the renderer
  const shouldShowWebpOverlay = webp.hasAnimatedWebp && (isHovered || (gridPreview && isVisible));
  // the static layer falls back to the animated file until its jpeg exists, only safe near the viewport
  const webpStaticReady = Boolean(webp.webpThumbnail) || !webp.hasAnimatedWebp;

  const shouldShowThumbnail = !shouldMountVideo || !video.isVideoReady;
  // a video-mode clip not cut yet shows a skeleton until clip_ready
  const videoClipPending =
    videoPreviewMode &&
    !isVideoPlayable &&
    clip.clipMode !== "failed" &&
    clip.thumbnailReady !== true;
  const showTileLoadingOverlay = isVideoPlayable
    ? clip.thumbnailReady === false || videoThumbFailed
    : clip.thumbnailReady === false || !webp.thumbnailLoaded || webp.thumbnailFailed;

  // separates on-screen tiles from overscan rows, scoped to the scroll container
  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    const root = el.closest(".clips-container") as HTMLElement | null;
    const observer = new IntersectionObserver(
      ([entry]) => {
        // a 0x0 rect means an ancestor went display:none, not a scroll-off
        const rect = entry.boundingClientRect;
        if (rect.width === 0 && rect.height === 0) return;
        setIsVisible(entry.isIntersecting);
      },
      { root, rootMargin: "300px", threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!showDownloadButton) return;
    const img = thumbnailRef.current;
    if (img?.complete) sampleDownloadTone(img);
  }, [webp.displayThumbnailPath, importToken, showDownloadButton, sampleDownloadTone]);

  // a cached image can finish before onLoad attaches, so the complete case is caught when the ref attaches
  const setThumbnailEl = useCallback(
    (el: HTMLImageElement | null) => {
      thumbnailRef.current = el;
      if (!el) return;
      if (el.complete && el.naturalWidth > 0) {
        webp.setThumbnailLoaded(true);
        if (showDownloadButton) sampleDownloadTone(el);
      }
    },
    [webp.setThumbnailLoaded, showDownloadButton, sampleDownloadTone]
  );

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (clip.thumbnailReady === false) return;
      onClipClick(clip.id, clip.src, index, e);
    },
    [clip.id, clip.src, clip.thumbnailReady, index, onClipClick]
  );

  const handleDoubleClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (clip.thumbnailReady === false) return;
      onClipDoubleClick(clip.id, clip.src, index, e);
    },
    [clip.id, clip.src, clip.thumbnailReady, index, onClipDoubleClick]
  );

  const beginHover = () => {
    // the IntersectionObserver can lag a tick; hovering must mount immediately
    setIsVisible(true);
    setIsHovered(true);
    setControlsMounted(true);
    // a tile whose poster gave up gets another chance on interaction
    if (videoThumbFailed) {
      setVideoThumbFailed(false);
      setVideoThumbRetry(0);
    }
  };

  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    // adding to a pack is a right-click on home; the Scenepacks page has its own menu
    if (activePage === "home" && scenepacksEnabled) {
      e.preventDefault();
      e.stopPropagation();
      useContextMenuStore.getState().openContextMenu("clip-scenepack-picker");
      // right-clicking part of a selection adds all of it, in grid order; anything else adds just this clip
      const { selectedClips, clips } = useAppStateStore.getState();
      setScenepackTargets(
        selectedClips.has(clip.id) && selectedClips.size > 1 ? clips.filter((c) => selectedClips.has(c.id)) : [clip]
      );
      setScenepackMenu({ x: e.clientX, y: e.clientY });
      return;
    }
    onClipContextMenu?.(e, clip);
  };

  const stopDrag = (e: React.DragEvent | React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const isScout = activePage === "sceneScout";
  const scoutTooltip = isScout
    ? [
        clip.originalName,
        `Timeframe: ${formatClipTimeframe(clip.startSec, clip.endSec, true)}`,
        clip.score !== undefined ? formatScoreWithConfidence(clip.score) : null,
        clip.motion ? `Starts: ${describeMotion(clip.motion.start)}` : null,
        clip.motion ? `Ends: ${describeMotion(clip.motion.end)}` : null,
      ]
        .filter(Boolean)
        .join("\n")
    : undefined;

  return (
    <div
      ref={wrapperRef}
      className={`clip-wrapper ${isFocused ? "focused" : ""} ${isSelected ? "selected" : ""} ${dragOver ? "scenepack-drag-over" : ""} ${appearDelayMs !== null ? "clip-appear" : ""}`}
      style={appearDelayMs !== null ? { ["--appear-delay" as any]: `${appearDelayMs}ms` } : undefined}
      title={scoutTooltip}
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
      onContextMenu={handleContextMenu}
      draggable={activePage === "scenepacks"}
      onDragStart={(e) => {
        if (activePage !== "scenepacks") return;
        e.dataTransfer.setData("text/plain", String(clip.sceneIndex ?? index));
        e.dataTransfer.effectAllowed = "move";
      }}
      onDragOver={(e) => {
        if (activePage !== "scenepacks") return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        if (activePage !== "scenepacks") return;
        e.preventDefault();
        setDragOver(false);
        const fromIdx = Number(e.dataTransfer.getData("text/plain"));
        const toIdx = clip.sceneIndex ?? index;
        if (Number.isNaN(fromIdx) || fromIdx === toIdx) return;
        const spId = useScenepacksStore.getState().openedScenepackId;
        if (spId) useScenepacksStore.getState().reorderScenepackClips(spId, fromIdx, toIdx);
      }}
      onDragEnd={() => setDragOver(false)}
      onMouseEnter={() => {
        if (isGridScrolling()) {
          // still under the pointer once scrolling stops: hover then
          pendingHoverRef.current?.();
          pendingHoverRef.current = whenGridScrollSettles(() => {
            pendingHoverRef.current = null;
            if (wrapperRef.current?.matches(":hover")) beginHover();
          });
          return;
        }
        beginHover();
      }}
      onMouseLeave={() => {
        pendingHoverRef.current?.();
        pendingHoverRef.current = null;
        setIsHovered(false);
        video.resetOnLeave();
      }}
    >
      {(controlsMounted || isSelected) && (
        <Tooltip content={isSelected ? "Deselect clip" : "Select clip"}>
          <button
            className={`clip-selected ${isSelected ? "active" : ""}`}
            onClick={(e) => onToggleSelection(clip.id, e)}
            aria-label={isSelected ? "Deselect clip" : "Select clip"}
          >
            {isSelected ? <FaCheck /> : <FaPlus />}
          </button>
        </Tooltip>
      )}

      {videoClipPending ? (
        <div className="clip clip-skeleton" style={{ borderRadius: 15 }} />
      ) : (
        <>
          {/* webp mode static thumbnail; video mode uses the poster below instead */}
          {!isVideoPlayable &&
            !webp.thumbnailFailed &&
            clip.thumbnailReady !== false &&
            (webpStaticReady || isVisible) &&
            // no image yet (a webp episode has no posters): the skeleton shows until its webp is made
            Boolean(webp.webpThumbnail || webp.hasAnimatedWebp || webp.thumbnailSrc) && (
              <img
                ref={setThumbnailEl}
                className="clip"
                src={
                  webp.webpThumbnail ??
                  (webp.hasAnimatedWebp
                    ? mediaSrcVersioned(previewWebpPath!, importToken)
                    : mediaSrcVersioned(webp.thumbnailSrc, importToken))
                }
                style={{ opacity: shouldShowThumbnail ? 1 : 0 }}
                draggable={false}
                onLoad={(e) => {
                  webp.setThumbnailLoaded(true);
                  if (showDownloadButton) sampleDownloadTone(e.currentTarget);
                  predecode(e.currentTarget);
                }}
                onError={webp.handleThumbnailError}
                onDragStart={stopDrag}
              />
            )}

          {/* video mode poster: a still at rest, the <video> mounts only on hover */}
          {isVideoPlayable && clip.thumbnailReady !== false && !videoThumbFailed && imageThumbnail(clip.thumbnail) && (
            <img
              className="clip"
              onLoad={(e) => predecode(e.currentTarget)}
              src={`${mediaSrcVersioned(clip.thumbnail, importToken)}${videoThumbRetry > 0 ? `&r=${videoThumbRetry}` : ""}`}
              style={{ opacity: shouldShowThumbnail ? 1 : 0 }}
              draggable={false}
              onError={() => {
                // poster jpgs fail transiently on a full grid reload, so retry with a cache-buster
                setVideoThumbRetry((attempt) => {
                  if (attempt >= VIDEO_THUMB_MAX_RETRIES) {
                    setVideoThumbFailed(true);
                    return attempt;
                  }
                  return attempt + 1;
                });
              }}
              onDragStart={stopDrag}
            />
          )}

          {showTileLoadingOverlay && (
            <div
              className="clip clip-skeleton clip-thumb-loading-overlay"
              style={{ opacity: shouldShowThumbnail ? 1 : 0 }}
            />
          )}

          {shouldMountVideo && videoSrcUrl && (
            <video
              className="clip"
              src={videoSrcUrl}
              muted={!hoverAudioActive}
              loop={!seekIntoSource}
              autoPlay
              playsInline
              preload="metadata"
              ref={video.setVideoRef}
              style={{ position: "absolute", inset: 0 }}
              draggable={false}
              onDragStart={stopDrag}
              onLoadedMetadata={video.handleLoadedMetadata}
              onPlaying={(e) => video.requestFirstFrame(e.currentTarget)}
              onLoadedData={video.handleLoadedData}
              onTimeUpdate={video.handleTimeUpdate}
              onEnded={video.handleEnded}
              onError={video.handleError}
            />
          )}

          {shouldShowWebpOverlay && previewWebpPath && (
            <img
              className="clip"
              style={{ position: "absolute", inset: 0, objectFit: "cover", zIndex: 3 }}
              src={`${convertFileSrc(previewWebpPath)}?v=${importToken}`}
              draggable={false}
              onDragStart={stopDrag}
            />
          )}

          {isProcessing && (
            <div className="clip-status-overlay">
              <span className="status-text">{clip.originalName}</span>
            </div>
          )}

          {showClipDuration && (activePage === "home" || activePage === "sceneScout") && (() => {
            const dur = formatClipDuration(clip.startSec, clip.endSec);
            return dur ? <div className="clip-duration-badge">{dur}</div> : null;
          })()}

          {showClipTimestamps && clip.startSec !== undefined && (
            <div className={`clip-original-timestamp${showClipEndTime && clip.endSec !== undefined ? " is-timeframe" : ""}`}>
              {showClipEndTime && clip.endSec !== undefined
                ? formatClipTimeframe(clip.startSec, clip.endSec)
                : formatClipTime(clip.startSec)}
            </div>
          )}

          {showDownloadButton && controlsMounted && (
            <DownloadButton tone={downloadTone} onClick={() => onDownloadClip(clip)} />
          )}

          {scenepackMenu && (
            <ScenepackPickerMenu
              clip={clip}
              clips={scenepackTargets}
              episodeId={episodeId}
              anchor={scenepackMenu}
              onClose={() => setScenepackMenu(null)}
              onCreateNew={() => setShowScenepackModal(true)}
              onFindFlow={
                canFindFlowFrom(clip, activePage, sceneScoutEnabled)
                  ? () => {
                      const source = flowSourceForClip(clip);
                      if (source) void useSceneScoutStore.getState().startFlowSearch(source, { pick: true });
                    }
                  : undefined
              }
            />
          )}

          {activePage === "scenepacks" && (
            <Tooltip content="Remove from Scenepack">
              <button
                className="clip-remove-from-scenepack"
                onClick={(e) => {
                  e.stopPropagation();
                  const spId = useScenepacksStore.getState().openedScenepackId;
                  if (!spId) return;
                  // same path as the right-click menu, so removal and file cleanup stay in one place
                  void removeClipsFromScenepack(spId, [
                    { index: clip.sceneIndex ?? 0, clipPath: clip.clipPath },
                  ]);
                }}
                aria-label="Remove from Scenepack"
              >
                <FaTrashAlt />
              </button>
            </Tooltip>
          )}

          {showScenepackModal && (
            <AddToScenepackModal
              clips={scenepackTargets}
              episodeId={episodeId}
              onClose={() => setShowScenepackModal(false)}
            />
          )}
        </>
      )}
    </div>
  );
});
