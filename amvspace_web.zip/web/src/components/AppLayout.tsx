import React from "react";
import Sidebar from "./sidebar/Sidebar";
import Navbar from "./Navbar";
import { convertFileSrc } from "@tauri-apps/api/core";
import { isVideoBackgroundPath, useThemeSettingsStore } from "../stores/settingsStore";
import { useViewportAlignedDivider } from "../hooks/useViewportAlignedDivider";
import { useUIStateStore } from "../stores/UIStore";

export interface AppLayoutProps {
  windowWrapperRef: React.RefObject<HTMLDivElement | null>;
  sidebarEnabled: boolean;
  navbarProps: React.ComponentProps<typeof Navbar>;
  dividerProps: {
    onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
    sidebarWidthPx: number;
  };
  children: React.ReactNode;
  loadingOverlay?: React.ReactNode;
  isDragging: boolean;
}

export default function AppLayout({
  windowWrapperRef,
  sidebarEnabled,
  navbarProps,
  dividerProps,
  children,
  loadingOverlay,
  isDragging,
}: AppLayoutProps) {
  const backgroundMediaPath = useThemeSettingsStore((s) => s.backgroundImagePath);
  // Tools lights up its own drop zone, and a drop there never imports
  const toolsOpen = useUIStateStore((s) => s.toolsOpen);
  const alignDivider = useViewportAlignedDivider();
  const backgroundVideoSrc = React.useMemo(() => {
    if (!backgroundMediaPath || !isVideoBackgroundPath(backgroundMediaPath)) {
      return null;
    }

    const [cleanPath, query] = backgroundMediaPath.split("?");
    const src = convertFileSrc(cleanPath);
    return query ? `${src}?${query}` : src;
  }, [backgroundMediaPath]);

  return (
    <main className="app-root">
      {backgroundVideoSrc && (
        <video
          className="app-bg-video"
          src={backgroundVideoSrc}
          autoPlay
          muted
          loop
          playsInline
        />
      )}
      {loadingOverlay}
      {isDragging && !toolsOpen && (
        <div className="dragging-overlay">
          <h1>Drag file(s) here.</h1>
        </div>
      )}
      <div
        className="window-wrapper"
        ref={windowWrapperRef}
        style={{
          ["--amverge-sidebar-width" as any]: `${dividerProps.sidebarWidthPx}px`,
        }}
      >
        <Navbar {...navbarProps} />
        {/* One window-body for both states. Two sibling branches meant toggling
            the sidebar unmounted one subtree and mounted the other, remounting
            the whole page - the grid rebuilt every tile and replayed its
            entrance animation. Keeping content-wrapper in a fixed slot lets
            React reconcile it in place, so only the sidebar comes and goes. */}
        <div className="window-body">
          {sidebarEnabled ? <Sidebar /> : null}
          {/* stays when the sidebar is folded, parked at the left edge to drag it back out */}
          <div
            ref={alignDivider}
            className="divider sidebar-splitter"
            onPointerDown={dividerProps.onPointerDown}
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize sidebar"
            tabIndex={-1}
          />
          <div className="content-wrapper">
            {children}
          </div>
        </div>
      </div>
    </main>
  );
}
