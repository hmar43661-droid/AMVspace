'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface SiDavinciresolveIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function SiDavinciresolveIcon({ size = '1em', className, ...rest }: SiDavinciresolveIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "tick" : now) : now === "tick" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("press");
    const done = setTimeout(() => setPlaying('rest'), 540);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <motion.path initial="rest" animate={playing} d="M17.153 1 L6.479 1.004 C5.223 1.004 3.953 1.32 3.03 2.021 A4.515 4.515 0 0 0 1.555 3.857 C1.214 4.603 1 5.602 1 6.455 L1.011 17.638 C1.013 19.109 1.45 20.441 2.35 21.408 C3.252 22.376 4.607 22.951 6.32 22.958 L16.451 23 C17.606 23.005 19.288 22.967 20.396 22.346 C21.381 21.791 22.252 20.919 22.685 19.61 C22.939 18.84 23.001 17.7 23 16.725 L22.981 6.523 C22.979 5.709 22.843 4.668 22.479 3.833 C22.09 2.939 21.397 2.17 20.351 1.611 C19.657 1.238 18.529 1 17.153 1 Z M17.153 1.853 C18.416 1.853 19.479 2.123 19.939 2.37 C20.835 2.85 21.355 3.439 21.671 4.167 C21.96 4.828 22.102 5.811 22.104 6.525 L22.121 16.727 C22.123 17.656 22.032 18.796 21.848 19.349 C21.485 20.451 20.797 21.133 19.957 21.606 C19.21 22.025 17.562 22.149 16.455 22.145 L6.326 22.104 C4.807 22.098 3.73 21.615 3.002 20.834 C2.276 20.054 1.891 18.946 1.891 17.639 L1.916 6.454 C1.916 5.694 2.095 4.779 2.35 4.22 C2.667 3.526 3.038 3.114 3.602 2.686 C4.286 2.164 5.462 1.889 6.573 1.889 Z M11.964 4.99 C10.153 5.072 9.027 6.51 9.018 8.006 C9.035 9.329 10.517 11.197 11.662 12.159 C11.772 12.249 11.803 12.258 11.964 12.324 C12.021 12.346 12.146 12.28 12.264 12.2 C12.594 11.975 13.174 11.332 13.775 10.607 A7.031 7.031 0 0 0 14.72 9.064 C15.095 8.248 14.959 7.598 14.935 7.333 A3.651 3.651 0 0 0 14.028 5.782 A3.08 3.08 0 0 0 11.964 4.99 Z M15.789 12.252 A9.336 9.336 0 0 0 12.815 12.811 C12.677 12.864 12.577 12.903 12.472 12.967 C12.42 13 12.371 13.091 12.376 13.235 C12.391 13.632 12.642 14.406 12.948 15.316 C13.3 16.356 13.925 17.396 14.638 17.827 A2.961 2.961 0 0 0 16.957 18.141 C17.72 17.918 18.419 17.345 18.756 16.724 C19.66 15.057 18.93 13.471 17.728 12.675 C17.319 12.403 16.69 12.267 15.996 12.253 C15.928 12.253 15.858 12.251 15.789 12.252 Z M8.059 12.287 A5.684 5.684 0 0 0 7.37 12.33 C6.824 12.402 6.516 12.58 6.187 12.797 A2.912 2.912 0 0 0 4.936 14.612 C4.867 15.118 4.857 15.577 4.966 15.993 C5.363 17.266 6.182 18.03 7.576 18.241 C8.159 18.266 8.832 18.183 9.4 17.828 C10.564 17.111 11.307 14.922 11.611 13.481 C11.66 13.32 11.643 13.154 11.599 13.096 C11.595 13.035 11.559 12.993 11.425 12.929 C11.06 12.753 10.215 12.546 9.248 12.379 A7.04 7.04 0 0 0 8.059 12.287 Z" variants={{ rest: { scale: 1 }, tick: { scale: [1,0.95,1], transition: { scale: { duration: 0.24, times: [0,0.4,1], ease: ["easeOut", "easeOut"] } } }, press: { scale: [1,1.04,0.95,0.95,1], transition: { scale: { duration: 0.5, times: [0,0.0923,0.3,0.4514,1], ease: ["easeOut", "easeOut", "easeOut", "linear"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    </motion.svg>
  );
}


