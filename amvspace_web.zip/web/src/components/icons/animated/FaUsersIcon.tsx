'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface FaUsersIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaUsersIcon({ size = '1em', className, ...rest }: FaUsersIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "nod" : now) : now === "nod" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("answer");
    const done = setTimeout(() => setPlaying('rest'), 700);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <motion.path initial="rest" animate={playing} d="M4.3 10.9 C5.513 10.9 6.5 9.913 6.5 8.7 S5.513 6.5 4.3 6.5 S2.1 7.487 2.1 8.7 S3.087 10.9 4.3 10.9 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: 0, y: 0 }, answer: { x: [0,0,0,0,0], y: [0,0,3.24,0,0], transition: { x: { duration: 0.66, times: [0,0.4244,0.5022,0.6111,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.4244,0.5022,0.6111,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    <motion.path initial="rest" animate={playing} d="M19.7 10.9 C20.913 10.9 21.9 9.913 21.9 8.7 S20.913 6.5 19.7 6.5 S17.5 7.487 17.5 8.7 S18.487 10.9 19.7 10.9 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: 0, y: 0 }, answer: { x: [0,0,0,0,0], y: [0,0,3.24,0,0], transition: { x: { duration: 0.66, times: [0,0.6111,0.6889,0.7978,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.6111,0.6889,0.7978,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    <motion.path initial="rest" animate={playing} d="M20.8 12 H18.6 C17.995 12 17.448 12.244 17.05 12.639 C18.435 13.399 19.418 14.771 19.631 16.4 H21.9 C22.508 16.4 23 15.908 23 15.3 V14.2 C23 12.987 22.013 12 20.8 12 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: 0, y: 0 }, answer: { x: [0,0,0,0,0], y: [0,0,1.053,0,0], transition: { x: { duration: 0.66, times: [0,0.6889,0.7511,0.86,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.6889,0.7511,0.86,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    <motion.path initial="rest" animate={playing} d="M12 12 C14.128 12 15.85 10.278 15.85 8.15 S14.128 4.3 12 4.3 S8.15 6.022 8.15 8.15 S9.872 12 12 12 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: [0,0,0], y: [0,2.914,0], transition: { x: { duration: 0.3, times: [0,0.4,1], ease: ["easeOut", "easeInOut"] }, y: { duration: 0.3, times: [0,0.4,1], ease: ["easeOut", "easeInOut"] } } }, answer: { x: [0,0,0,0,0,0], y: [0,4.05,0,2.43,0,0], transition: { x: { duration: 0.66, times: [0,0.3,0.3933,0.4711,0.5644,1], ease: ["easeOut", "easeOut", "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.3,0.3933,0.4711,0.5644,1], ease: ["easeOut", "easeOut", "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    <motion.path initial="rest" animate={playing} d="M14.64 13.1 H14.355 C13.64 13.444 12.846 13.65 12 13.65 S10.364 13.444 9.645 13.1 H9.36 C7.174 13.1 5.4 14.874 5.4 17.06 V18.05 C5.4 18.961 6.139 19.7 7.05 19.7 H16.95 C17.861 19.7 18.6 18.961 18.6 18.05 V17.06 C18.6 14.874 16.826 13.1 14.64 13.1 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: 0, y: 0 }, answer: { x: [0,0,0,0,0], y: [0,0,1.215,0,0], transition: { x: { duration: 0.66, times: [0,0.3156,0.3778,0.4867,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.3156,0.3778,0.4867,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    <motion.path initial="rest" animate={playing} d="M6.95 12.639 C6.552 12.244 6.005 12 5.4 12 H3.2 C1.987 12 1 12.987 1 14.2 V15.3 C1 15.908 1.492 16.4 2.1 16.4 H4.365 C4.582 14.771 5.565 13.399 6.95 12.639 Z" variants={{ rest: { x: 0, y: 0 }, nod: { x: 0, y: 0 }, answer: { x: [0,0,0,0,0], y: [0,0,1.053,0,0], transition: { x: { duration: 0.66, times: [0,0.5022,0.5644,0.6733,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] }, y: { duration: 0.66, times: [0,0.5022,0.5644,0.6733,1], ease: [[0,0,1,1], "easeOut", "easeOut", "easeOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    </motion.svg>
  );
}


