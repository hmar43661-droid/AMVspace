'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface FaDiscordIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaDiscordIcon({ size = '1em', className, ...rest }: FaDiscordIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "tick" : now) : now === "tick" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("press");
    const done = setTimeout(() => setPlaying('rest'), 500);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <motion.path initial="rest" animate={playing} d="M19.031 5.601 A0.052 0.052 0 0 0 19.004 5.577 A16.674 16.674 0 0 0 14.89 4.301 A0.062 0.062 0 0 0 14.824 4.332 A11.6 11.6 0 0 0 14.312 5.384 A15.395 15.395 0 0 0 9.691 5.384 A10.64 10.64 0 0 0 9.171 4.332 A0.065 0.065 0 0 0 9.105 4.301 A16.627 16.627 0 0 0 4.99 5.577 A0.059 0.059 0 0 0 4.963 5.6 C2.343 9.513 1.625 13.33 1.977 17.1 A0.069 0.069 0 0 0 2.004 17.147 A16.764 16.764 0 0 0 7.051 19.697 A0.065 0.065 0 0 0 7.122 19.674 A11.969 11.969 0 0 0 8.154 17.995 A0.064 0.064 0 0 0 8.119 17.906 A11.04 11.04 0 0 1 6.542 17.155 A0.065 0.065 0 0 1 6.536 17.047 C6.642 16.968 6.748 16.885 6.849 16.802 A0.063 0.063 0 0 1 6.914 16.793 C10.222 18.303 13.804 18.303 17.072 16.793 A0.062 0.062 0 0 1 17.138 16.801 C17.24 16.885 17.346 16.968 17.452 17.047 A0.065 0.065 0 0 1 17.447 17.155 A10.361 10.361 0 0 1 15.869 17.905 A0.064 0.064 0 0 0 15.835 17.995 A13.443 13.443 0 0 0 16.867 19.673 A0.064 0.064 0 0 0 16.938 19.697 A16.708 16.708 0 0 0 21.993 17.147 A0.065 0.065 0 0 0 22.019 17.1 C22.441 12.742 21.313 8.957 19.031 5.601 Z M8.648 14.804 C7.652 14.804 6.832 13.89 6.832 12.768 S7.636 10.732 8.648 10.732 C9.668 10.732 10.481 11.653 10.465 12.768 C10.465 13.89 9.66 14.804 8.648 14.804 Z M15.364 14.804 C14.368 14.804 13.548 13.89 13.548 12.768 S14.353 10.732 15.364 10.732 C16.384 10.732 17.197 11.653 17.181 12.768 C17.181 13.89 16.384 14.804 15.364 14.804 Z" variants={{ rest: { scale: 1 }, tick: { scale: [1,0.95,1], transition: { scale: { duration: 0.22, times: [0,0.4,1], ease: ["easeOut", "easeOut"] } } }, press: { scale: [1,1.04,0.95,0.95,1], transition: { scale: { duration: 0.46, times: [0,0.1003,0.3261,0.4718,1], ease: ["easeOut", "easeOut", "easeOut", "linear"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    </motion.svg>
  );
}


