'use client';

import { motion } from 'motion/react';
import type { SVGProps } from 'react';

export interface FaSpinnerIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaSpinnerIcon({ size = '1em', className, ...rest }: FaSpinnerIconProps) {
  return (
    <motion.svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate="turn"
    >
    <motion.g variants={{ rest: { rotate: 0 }, turn: { rotate: [0,360], transition: { rotate: { duration: 1, times: [0,1], ease: ["linear"], repeat: Infinity } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }}>
      <path d="M14.062 3.062 C14.062 4.202 13.139 5.125 12 5.125 S9.938 4.202 9.938 3.062 S10.861 1 12 1 S14.062 1.923 14.062 3.062 Z" />
      <path d="M12 18.875 C10.861 18.875 9.938 19.798 9.938 20.938 S10.861 23 12 23 S14.062 22.077 14.062 20.938 S13.139 18.875 12 18.875 Z" />
      <path d="M20.938 9.938 C19.798 9.938 18.875 10.861 18.875 12 S19.798 14.062 20.938 14.062 S23 13.139 23 12 S22.077 9.938 20.938 9.938 Z" />
      <path d="M5.125 12 C5.125 10.861 4.202 9.938 3.062 9.938 S1 10.861 1 12 S1.923 14.062 3.062 14.062 S5.125 13.139 5.125 12 Z" />
      <path d="M5.68 16.257 C4.541 16.257 3.618 17.181 3.618 18.32 S4.541 20.382 5.68 20.382 S7.743 19.459 7.743 18.32 C7.743 17.181 6.819 16.257 5.68 16.257 Z" />
      <path d="M18.32 16.257 C17.181 16.257 16.257 17.181 16.257 18.32 S17.181 20.382 18.32 20.382 S20.382 19.459 20.382 18.32 C20.382 17.181 19.459 16.257 18.32 16.257 Z" />
      <path d="M5.68 3.618 C4.541 3.618 3.618 4.541 3.618 5.68 S4.541 7.743 5.68 7.743 S7.743 6.819 7.743 5.68 S6.819 3.618 5.68 3.618 Z" />
    </motion.g>
    </motion.svg>
  );
}


