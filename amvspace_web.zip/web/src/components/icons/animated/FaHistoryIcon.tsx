'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface FaHistoryIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaHistoryIcon({ size = '1em', className, ...rest }: FaHistoryIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "wind" : now) : now === "wind" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("rewind");
    const done = setTimeout(() => setPlaying('rest'), 990);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <path d="M22.656 11.98 C22.667 17.851 17.879 22.652 12.008 22.656 C9.472 22.658 7.143 21.774 5.312 20.297 C4.836 19.913 4.801 19.199 5.233 18.767 L5.717 18.283 C6.087 17.913 6.678 17.872 7.088 18.197 C8.436 19.268 10.143 19.906 12 19.906 C16.37 19.906 19.906 16.369 19.906 12 C19.906 7.63 16.369 4.094 12 4.094 C9.903 4.094 7.998 4.909 6.583 6.239 L8.764 8.42 C9.197 8.853 8.89 9.594 8.278 9.594 H2.031 C1.652 9.594 1.344 9.286 1.344 8.906 V2.66 C1.344 2.047 2.084 1.741 2.517 2.174 L4.639 4.295 C6.552 2.467 9.145 1.344 12 1.344 C17.879 1.344 22.645 6.104 22.656 11.98 Z" />
    <motion.path initial="rest" animate={playing} d="M14.883 15.365 L15.305 14.822 C15.654 14.373 15.573 13.725 15.124 13.375 L13.375 12.015 V7.531 C13.375 6.962 12.913 6.5 12.344 6.5 H11.656 C11.087 6.5 10.625 6.962 10.625 7.531 V13.36 L13.436 15.546 C13.885 15.896 14.533 15.815 14.883 15.365 Z" variants={{ rest: { rotate: 0 }, wind: { rotate: [0,-25.29,0], transition: { rotate: { duration: 0.32, times: [0,0.45,1], ease: ["easeInOut", "easeInOut"] } } }, rewind: { rotate: [0,-360], transition: { rotate: { duration: 0.95, times: [0,1], ease: ["easeInOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    </motion.svg>
  );
}


