'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface FaGithubIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaGithubIcon({ size = '1em', className, ...rest }: FaGithubIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "tick" : now) : now === "tick" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("press");
    const done = setTimeout(() => setPlaying('rest'), 500);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <motion.g initial="rest" animate={playing} variants={{ rest: { scale: 1 }, tick: { scale: [1,0.95,1], transition: { scale: { duration: 0.22, times: [0,0.4,1], ease: ["easeOut", "easeOut"] } } }, press: { scale: [1,1.04,0.95,0.95,1], transition: { scale: { duration: 0.46, times: [0,0.1003,0.3261,0.4718,1], ease: ["easeOut", "easeOut", "easeOut", "linear"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }}>
      <path d="M8.472 18.076 C8.472 18.162 8.373 18.23 8.249 18.23 C8.107 18.243 8.008 18.175 8.008 18.076 C8.008 17.99 8.107 17.921 8.232 17.921 C8.361 17.908 8.472 17.977 8.472 18.076 Z" />
      <path d="M7.136 17.882 C7.106 17.968 7.192 18.067 7.321 18.093 C7.432 18.136 7.561 18.093 7.587 18.007 S7.531 17.822 7.402 17.784 C7.291 17.754 7.166 17.796 7.136 17.882 Z" />
      <path d="M9.035 17.809 C8.911 17.839 8.825 17.921 8.838 18.02 C8.85 18.106 8.962 18.162 9.091 18.132 C9.216 18.102 9.302 18.02 9.289 17.934 C9.276 17.852 9.16 17.796 9.035 17.809 Z" />
      <path d="M11.863 1.344 C5.903 1.344 1.344 5.868 1.344 11.828 C1.344 16.593 4.343 20.671 8.627 22.106 C9.177 22.205 9.37 21.866 9.37 21.586 C9.37 21.32 9.357 19.85 9.357 18.948 C9.357 18.948 6.35 19.593 5.718 17.668 C5.718 17.668 5.228 16.417 4.523 16.095 C4.523 16.095 3.539 15.42 4.592 15.433 C4.592 15.433 5.662 15.519 6.251 16.542 C7.192 18.2 8.769 17.723 9.383 17.44 C9.482 16.752 9.761 16.275 10.071 15.992 C7.669 15.725 5.245 15.377 5.245 11.244 C5.245 10.062 5.572 9.469 6.259 8.713 C6.148 8.434 5.782 7.282 6.371 5.795 C7.269 5.516 9.336 6.955 9.336 6.955 C10.195 6.715 11.119 6.59 12.034 6.59 S13.873 6.715 14.733 6.955 C14.733 6.955 16.8 5.512 17.698 5.795 C18.286 7.286 17.921 8.434 17.809 8.713 C18.497 9.473 18.918 10.066 18.918 11.244 C18.918 15.39 16.387 15.721 13.985 15.992 C14.38 16.331 14.716 16.976 14.716 17.986 C14.716 19.434 14.703 21.225 14.703 21.578 C14.703 21.857 14.9 22.196 15.446 22.098 C19.743 20.671 22.656 16.593 22.656 11.828 C22.656 5.868 17.822 1.344 11.863 1.344 Z M5.52 16.164 C5.464 16.207 5.477 16.305 5.55 16.387 C5.619 16.456 5.718 16.486 5.774 16.43 C5.83 16.387 5.817 16.288 5.744 16.207 C5.675 16.138 5.576 16.108 5.52 16.164 Z M5.056 15.816 C5.026 15.871 5.069 15.94 5.155 15.983 C5.224 16.026 5.31 16.013 5.34 15.953 C5.37 15.897 5.327 15.829 5.241 15.786 C5.155 15.76 5.086 15.773 5.056 15.816 Z M6.448 17.345 C6.38 17.401 6.405 17.53 6.504 17.612 C6.603 17.711 6.728 17.723 6.784 17.655 C6.839 17.599 6.814 17.47 6.728 17.388 C6.633 17.289 6.504 17.277 6.448 17.345 Z M5.959 16.714 C5.89 16.757 5.89 16.868 5.959 16.967 C6.027 17.066 6.143 17.109 6.199 17.066 C6.268 17.01 6.268 16.898 6.199 16.8 C6.139 16.701 6.027 16.658 5.959 16.714 Z" />
    </motion.g>
    </motion.svg>
  );
}


