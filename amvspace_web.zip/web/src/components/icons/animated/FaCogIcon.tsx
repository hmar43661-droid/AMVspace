'use client';

import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import { useIconHost } from './useIconHost';

export interface FaCogIconProps extends Omit<SVGProps<SVGSVGElement>, 'ref'> {
  size?: number | string;
  className?: string;
}

export function FaCogIcon({ size = '1em', className, ...rest }: FaCogIconProps) {
  const [playing, setPlaying] = useState<string>("rest");
  const hostRef = useRef<SVGSVGElement>(null);
  const { hovered, tapped } = useIconHost(hostRef);
  useEffect(() => {
    setPlaying((now) => (hovered ? (now === "rest" ? "tooth" : now) : now === "tooth" ? "rest" : now));
  }, [hovered]);
  useEffect(() => {
    if (!tapped) return;
    setPlaying("turn");
    const done = setTimeout(() => setPlaying('rest'), 740);
    return () => clearTimeout(done);
  }, [tapped]);
  return (
    <motion.svg
      ref={hostRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      {...(rest as object)}
      fill="currentColor" stroke="none" strokeWidth={0} strokeLinecap="round" strokeLinejoin="round"
      initial="rest"
      animate={playing}
    >
    <motion.path initial="rest" animate={playing} d="M21.943 14.565 L20.113 13.508 C20.297 12.511 20.297 11.489 20.113 10.492 L21.943 9.435 C22.154 9.314 22.248 9.065 22.179 8.833 C21.702 7.304 20.89 5.92 19.829 4.768 C19.666 4.592 19.399 4.549 19.193 4.67 L17.363 5.727 C16.593 5.065 15.708 4.554 14.75 4.218 V2.109 C14.75 1.868 14.582 1.657 14.346 1.606 C12.769 1.254 11.154 1.271 9.654 1.606 C9.418 1.657 9.25 1.868 9.25 2.109 V4.223 C8.296 4.562 7.411 5.073 6.637 5.731 L4.811 4.674 C4.601 4.554 4.339 4.592 4.175 4.773 C3.114 5.92 2.302 7.304 1.825 8.838 C1.752 9.07 1.851 9.319 2.061 9.439 L3.892 10.496 C3.707 11.493 3.707 12.516 3.892 13.512 L2.061 14.57 C1.851 14.69 1.756 14.939 1.825 15.171 C2.302 16.701 3.114 18.084 4.175 19.236 C4.339 19.412 4.605 19.455 4.811 19.335 L6.642 18.278 C7.411 18.939 8.296 19.451 9.254 19.786 V21.9 C9.254 22.141 9.422 22.351 9.658 22.403 C11.235 22.755 12.851 22.738 14.35 22.403 C14.587 22.351 14.754 22.141 14.754 21.9 V19.786 C15.708 19.446 16.593 18.935 17.367 18.278 L19.197 19.335 C19.408 19.455 19.67 19.416 19.833 19.236 C20.895 18.089 21.707 16.705 22.184 15.171 C22.248 14.935 22.154 14.686 21.943 14.565 Z M12 15.438 C10.105 15.438 8.562 13.895 8.562 12 S10.105 8.562 12 8.562 S15.438 10.105 15.438 12 S13.895 15.438 12 15.438 Z" variants={{ rest: { rotate: 0 }, turn: { rotate: [0,-6,180], transition: { rotate: { duration: 0.7, times: [0,0.08,1], ease: ["easeOut", "easeInOut"] } } }, tooth: { rotate: [0,12,0], transition: { rotate: { duration: 0.32, times: [0,0.45,1], ease: ["easeInOut", "easeInOut"] } } } }} style={{ transformBox: 'view-box', originX: '12px', originY: '12px' }} />
    </motion.svg>
  );
}


