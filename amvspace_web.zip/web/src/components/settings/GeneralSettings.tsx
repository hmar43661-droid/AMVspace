import {
  PreviewTranscodeMode,
  SceneDetectionMethod,
  useGeneralSettingsStore,
} from "../../stores/settingsStore";
import { useAppStateStore } from "../../stores/appStore";
import { useUIStateStore } from "../../stores/UIStore";
import { useEffect, useState } from "react";
import SettingRow from "../common/SettingRow";
import Dropdown from "../common/Dropdown";
import SettingsSection from "../common/SettingsSection";
import InfoButton from "../common/InfoButton";
import Tooltip from "../common/Tooltip";
import { useAiDepsStore } from "../../stores/aiDepsStore";
import { isPackInstalled } from "../../features/aiDeps/packs";
import { runningProcess } from "../../features/processes/singleProcess";
import {
  PREVIEW_METHOD_OPTIONS,
  PREVIEW_TRANSCODE_MODE_OPTIONS,
  PREVIEW_TRANSCODE_QUALITY_OPTIONS,
  sceneDetectionOptions,
} from "./general/options";
import { ConfirmModal } from "./general/ConfirmModal";
import { useDavinciInstalled } from "../../features/davinci/useDavinciAvailable";

type GeneralSettingsProps = {
  onGeneralSettingsReset: () => void;
};

export default function GeneralSettings({
  onGeneralSettingsReset,
}: GeneralSettingsProps) {
  const generalSettings = useGeneralSettingsStore();
  const setGeneralSettings = useGeneralSettingsStore.setState;
  const setSceneDetectionMethod = useGeneralSettingsStore((s) => s.setSceneDetectionMethod);
  const setImportMethod = useGeneralSettingsStore((s) => s.setImportMethod);
  const setPreviewTranscodeMode = useGeneralSettingsStore((s) => s.setPreviewTranscodeMode);
  const setPreviewTranscodeQuality = useGeneralSettingsStore((s) => s.setPreviewTranscodeQuality);
  const userHasHEVC = useAppStateStore((s) => s.userHasHEVC);
  const hevcForced = !userHasHEVC;
  const effectivePreviewTranscodeMode: PreviewTranscodeMode =
    hevcForced && generalSettings.previewTranscodeMode === "off"
      ? "hevc"
      : generalSettings.previewTranscodeMode;
  const setGridPreview = useUIStateStore((s) => s.setGridPreview);
  const davinciInstalled = useDavinciInstalled();
  const [showFactoryResetConfirm, setShowFactoryResetConfirm] = useState(false);
  const isMac = navigator.userAgent.includes("Mac OS X");
  const isLinux = navigator.userAgent.includes("Linux");
  const storageLocationName = isMac ? "Application Support" : isLinux ? "~/.local/share" : "AppData";
  const factoryResetConfirmation =
    `This will restore AMVspace to its default settings and move your episode storage folder back to ${storageLocationName}. Any custom settings or storage location changes you made will be reset.`;

  // TransNetV2 needs the `ml` pack, so the install is offered when it is chosen
  const aiStatus = useAiDepsStore((s) => s.status);
  const mlInstalled = isPackInstalled(aiStatus, "ml");
  const aiDepsBusy = useAiDepsStore((s) => s.stage === "installing");
  // a running import has nelux loaded, so swapping it underneath fails or breaks the episode
  const importRunning = useAppStateStore(() => runningProcess() === "import");

  useEffect(() => {
    if (!useAiDepsStore.getState().status) void useAiDepsStore.getState().refresh();
  }, []);

  const handleSceneDetectionChange = async (method: SceneDetectionMethod) => {
    if (method === "transnetv2_gpu") {
      if (!mlInstalled) {
        const installed = await useAiDepsStore.getState().ensurePack("ml");
        if (!installed) return; // declined, keep the current method
      }
      if (!generalSettings.aiSceneDetectionEnabled) {
        useGeneralSettingsStore.setState({ aiSceneDetectionEnabled: true });
      }
    }
    setSceneDetectionMethod(method);
  };

  return (
    <section className="panel menu-panel settings-panel">
      <h3>General</h3>
      <div className="about-content">
        <SettingRow
          label="Application Version"
          description=""
          control={
          <div className="settings-control">
            <span className="settings-value" style={{ width: "auto" }}>
              v2.0.2
            </span>
          </div>
          }
        />

        <SettingsSection id="general.import" title="Import">
          <SettingRow
            label="Scene Detection Method"
            description="How AMVspace finds scene cuts when you import."
            tourTarget="scene-detection"
            info={
              <InfoButton title="Scene Detection Method">
                <h4>AI Scene Detection</h4>
                <p>
                  Runs every frame of the episode through TransNetV2, a neural network
                  trained to spot the moment one shot ends and the next begins. It is the
                  most accurate option and catches cuts that other methods miss.
                </p>
                <p>
                  It is also the slowest, because the whole episode has to be decoded and
                  looked at frame by frame. A GPU makes this much faster.
                </p>
                <p>
                  After detection, AMVspace re-encodes the AI scene previews. This makes every
                  clip start exactly where the AI found the shot change instead of a moment
                  early or late.
                </p>

                <h4>Keyframe Detection</h4>
                <p>
                  A video file does not store a full picture for every frame. Every so often
                  it saves a complete one, called a keyframe, and the frames after it only
                  store what changed since. Those complete pictures are the only places a
                  video can be cut without rebuilding it.
                </p>
                <p>
                  This method cuts at those points only, so it is instant and
                  works on any PC with no GPU needed. It is by far the fastest way to import.
                </p>
                <p>
                  The tradeoff is accuracy. Cuts land on the nearest keyframe rather than the
                  exact shot change, so a clip can start slightly early or late, and shot
                  changes that happen between keyframes are missed entirely. This was the traditional method on launch of AMVspace.
                </p>
              </InfoButton>
            }
            control={
              <Dropdown
                className="settings-wide-dropdown"
                options={sceneDetectionOptions(generalSettings.aiSceneDetectionEnabled && mlInstalled)}
                value={generalSettings.sceneDetectionMethod}
                onChange={(method) => void handleSceneDetectionChange(method)}
              />
            }
          />

          {/* only once AI Scene Detection is installed and on, since only it decodes this way */}
          {generalSettings.aiSceneDetectionEnabled && mlInstalled && (
            <SettingRow
              label="GPU Decoding"
              description={
                !aiStatus?.managed
                  ? "Dev build: install nelux into the CLI checkout's venv instead."
                  : aiStatus.gpuDecodeSupported
                    ? "Decode video on the NVIDIA GPU during AI Scene Detection. Much faster on long episodes."
                    : "Needs an NVIDIA GTX 16-series, RTX 20-series or newer GPU."
              }
              control={
                <Tooltip content="Setting disabled while imports are running" disabled={!importRunning}>
                  {/* a disabled button gets no hover events, so the span carries the tooltip */}
                  <span style={{ display: "inline-flex" }}>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={Boolean(aiStatus?.gpuDecodeInstalled)}
                      aria-label="GPU Decoding"
                      className="aid-switch"
                      disabled={!aiStatus?.managed || !aiStatus.gpuDecodeSupported || aiDepsBusy || importRunning}
                      onClick={() => void useAiDepsStore.getState().setGpuDecode(!aiStatus?.gpuDecodeInstalled)}
                    />
                  </span>
                </Tooltip>
              }
            />
          )}
        </SettingsSection>

        <SettingsSection id="general.preview" title="Preview & Playback">
        <SettingRow
          label="Preview Method"
          description="What the grid plays when you hover over a clip."
          tourTarget="preview-method"
          info={
            <InfoButton title="Preview Method">
              <h4>Video Files</h4>
              <p>
                Cuts a real video clip for every scene. Hovering a tile plays the actual
                video, so what you see is exactly what you get when you export (unless you lower the preview quality).
              </p>
              <p>
                Each tile that plays is an actual video being decoded, so a long episode with
                hundreds of scenes can be demanding.
              </p>

              <h4>WebP Files</h4>
              <p>
                Builds a small animated preview for each scene instead, sorta similar to a GIF.
                They are far lighter than video, so scrolling and hovering stay smooth even
                with hundreds of scenes. If the app feels slow, this is the option to pick.
              </p>
              <p>
                The cost is import time. Every preview has to be made up front, so importing
                takes noticeably longer than it does with video files.
              </p>
              <p>
                This only changes what you preview in the grid. Exports are always cut from
                the original episode video, so your exported clips are full quality either
                way.
              </p>
            </InfoButton>
          }
          control={
            <Dropdown
              className="settings-wide-dropdown"
              options={PREVIEW_METHOD_OPTIONS}
              value={generalSettings.importMethod}
              onChange={(nextMethod) => {
                setImportMethod(nextMethod);
                if (nextMethod === "webp_files") {
                  setGridPreview(true);
                }
              }}
            />
          }
        />

        <SettingRow
          label="Re-encode Previews"
          description={
            hevcForced
              ? "This PC can't play HEVC, so those previews have to be re-encoded."
              : "Re-encode previews for smoother playback and HEVC support."
          }
          control={
            <Dropdown
              className="settings-wide-dropdown"
              options={
                hevcForced
                  ? PREVIEW_TRANSCODE_MODE_OPTIONS.filter((option) => option.value !== "off")
                  : PREVIEW_TRANSCODE_MODE_OPTIONS
              }
              value={effectivePreviewTranscodeMode}
              onChange={(mode) => setPreviewTranscodeMode(mode)}
            />
          }
        />

        {effectivePreviewTranscodeMode !== "off" && (
          <SettingRow
            label="Preview Quality"
            description="Resolution for re-encoded previews. Audio and timing are kept."
            control={
              <Dropdown
                className="settings-wide-dropdown"
                options={PREVIEW_TRANSCODE_QUALITY_OPTIONS}
                value={generalSettings.previewTranscodeQuality}
                onChange={(quality) => setPreviewTranscodeQuality(quality)}
              />
            }
          />
        )}
      
        <SettingRow
          label="Audio Playback Hover"
          description="Play a clip's audio when you hover over it."
          control={
            <div className="settings-control">
              <label className="custom-checkbox">
                <input
                  type="checkbox"
                  className="checkbox"
                  checked={generalSettings.audioPlaybackHover}
                  onChange={(e) =>
                    setGeneralSettings((prev) => ({
                      ...prev,
                      audioPlaybackHover: e.target.checked,
                    }))
                  }
                />
                <span className="checkmark"></span>
              </label>
            </div>
          }
        />

        <SettingRow
          label="Playback Volume"
          description="Master volume for clip previews and playback."
          control={
            <div className="settings-control">
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={generalSettings.playbackVolume}
                onChange={(e) =>
                  setGeneralSettings((prev) => ({
                    ...prev,
                    playbackVolume: parseFloat(e.target.value),
                  }))
                }
              />
              <span className="settings-value">
                {Math.round(generalSettings.playbackVolume * 100)}%
              </span>
            </div>
          }
        />
        </SettingsSection>

        {/* scenepacks and the other major features moved to Settings > Features */}
        {/* only Resolve lives here, so the section shows only where Resolve is installed */}
        {davinciInstalled && (
        <SettingsSection id="general.integrations" title="Integrations">
        <SettingRow
          label="DaVinci Resolve Compatibility"
          description="Send exported clips straight to the DaVinci Resolve timeline (Studio only)."
          control={
            <div className="settings-control">
              <label className="custom-checkbox">
                <input
                  type="checkbox"
                  className="checkbox"
                  checked={generalSettings.davinciResolveEnabled}
                  onChange={(e) =>
                    setGeneralSettings((prev) => ({
                      ...prev,
                      davinciResolveEnabled: e.target.checked,
                    }))
                  }
                />
                <span className="checkmark"></span>
              </label>
            </div>
          }
        />
        </SettingsSection>
        )}

        <SettingsSection id="general.maintenance" title="Maintenance">
        <SettingRow
          label="Factory Reset"
          description="Puts every General setting back to its default."
          control={
            <div className="settings-control">
              <button
                className="buttons emergency"
                onClick={() => {
                  setShowFactoryResetConfirm(true);
                }}
                style={{ width: "auto", padding: "0 16px", marginBottom: 0, color: "red" }}
              >
                Reset to Defaults
              </button>
            </div>
          }
        />
        </SettingsSection>

        {showFactoryResetConfirm && (
          <ConfirmModal
            title="Factory Reset"
            message={factoryResetConfirmation}
            confirmLabel="Reset"
            onClose={() => setShowFactoryResetConfirm(false)}
            onConfirm={() => {
              setShowFactoryResetConfirm(false);
              void onGeneralSettingsReset();
            }}
          />
        )}
      </div>
    </section>
  );
}
