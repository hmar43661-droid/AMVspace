import type { ReactNode } from "react";
import { FaChevronDown } from '../icons/animated';
import { useSettingsSectionsStore } from "../../stores/settingsSectionsStore";

type SettingsSectionProps = {
  id: string;
  title: string;
  children: ReactNode;
  tourTarget?: string;
};

export default function SettingsSection({
  id,
  title,
  children,
  tourTarget,
}: SettingsSectionProps) {
  // open unless the user collapsed it; the store only records sections they toggled
  const open = useSettingsSectionsStore((state) => state.openSections[id] ?? true);
  const setSectionOpen = useSettingsSectionsStore((state) => state.setSectionOpen);

  return (
    <div className={`settings-collapsible${open ? " is-open" : ""}`} data-getting-started={tourTarget}>
      <button
        type="button"
        className="settings-collapsible-header"
        onClick={() => setSectionOpen(id, !open)}
        aria-expanded={open}
      >
        <span className="settings-collapsible-title">{title}</span>
        <FaChevronDown className="settings-collapsible-chevron" aria-hidden="true" />
      </button>
      {open ? <div className="settings-collapsible-body">{children}</div> : null}
    </div>
  );
}
