import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { FaInfo, FaTimes } from '../icons/animated';

import Tooltip from "./Tooltip";
import { useEscapeToClose } from "./useEscapeToClose";

type InfoButtonProps = {
  title: string;
  children: ReactNode;
  /** "toolbar" sizes it like the toolbar buttons beside it (rounded square, accent border) */
  variant?: "inline" | "toolbar";
};

/** small "i" beside a setting label that opens a short explainer */
export default function InfoButton({ title, children, variant = "inline" }: InfoButtonProps) {
  const [open, setOpen] = useState(false);

  useEscapeToClose(() => setOpen(false), open);

  return (
    <>
      <Tooltip content={`About ${title}`}>
        <button
          type="button"
          className={variant === "toolbar" ? "info-button toolbar-info-button" : "info-button"}
          onClick={() => setOpen(true)}
          aria-label={`About ${title}`}
        >
          <FaInfo aria-hidden="true" />
        </button>
      </Tooltip>

      {/* portalled to <body>: inside a blurred or animated panel "fixed" pins to that panel and scrolls with it */}
      {open && createPortal(
        <div
          className="info-modal-overlay"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
        >
          <div className="info-modal" role="dialog" aria-modal="true" aria-label={title}>
            <div className="info-modal-head">
              <h3 className="info-modal-title">{title}</h3>
              <Tooltip content="Close">
                <button
                  type="button"
                  className="info-modal-close"
                  onClick={() => setOpen(false)}
                  aria-label="Close"
                >
                  <FaTimes aria-hidden="true" />
                </button>
              </Tooltip>
            </div>
            <div className="info-modal-body">{children}</div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}
