import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

const shim = (f: string) => fileURLToPath(new URL(`./src/shim/${f}`, import.meta.url));

export default defineConfig({
  plugins: [react()],
  base: "./",
  resolve: {
    alias: [
      { find: "@tauri-apps/api/core", replacement: shim("core.ts") },
      { find: "@tauri-apps/api/event", replacement: shim("event.ts") },
      { find: "@tauri-apps/api/window", replacement: shim("window.ts") },
      { find: "@tauri-apps/api/webview", replacement: shim("webview.ts") },
      { find: "@tauri-apps/api/app", replacement: shim("app.ts") },
      { find: "@tauri-apps/api/dpi", replacement: shim("dpi.ts") },
      { find: "@tauri-apps/plugin-dialog", replacement: shim("dialog.ts") },
      { find: "@tauri-apps/plugin-shell", replacement: shim("shell.ts") },
      { find: "@tauri-apps/plugin-updater", replacement: shim("updater.ts") },
    ],
  },
  build: {
    outDir: "dist",
    chunkSizeWarningLimit: 6000,
  },
});
