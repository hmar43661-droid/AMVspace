"""AMVspace online engine: answers the UI's `invoke` calls over HTTP (runs on Colab).
Based on AMVerge (GPL-3.0). Scene detection is done by the AMVerge-CLI (`amverge backend`)."""
import os, sys, re, json, time, uuid, shutil, hashlib, asyncio, threading, subprocess, glob
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.staticfiles import StaticFiles

DATA = Path(os.environ.get("AMV_DATA", "/content/amv"))
STORAGE = DATA / "storage"
EPISODES = STORAGE / "episodes_storage"
CACHE = DATA / "cache"
UPLOADS = DATA / "uploads"
EXPORTS = DATA / "exports"
UI = DATA / "ui"
for d in (EPISODES, CACHE, UPLOADS, EXPORTS, UI):
    d.mkdir(parents=True, exist_ok=True)

app = FastAPI()
LOOP = None
CLIENTS = set()
PROCS = {}  # episode id -> subprocess
HANDLERS = {}


@app.get("/health")
def health():
    return {"ok": True}


# ---------------- events (SSE) ----------------
@app.on_event("startup")
async def _startup():
    global LOOP
    LOOP = asyncio.get_running_loop()


def emit(event, payload=None):
    msg = json.dumps({"event": event, "payload": payload})
    if LOOP is not None:
        for q in list(CLIENTS):
            LOOP.call_soon_threadsafe(q.put_nowait, msg)


def log(msg, level="log"):
    print(msg, flush=True)
    emit("console_log", {"source": "python", "level": level, "message": str(msg)[:2000]})


@app.get("/events")
async def events():
    q = asyncio.Queue()
    CLIENTS.add(q)

    async def gen():
        try:
            yield "retry: 2000\n\n"
            while True:
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {msg}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
        finally:
            CLIENTS.discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------- files, uploads ----------------
def safe_path(p):
    rp = Path(p).resolve()
    if not (rp == DATA or DATA in rp.parents):
        raise HTTPException(403, "outside data dir")
    return rp


@app.get("/f/{p:path}")
def serve_file(p: str):
    rp = safe_path("/" + p)
    if not rp.is_file():
        raise HTTPException(404, "not found")
    return FileResponse(rp)


@app.get("/d/{p:path}")
def download_file(p: str):
    rp = safe_path("/" + p)
    if not rp.is_file():
        raise HTTPException(404, "not found")
    return FileResponse(rp, filename=rp.name)


@app.post("/upload/{uid}/done")
def upload_done(uid: str, name: str):
    d = UPLOADS / re.sub(r"[^A-Za-z0-9_-]", "", uid)
    parts = sorted(d.glob("*.part"))
    if not parts:
        raise HTTPException(400, "no parts")
    safe = re.sub(r"[^\w.\- ()]", "_", name) or "video.mp4"
    out = d / safe
    with open(out, "wb") as w:
        for p in parts:
            with open(p, "rb") as r:
                shutil.copyfileobj(r, w)
            p.unlink()
    return {"path": str(out)}


@app.post("/upload/{uid}/{n}")
async def upload_part(uid: str, n: int, request: Request):
    d = UPLOADS / re.sub(r"[^A-Za-z0-9_-]", "", uid)
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{n:06d}.part").write_bytes(await request.body())
    return {"ok": True}


# ---------------- ffmpeg helpers ----------------
def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def probe_streams(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "stream=index,codec_type,codec_name:stream_tags=language,title",
             "-of", "json", str(path)])
    try:
        return json.loads(r.stdout).get("streams", [])
    except Exception:
        return []


def video_codec(path):
    for s in probe_streams(path):
        if s.get("codec_type") == "video":
            return (s.get("codec_name") or "").lower()
    return None


def cache_key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def sanitize_id(x):
    x = (x or "").strip()
    if not x or len(x) > 96 or not re.fullmatch(r"[A-Za-z0-9_-]+", x):
        raise ValueError("invalid episode id")
    return x


def H(name):
    def deco(fn):
        HANDLERS[name] = fn
        return fn
    return deco


# ---------------- storage / simple commands ----------------
@H("get_default_episodes_dir")
def _(a):
    return str(EPISODES)


@H("path_exists")
def _(a):
    try:
        return safe_path(a.get("path", "")).exists()
    except Exception:
        return False


@H("reveal_in_file_manager")
def _(a):
    return None


@H("delete_episode_cache")
def _(a):
    try:
        shutil.rmtree(EPISODES / sanitize_id(a.get("episodeCacheId")), ignore_errors=True)
    except Exception:
        pass
    return None


@H("clear_episode_panel_cache")
def _(a):
    return None


@H("detect_pc_specs")
def _(a):
    return "AMVspace online engine (Google Colab)"


@H("ai_env_status")
def _(a):
    gpu = False
    try:
        import torch
        gpu = bool(torch.cuda.is_available())
    except Exception:
        pass
    return {"envReady": True, "uvAvailable": True,
            "packs": {"ml": True, "depth": True, "upscale": True, "scout": True},
            "torchVariant": "cuda" if gpu else "cpu", "torchVersion": None, "envCliVersion": None,
            "bundledCliVersion": None, "gpuAvailable": gpu, "gpuProbe": "found" if gpu else "none",
            "gpuDecodeSupported": False, "gpuDecodeInstalled": False, "envPythonVersion": None,
            "statusError": None}


@H("list_models")
def _(a):
    return {"depth": [], "upscale": []}


@H("lookup_scene_webp_cache_batch")
def _(a):
    return {"items": []}


@H("generate_scene_webp_batch")
def _(a):
    return {"items": []}


# ---------------- scene detection (AMVerge-CLI) ----------------
def write_manifest(out_dir, video, eid, method, imp, payload):
    scenes = payload.get("scenes", []) if isinstance(payload, dict) else []
    name = Path(video).name
    clips = []
    for i, s in enumerate(scenes):
        st = float(s.get("start_sec") or 0.0)
        clips.append({
            "scene_index": s.get("scene_index", i), "start_sec": st, "end_sec": float(s.get("end_sec") or st),
            "path": video, "thumbnail": s.get("thumbnail") or "", "thumbnail_ready": s.get("thumbnail_ready", True),
            "original_file": name, "original_path": video, "clip_path": s.get("clip_path"),
            "clip_mode": s.get("clip_mode") or "",
        })
    man = {"schemaVersion": "1.0.0", "manifestId": str(uuid.uuid4()), "createdAtUnix": int(time.time()),
           "source": {"videoPath": video, "episodeCacheId": eid, "outputDir": str(out_dir),
                      "sceneDetectionMethod": method, "importMethod": imp},
           "summary": {"sceneCount": len(scenes), "initialClipCount": len(clips)},
           "initialClips": clips, "scenes": scenes, "backendPayload": payload}
    tmp = Path(out_dir) / "manifest.json.tmp"
    tmp.write_text(json.dumps(man))
    tmp.replace(Path(out_dir) / "manifest.json")


@H("detect_scenes")
def _(a):
    video = a["videoPath"]
    eid = a.get("episodeCacheId")
    method = a.get("sceneDetectionMethod") or "transnetv2_gpu"
    imp = a.get("importMethod") or "video_files"
    out_dir = EPISODES / sanitize_id(eid) if eid else EPISODES
    out_dir.mkdir(parents=True, exist_ok=True)
    for f in out_dir.iterdir():
        if f.is_file():
            f.unlink()
    exe = shutil.which("amverge")
    cmd = ([exe] if exe else [sys.executable, "-m", "amverge"]) + ["backend", video, str(out_dir), method, imp]
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
               AMVERGE_CONFIG_DIR=str(DATA / "config"), HF_HOME=str(DATA / "hf"))
    log(f"SCENE|start video={Path(video).name} method={method}")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    PROCS[eid] = p
    err_acc = []

    def read_err():
        for line in p.stderr:
            line = line.rstrip("\n")
            err_acc.append(line)
            if line.startswith("PROGRESS|"):
                parts = line.split("|", 2)
                try:
                    emit("scene_progress", {"percent": int(parts[1].strip()), "message": parts[2] if len(parts) > 2 else ""})
                except Exception:
                    pass
            elif line.startswith("INITIAL_CLIPS_READY|"):
                emit("initial_clips_ready", {"clips_json": line.split("|", 1)[1], "episode_cache_id": eid})
            elif line.strip() == "PHASE1_COMPLETE":
                emit("phase1_complete", {"episode_cache_id": eid})
            elif line.startswith("REENCODE_PROGRESS|"):
                try:
                    _, d, t = line.split("|")
                    emit("reencode_progress", {"done": int(d), "total": int(t), "episode_cache_id": eid})
                except Exception:
                    pass
            elif line.startswith("THUMBNAIL_READY|"):
                try:
                    emit("thumbnail_ready", {"position": int(line.split("|")[1]), "episode_cache_id": eid})
                except Exception:
                    pass
            elif line.startswith("CLIP_READY|"):
                parts = line[len("CLIP_READY|"):].split("|", 2)
                if len(parts) == 3:
                    try:
                        emit("clip_ready", {"scene_index": int(parts[0]), "clip_path": parts[1].strip() or None,
                                            "clip_mode": parts[2].strip(), "episode_cache_id": eid})
                    except Exception:
                        pass
            elif line.startswith("PAIR_RESULT|"):
                parts = line[len("PAIR_RESULT|"):].split("|", 2)
                if len(parts) == 3:
                    try:
                        emit("pair_result", {"pos_a": int(parts[0]), "pos_b": int(parts[1]), "should_merge": parts[2].strip() == "1"})
                    except Exception:
                        pass
            elif line.strip() == "PROCESSING_COMPLETE":
                emit("processing_complete", None)
            elif line.strip():
                emit("console_log", {"source": "python", "level": "log", "message": line[:2000]})

    t = threading.Thread(target=read_err, daemon=True)
    t.start()
    stdout = p.stdout.read()
    p.wait()
    t.join(timeout=5)
    PROCS.pop(eid, None)
    if p.returncode != 0:
        raise RuntimeError("\n".join(err_acc[-25:]) or f"amverge exited with {p.returncode}")
    try:
        payload = json.loads(stdout)
    except Exception as e:
        raise RuntimeError(f"Backend output is not valid JSON: {e}")
    write_manifest(out_dir, video, eid, method, imp, payload)
    return stdout


@H("abort_detect_scenes")
def _(a):
    eid = a.get("episodeCacheId")
    for k in ([eid] if eid in PROCS else list(PROCS)):
        p = PROCS.pop(k, None)
        if p:
            try:
                subprocess.run(["pkill", "-TERM", "-P", str(p.pid)])
                p.terminate()
            except Exception:
                pass
    return None


@H("load_episode_manifest")
def _(a):
    mp = EPISODES / sanitize_id(a.get("episodeCacheId")) / "manifest.json"
    if not mp.exists():
        raise FileNotFoundError(f"Failed to read manifest '{mp}'")
    return mp.read_text()


# ---------------- playback ----------------
@H("check_video_codec")
def _(a):
    path = a.get("videoPath", "")
    c = video_codec(path)
    ext = Path(path).suffix.lower()
    return {"hevc": c in ("hevc", "h265"),
            "browserPlayable": c in ("h264", "vp8", "vp9", "av1") and ext in (".mp4", ".m4v", ".mov", ".webm")}


@H("get_audio_streams")
def _(a):
    out = []
    n = 0
    for s in probe_streams(a.get("videoPath", "")):
        if s.get("codec_type") == "audio":
            tags = s.get("tags") or {}
            out.append({"audioStreamIndex": n, "language": tags.get("language", ""), "title": tags.get("title", ""),
                        "codec": s.get("codec_name", "")})
            n += 1
    return out


def transcode_preview(src, dst, height, crf, start=None, end=None, audio_idx=None):
    cmd = ["ffmpeg", "-y", "-v", "error"]
    if start is not None:
        cmd += ["-ss", str(start), "-to", str(end)]
    cmd += ["-i", str(src), "-map", "0:v:0", "-map", f"0:a:{audio_idx}?" if audio_idx is not None else "0:a:0?",
            "-vf", f"scale=-2:{int(height)}", "-c:v", "libx264", "-preset", "ultrafast", "-crf", str(int(crf)),
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst)]
    r = run(cmd)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-400:])


@H("ensure_preview_proxy")
def _(a):
    src = a["clipPath"]
    audio = a.get("audioStreamIndex")
    if not a.get("transcodeVideo") and audio is None:
        return src
    h = a.get("previewHeight") or 480
    crf = a.get("previewCrf") or 28
    key = cache_key(src, os.path.getmtime(src), h, crf, audio)
    dst = CACHE / f"proxy_{key}.mp4"
    if not dst.exists():
        transcode_preview(src, dst, h, crf, audio_idx=audio)
    return str(dst)


@H("ensure_scene_range_preview")
def _(a):
    src = a["videoPath"]
    s, e = float(a["startSec"]), float(a["endSec"])
    h = a.get("previewHeight") or 480
    crf = a.get("previewCrf") or 28
    key = cache_key(src, os.path.getmtime(src), s, e, h, crf)
    dst = CACHE / f"range_{key}.mp4"
    if not dst.exists():
        transcode_preview(src, dst, h, crf, start=s, end=e)
    return str(dst)


# ---------------- export ----------------
@H("probe_export_source_streams")
def _(a):
    streams = probe_streams(a.get("videoPath", ""))
    return {"videoCodec": next((s.get("codec_name") for s in streams if s.get("codec_type") == "video"), None),
            "audioCodecs": [s.get("codec_name") for s in streams if s.get("codec_type") == "audio"]}


@H("create_export_staging_dir")
def _(a):
    d = EXPORTS / f"staging_{uuid.uuid4().hex[:8]}"
    d.mkdir(parents=True, exist_ok=True)
    return str(d)


@H("delete_export_staging_dir")
def _(a):
    try:
        shutil.rmtree(safe_path(a.get("dir") or a.get("path") or ""), ignore_errors=True)
    except Exception:
        pass
    return None


@H("unique_export_base_name")
def _(a):
    d = Path(a.get("dir") or EXPORTS)
    base = a.get("base") or "export"
    ext = a.get("extension") or "mp4"
    cand, n = base, 1
    while (d / f"{cand}.{ext}").exists():
        n += 1
        cand = f"{base}_{n}"
    return cand


def cut_one(spec, dst, reencode=True):
    src = spec["input"]
    s, e = spec.get("start_sec"), spec.get("end_sec")
    if s is None or e is None:
        shutil.copyfile(src, dst)
        return
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", str(s), "-to", str(e), "-i", str(src)]
    cmd += (["-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k"]
            if reencode else ["-c", "copy"])
    r = run(cmd + [str(dst)])
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-400:])


@H("export_clips")
def _(a):
    specs = [{"input": c} if isinstance(c, str) else c for c in (a.get("clips") or [])]
    if not specs:
        raise ValueError("no clips to export")
    save = Path(a["savePath"])
    save.parent.mkdir(parents=True, exist_ok=True)
    ext = save.suffix or ".mp4"
    tmp = EXPORTS / f"job_{uuid.uuid4().hex[:8]}"
    tmp.mkdir(parents=True, exist_ok=True)
    produced = []
    try:
        if a.get("mergeEnabled") and len(specs) > 1:
            parts = []
            for i, sp in enumerate(specs):
                p = tmp / f"p{i:04d}.mp4"
                cut_one(sp, p, reencode=True)
                parts.append(p)
            lst = tmp / "list.txt"
            lst.write_text("".join(f"file '{p}'\n" for p in parts))
            r = run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(save)])
            if r.returncode != 0:
                raise RuntimeError(r.stderr[-400:])
            produced.append(str(save))
        else:
            for i, sp in enumerate(specs):
                name = save.name
                if "####" in name:
                    num = sp.get("scene_index", i + 1)
                    name = name.replace("####", f"{int(num):04d}")
                elif len(specs) > 1:
                    name = f"{save.stem}_{i + 1:04d}{ext}"
                dst = save.parent / name
                cut_one(sp, dst, reencode=True)
                produced.append(str(dst))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return produced


# ---------------- RPC entry ----------------
@app.post("/rpc/{cmd}")
async def rpc(cmd: str, request: Request):
    try:
        args = await request.json()
    except Exception:
        args = {}
    fn = HANDLERS.get(cmd)
    if fn is None:
        print(f"[unsupported] {cmd}", flush=True)
        return JSONResponse(None)
    try:
        res = await asyncio.get_running_loop().run_in_executor(None, lambda: fn(args or {}))
        return JSONResponse(res)
    except Exception as e:
        print(f"[error] {cmd}: {e}", flush=True)
        return JSONResponse({"error": str(e)}, status_code=500)


if UI.exists():
    app.mount("/", StaticFiles(directory=str(UI), html=True), name="ui")
