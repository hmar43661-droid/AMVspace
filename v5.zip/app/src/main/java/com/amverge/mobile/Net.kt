package com.amverge.mobile

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object Net {
    @Volatile var base: String = ""
    fun ready() = base.isNotBlank()
    fun clean(u: String) = u.trim().trimEnd('/')

    private fun open(path: String, method: String): HttpURLConnection {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 180_000
        c.setRequestProperty("User-Agent", "AMVspace/1.0")
        return c
    }

    private fun readBody(c: HttpURLConnection): String {
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw IOException("HTTP $code ${txt.take(200)}")
        return txt
    }

    fun getJson(path: String): JSONObject {
        val c = open(path, "GET")
        try {
            return JSONObject(readBody(c))
        } finally {
            c.disconnect()
        }
    }

    fun postJson(path: String, body: JSONObject): JSONObject {
        val c = open(path, "POST")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            return JSONObject(readBody(c))
        } finally {
            c.disconnect()
        }
    }

    private fun fill(ins: InputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) {
            val n = ins.read(buf, off, buf.size - off)
            if (n < 0) break
            off += n
        }
        return off
    }

    // رفع على دفعات 24MB (حد Cloudflare هو 100MB للطلب الواحد)
    fun upload(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): String {
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        val total = ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            val buf = ByteArray(24 * 1024 * 1024)
            var n = 0
            var sent = 0L
            while (true) {
                val len = fill(ins, buf)
                if (len <= 0) break
                var tries = 0
                while (true) {
                    try {
                        val c = open("/upload/$id/$n", "POST")
                        try {
                            c.doOutput = true
                            c.setFixedLengthStreamingMode(len)
                            c.outputStream.use { it.write(buf, 0, len) }
                            readBody(c)
                        } finally {
                            c.disconnect()
                        }
                        break
                    } catch (e: IOException) {
                        tries++
                        if (tries >= 3) throw e
                    }
                }
                n++
                sent += len
                if (total > 0) onProgress(sent.toFloat() / total)
            }
        }
        return id
    }

    fun download(path: String, out: File, onProgress: (Float) -> Unit) {
        val c = open(path, "GET")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            c.inputStream.use { i ->
                out.outputStream().use { o ->
                    val b = ByteArray(256 * 1024)
                    var done = 0L
                    while (true) {
                        val n = i.read(b)
                        if (n < 0) break
                        o.write(b, 0, n)
                        done += n
                        if (total > 0) onProgress(done.toFloat() / total)
                    }
                }
            }
        } finally {
            c.disconnect()
        }
    }

    fun saveVideo(ctx: Context, f: File, name: String): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AMVspace")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("تعذر إنشاء الملف")
        try {
            resolver.openOutputStream(out)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(out, values, null, null)
        } catch (e: Exception) {
            resolver.delete(out, null, null)
            throw e
        } finally {
            f.delete()
        }
        return out
    }

    // رفع -> معالجة على GPU -> تنزيل -> حفظ في Movies/AMVspace
    suspend fun runJob(
        ctx: Context, kind: String, uri: Uri, name: String, params: JSONObject,
        report: (String, Float, String) -> Unit
    ): Uri = withContext(Dispatchers.IO) {
        report("upload", 0f, "رفع الفيديو إلى السيرفر")
        val up = upload(ctx, uri) { report("upload", it, "رفع الفيديو إلى السيرفر") }
        val jid = postJson("/jobs/$kind", JSONObject().put("upload", up).put("name", name).put("params", params))
            .getString("job")
        try {
            while (true) {
                ensureActive()
                val st = getJson("/jobs/$jid")
                val s = st.optString("status")
                report(s, st.optDouble("progress", 0.0).toFloat(), st.optString("message"))
                if (s == "error") throw IOException(st.optString("message", "فشلت المعالجة"))
                if (s == "done") break
                delay(1000)
            }
            report("download", 0f, "تنزيل النتيجة")
            val f = File(ctx.cacheDir, "res_$jid.mp4")
            download("/jobs/$jid/result", f) { report("download", it, "تنزيل النتيجة") }
            saveVideo(ctx, f, "AMVspace_${kind}_$jid")
        } catch (e: CancellationException) {
            try {
                postJson("/jobs/$jid/cancel", JSONObject())
            } catch (x: Exception) {
            }
            throw e
        }
    }
}
