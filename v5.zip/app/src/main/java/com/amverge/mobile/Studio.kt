package com.amverge.mobile

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

const val COLAB_URL =
    "https://colab.research.google.com/github/hmar43661-droid/AMVspace/blob/main/AMVspace_backend.ipynb"

class Opt(val key: String, val label: String, val choices: List<Pair<String, String>>)
class Tool(val id: String, val icon: String, val title: String, val sub: String, val opts: List<Opt>)

val TOOLS = listOf(
    Tool(
        "upscale", "⚡", "تكبير 2× / 4×", "Real-ESRGAN للأنمي و AMV",
        listOf(Opt("scale", "مقدار التكبير", listOf("2" to "2×", "4" to "4×")))
    ),
    Tool(
        "rife", "🎞", "RIFE 60/120 FPS", "استيفاء إطارات سلس وحركة بطيئة",
        listOf(
            Opt(
                "model", "نموذج RIFE",
                listOf(
                    "RIFE_v4.6" to "v4.6 (أنمي)",
                    "RIFE_v4.25" to "v4.25 (حركة سريعة)",
                    "RIFE_v4.22.lite" to "v4.22 Lite (سريع جداً)",
                    "RIFE_v4.22" to "v4.22 (واقعي)",
                    "RIFE_v4.26.heavy" to "v4.26 Heavy (أعلى جودة)"
                )
            ),
            Opt("mult", "مضاعف الإطارات", listOf("2" to "2×", "4" to "4×", "8" to "8×")),
            Opt("mode", "الوضع", listOf("fps" to "FPS أعلى (مع الصوت)", "slow" to "حركة بطيئة (بدون صوت)"))
        )
    ),
    Tool(
        "depth", "🌊", "خريطة العمق", "Depth Anything V2",
        listOf(Opt("style", "الألوان", listOf("gray" to "رمادي", "inferno" to "حراري", "turbo" to "ملوّن")))
    )
)

@Composable
fun Hide(show: Boolean, content: @Composable () -> Unit) {
    Box(if (show) Modifier.fillMaxSize() else Modifier.size(0.dp).clipToBounds()) { content() }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var connected by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        Net.base = ctx.getSharedPreferences("amv", Context.MODE_PRIVATE).getString("base", "") ?: ""
        if (Net.ready()) {
            connected = try {
                withContext(Dispatchers.IO) { Net.getJson("/health") }.optBoolean("ok")
            } catch (e: Exception) {
                false
            }
        }
    }
    val itemColors = NavigationBarItemDefaults.colors(
        indicatorColor = Color(0xFF3B1A66), selectedTextColor = Purple, unselectedTextColor = Color.Gray
    )
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0716)) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("🎬") }, label = { Text("المشاهد") }, colors = itemColors)
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("✨") }, label = { Text("الاستوديو") }, colors = itemColors)
                NavigationBarItem(tab == 2, { tab = 2 }, { Text("🔗") }, label = { Text("الاتصال") }, colors = itemColors)
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Hide(tab == 0) { App() }
            Hide(tab == 1) { Studio(connected) { tab = 2 } }
            Hide(tab == 2) { Connect(connected) { connected = it } }
        }
    }
}

@Composable
fun Studio(connected: Boolean, goConnect: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tool by remember { mutableStateOf<Tool?>(null) }
    var video by remember { mutableStateOf<Uri?>(null) }
    var vname by remember { mutableStateOf("") }
    val sel = remember { mutableStateMapOf<String, String>() }
    var phase by remember { mutableStateOf("") }
    var prog by remember { mutableStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Pair<String, Uri>>>(emptyList()) }
    var play by remember { mutableStateOf<Uri?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            video = u
            vname = displayName(ctx, u)
        }
    }
    val working = phase == "upload" || phase == "queued" || phase == "running" || phase == "download"

    fun start(t: Tool) {
        val v = video ?: return
        val p = JSONObject()
        t.opts.forEach { p.put(it.key, sel[it.key] ?: it.choices[0].first) }
        phase = "upload"
        prog = 0f
        msg = ""
        job = scope.launch {
            try {
                val out = Net.runJob(ctx, t.id, v, vname, p) { ph, pr, m ->
                    phase = ph
                    prog = pr
                    msg = m
                }
                results = listOf("${t.title} • $vname" to out) + results
                phase = "done"
                prog = 1f
                msg = "تم الحفظ في Movies/AMVspace"
            } catch (e: CancellationException) {
                phase = ""
                msg = ""
                throw e
            } catch (e: Exception) {
                phase = "error"
                msg = e.message ?: "خطأ"
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Studio", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.weight(1f))
                Text(
                    if (connected) "● متصل" else "● غير متصل",
                    color = if (connected) Color(0xFF4ADE80) else Color(0xFFF87171),
                    modifier = Modifier.clickable(onClick = goConnect)
                )
            }
        }
        val t = tool
        if (t == null) {
            items(TOOLS) { tl ->
                Row(
                    Modifier.fillMaxWidth().clip4().background(CardBg)
                        .clickable { tool = tl; sel.clear(); phase = ""; msg = "" }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(tl.icon, fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(tl.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(tl.sub, color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
            if (!connected) item { Text("اربط السيرفر من تبويب الاتصال أولاً لتفعيل أدوات الذكاء الاصطناعي.", color = Purple) }
        } else {
            item {
                Column {
                    Text("← رجوع", Modifier.clickable(enabled = !working) { tool = null }.padding(vertical = 6.dp), color = Purple)
                    Text("${t.icon} ${t.title}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Column {
                    Button(onClick = { pick.launch(arrayOf("video/*")) }, enabled = !working) {
                        Text(if (video == null) "اختيار فيديو من المعرض" else "تغيير الفيديو")
                    }
                    if (vname.isNotEmpty()) Text(vname, Modifier.padding(top = 6.dp), color = Color.White)
                }
            }
            items(t.opts) { o ->
                Column {
                    Text(o.label, color = Purple, fontWeight = FontWeight.Bold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        o.choices.forEach { (k, l) ->
                            Chip(l, (sel[o.key] ?: o.choices[0].first) == k) { sel[o.key] = k }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { start(t) }, enabled = connected && video != null && !working,
                        modifier = Modifier.weight(1f)
                    ) { Text("ابدأ المعالجة") }
                    if (working) {
                        OutlinedButton(onClick = { job?.cancel() }, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                    }
                }
            }
            if (phase.isNotEmpty()) item {
                val label = when (phase) {
                    "upload" -> "رفع إلى السيرفر"
                    "queued" -> "في الانتظار"
                    "running" -> "معالجة على GPU"
                    "download" -> "تنزيل النتيجة"
                    "done" -> "تم ✓"
                    else -> "خطأ"
                }
                Column(Modifier.fillMaxWidth().clip4().background(CardBg).padding(14.dp)) {
                    Text("$label  ${(prog * 100).toInt()}%", color = Purple, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(
                        progress = { prog.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        color = Purple, trackColor = Color(0xFF2A1A44)
                    )
                    Text(msg, color = if (phase == "error") Color(0xFFF87171) else Color.White, fontSize = 13.sp)
                }
            }
        }
        if (results.isNotEmpty()) {
            item { Text("النتائج", color = Purple, fontWeight = FontWeight.Bold) }
            items(results) { (name, uri) ->
                Row(Modifier.fillMaxWidth().clip4().background(CardBg).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("▶", Modifier.clickable { play = uri }.padding(end = 12.dp), color = Color.White, fontSize = 22.sp)
                    Text(name, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
                    Text("مشاركة", Modifier.clickable { shareVideo(ctx, uri) }.padding(start = 12.dp), color = Purple)
                }
            }
        }
    }
    val pl = play
    if (pl != null) PreviewDialog(pl, Scene(0, 86_400_000_000L)) { play = null }
}

fun Modifier.clip4(): Modifier = this.clip(RoundedCornerShape(14.dp))

fun shareVideo(ctx: Context, u: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, u)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun Connect(connected: Boolean, onResult: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Net.base) }
    var info by remember { mutableStateOf("") }
    fun test() {
        Net.base = Net.clean(url)
        ctx.getSharedPreferences("amv", Context.MODE_PRIVATE).edit().putString("base", Net.base).apply()
        info = "جاري الاتصال..."
        scope.launch {
            try {
                val h = withContext(Dispatchers.IO) { Net.getJson("/health") }
                onResult(h.optBoolean("ok"))
                info = "متصل ✓  GPU: ${h.optString("gpu")}"
            } catch (e: Exception) {
                onResult(false)
                info = "فشل الاتصال: ${e.message}"
            }
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الاتصال بالسيرفر", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        item {
            Text(
                if (connected) "● متصل" else "● غير متصل",
                color = if (connected) Color(0xFF4ADE80) else Color(0xFFF87171)
            )
        }
        item {
            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true,
                label = { Text("رابط السيرفر (trycloudflare.com)") }, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.getItemAt(0)?.text?.toString()
                    if (t != null) url = t.trim()
                }, modifier = Modifier.weight(1f)) { Text("لصق") }
                Button(onClick = { test() }, modifier = Modifier.weight(1f)) { Text("اتصال / اختبار") }
            }
        }
        if (info.isNotEmpty()) item { Text(info, color = Purple) }
        item {
            Button(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(COLAB_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, modifier = Modifier.fillMaxWidth()) { Text("فتح Colab (سيرفر الذكاء الاصطناعي)") }
        }
        item {
            Text(
                "1) اضغط «فتح Colab».\n" +
                    "2) من Runtime ← Change runtime type اختر T4 GPU.\n" +
                    "3) اضغط Runtime ← Run all وانتظر ظهور رابط https://…trycloudflare.com\n" +
                    "4) انسخ الرابط، ارجع هنا واضغط «لصق» ثم «اتصال».\n\n" +
                    "السيرفر يعمل على GPU مجاني من Google، ويتوقف بعد ساعات فأعد التشغيل عند الحاجة.",
                color = Color.White, fontSize = 14.sp
            )
        }
    }
}
