package com.amverge.mobile

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.abs

// ---------- النماذج ----------

data class Scene(val start: Long, val end: Long)
class Analysis(val keyframes: List<Long>, val sigs: List<IntArray>, val durationUs: Long)
class Episode(val uri: Uri, val name: String, val analysis: Analysis, val detailed: Boolean)
class Item(val ep: Int, val idx: Int, val scene: Scene) { val id: String get() = "$ep:$idx" }

// ---------- التحليل (الإطارات المفتاحية + بصمة بصرية لكل إطار) ----------

fun signature(b: Bitmap?): IntArray {
    val out = IntArray(144)
    if (b == null) return out
    val s = Bitmap.createScaledBitmap(b, 16, 9, true)
    val px = IntArray(144)
    s.getPixels(px, 0, 16, 0, 0, 16, 9)
    for (i in 0 until 144) {
        val c = px[i]
        out[i] = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
    }
    return out
}

fun diff(a: IntArray, b: IntArray): Float {
    var s = 0L
    for (i in a.indices) s += abs(a[i] - b[i])
    return s / (a.size * 255f) * 100f
}

fun analyze(ctx: Context, uri: Uri, detailed: Boolean, onProgress: (Float) -> Unit): Analysis {
    val keys = ArrayList<Long>()
    var dur = 0L
    if (!detailed) {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    track = i
                    if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION)
                    break
                }
            }
            require(track >= 0) { "لا يوجد مسار فيديو" }
            ex.selectTrack(track)
            while (true) {
                val t = ex.sampleTime
                if (t < 0) break
                if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) keys.add(t)
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        if (keys.isEmpty()) keys.add(0L)
        if (dur <= 0) dur = keys.last() + 1_000_000
    }
    val sigs = ArrayList<IntArray>()
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        if (detailed) {
            dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
            require(dur > 0) { "تعذر قراءة مدة الفيديو" }
            var t = 0L
            while (t < dur) {
                keys.add(t)
                t += 500_000
            }
        }
        val opt = if (detailed) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC
        for ((i, k) in keys.withIndex()) {
            val bmp = try {
                r.getScaledFrameAtTime(k, opt, 32, 18)
            } catch (e: Exception) {
                null
            }
            sigs.add(signature(bmp))
            onProgress((i + 1f) / keys.size)
        }
    } finally {
        r.release()
    }
    return Analysis(keys, sigs, dur)
}

// دمج ذكي: لا نبدأ مشهداً جديداً إلا إذا طال الوقت وتغيّرت الصورة فعلاً
fun buildScenes(a: Analysis, minSec: Float, thr: Float): List<Scene> {
    val minUs = (minSec * 1_000_000).toLong()
    val starts = ArrayList<Long>()
    for (i in a.keyframes.indices) {
        val k = a.keyframes[i]
        if (starts.isEmpty()) {
            starts.add(k)
        } else if (k - starts.last() >= minUs && diff(a.sigs[i], a.sigs[i - 1]) >= thr) {
            starts.add(k)
        }
    }
    return starts.mapIndexed { i, s ->
        Scene(s, if (i + 1 < starts.size) starts[i + 1] else a.durationUs)
    }
}

// ---------- التصدير / الدمج بدون إعادة ترميز ----------

fun exportScenes(ctx: Context, src: Uri, list: List<Scene>, name: String) {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AMVspace")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("تعذر إنشاء الملف")
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, src, null)
        resolver.openFileDescriptor(out, "w")!!.use { pfd ->
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_ROTATION)) {
                            m.setOrientationHint(f.getInteger(MediaFormat.KEY_ROTATION))
                        }
                        map[i] = m.addTrack(f)
                        ex.selectTrack(i)
                    }
                }
                m.start()
                val buf = ByteBuffer.allocate(8 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                var offset = 0L
                for (sc in list) {
                    ex.seekTo(sc.start, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                    while (true) {
                        val t = ex.sampleTime
                        if (t < 0 || t >= sc.end) break
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                            MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        info.set(0, size, maxOf(0L, t - sc.start) + offset, flags)
                        map[ex.sampleTrackIndex]?.let { m.writeSampleData(it, buf, info) }
                        ex.advance()
                    }
                    offset += sc.end - sc.start
                }
                m.stop()
            } finally {
                m.release()
            }
        }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(out, values, null, null)
    } catch (e: Exception) {
        resolver.delete(out, null, null)
        throw e
    } finally {
        ex.release()
    }
}

// ---------- المحرك الدقيق (Media3): قص إطار بإطار + دمج + تكبير ----------

suspend fun runTransformer(ctx: Context, src: Uri, list: List<Scene>, path: String, height: Int) {
    suspendCancellableCoroutine<Unit> { cont ->
        val fx = if (height > 0) listOf<Effect>(Presentation.createForHeight(height)) else emptyList()
        val items = list.map { sc ->
            EditedMediaItem.Builder(
                MediaItem.Builder().setUri(src).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(sc.start / 1000)
                        .setEndPositionMs(sc.end / 1000)
                        .build()
                ).build()
            ).setEffects(Effects(emptyList(), fx)).build()
        }
        val comp = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val tb = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .experimentalSetTrimOptimizationEnabled(true)
        if (height > 0) {
            val bitrate = if (height >= 2160) 40_000_000 else if (height >= 1440) 24_000_000 else 14_000_000
            tb.setEncoderFactory(
                DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                    .build()
            )
        }
        val t = tb.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                if (cont.isActive) cont.resume(Unit)
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                if (cont.isActive) cont.resumeWithException(exportException)
            }
        }).build()
        t.start(comp, path)
        cont.invokeOnCancellation { t.cancel() }
    }
}

suspend fun exportAccurate(ctx: Context, src: Uri, list: List<Scene>, name: String, height: Int) {
    val tmp = File(ctx.cacheDir, "$name.mp4")
    try {
        withContext(Dispatchers.Main) { runTransformer(ctx, src, list, tmp.absolutePath, height) }
        withContext(Dispatchers.IO) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AMVspace")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("تعذر إنشاء الملف")
            try {
                resolver.openOutputStream(out)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(out, values, null, null)
            } catch (e: Exception) {
                resolver.delete(out, null, null)
                throw e
            }
        }
    } finally {
        tmp.delete()
    }
}

// ---------- أدوات ----------

private val cache = object : LruCache<String, Bitmap>(80) {}

fun thumb(ctx: Context, uri: Uri, us: Long): Bitmap? {
    val key = "$uri#$us"
    cache.get(key)?.let { return it }
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let {
            Bitmap.createScaledBitmap(it, 320, (320f * it.height / it.width).toInt().coerceAtLeast(1), true)
        }?.also { cache.put(key, it) }
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "video"

fun fmt(us: Long): String {
    val s = us / 1_000_000
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------- الثيم: أسود + بنفسجي + أبيض ----------

private val Purple = Color(0xFFA855F7)
private val CardBg = Color(0xFF150E22)

@Composable
fun AMVTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, onPrimary = Color.White,
            background = Color.Black, onBackground = Color.White,
            surface = Color(0xFF0D0716), onSurface = Color.White,
            surfaceVariant = CardBg, outline = Color(0xFF6D3FB0)
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AMVTheme {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

// ---------- الشاشة الرئيسية (Scene Scout) ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var minSec by remember { mutableStateOf(3f) }
    var thr by remember { mutableStateOf(6f) }
    var filter by remember { mutableStateOf(-1) }
    var prefix by remember { mutableStateOf("AMVspace") }
    var detailed by remember { mutableStateOf(false) }
    var res by remember { mutableStateOf(0) }
    var precise by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("أضف حلقات أو فيديوهات للبدء") }
    var progress by remember { mutableStateOf(-1f) }
    var busy by remember { mutableStateOf(false) }
    var startedAt by remember { mutableStateOf(0L) }
    var nowMs by remember { mutableStateOf(0L) }
    var preview by remember { mutableStateOf<Item?>(null) }
    val selected = remember { mutableStateListOf<String>() }

    val list = remember(episodes, minSec, thr, filter) {
        episodes.flatMapIndexed { e, ep ->
            if (filter >= 0 && filter != e) emptyList()
            else buildScenes(ep.analysis, minSec, thr).mapIndexed { i, s -> Item(e, i, s) }
        }
    }
    LaunchedEffect(minSec, thr, episodes) { selected.clear() }
    LaunchedEffect(busy) {
        while (busy) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            startedAt = System.currentTimeMillis()
            scope.launch {
                try {
                    for ((n, u) in uris.withIndex()) {
                        val nm = displayName(ctx, u)
                        status = "كشف المشاهد ${n + 1}/${uris.size}: $nm"
                        progress = 0f
                        val a = withContext(Dispatchers.IO) { analyze(ctx, u, detailed) { p -> progress = p } }
                        episodes = episodes + Episode(u, nm, a, detailed)
                    }
                    status = "تم. اضغط ▶ للمعاينة وحدّد المشاهد"
                } catch (e: Exception) {
                    status = "فشل التحليل: ${e.message}"
                }
                progress = -1f
                busy = false
            }
        }
    }

    fun doExport(merge: Boolean) {
        val chosen = list.filter { it.id in selected }
        if (chosen.isEmpty()) return
        val base = prefix.ifBlank { "AMVspace" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        busy = true
        startedAt = System.currentTimeMillis()
        scope.launch {
            try {
                val accurate = precise || res > 0
                suspend fun put(e: Int, sc: List<Scene>, nm: String) {
                    if (accurate || episodes[e].detailed) {
                        status = "معالجة دقيقة: $nm (قد تستغرق وقتاً)"
                        exportAccurate(ctx, episodes[e].uri, sc, nm, res)
                    } else {
                        withContext(Dispatchers.IO) { exportScenes(ctx, episodes[e].uri, sc, nm) }
                    }
                }
                if (merge) {
                    for ((e, group) in chosen.groupBy { it.ep }) {
                        put(e, group.map { it.scene }, "${base}_e${e + 1}_merged")
                    }
                } else {
                    for ((n, c) in chosen.withIndex()) {
                        progress = n.toFloat() / chosen.size
                        put(c.ep, listOf(c.scene), "${base}_e${c.ep + 1}_s${c.idx + 1}")
                    }
                }
                status = "تم! الملفات في Movies/AMVspace"
            } catch (e: Exception) {
                status = "فشل: ${e.message}"
            }
            progress = -1f
            busy = false
        }
    }

    val full: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(span = full) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("AMV", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("space", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Purple)
                    Spacer(Modifier.width(8.dp))
                    Text("Scene Scout", color = Color.Gray, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy) {
                    Text("إضافة حلقات / فيديوهات")
                }
                Row(
                    Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip("كشف سريع", !detailed) { detailed = false }
                    Chip("كشف دقيق (أبطأ)", detailed) { detailed = true }
                }
                Text(status, Modifier.padding(top = 6.dp), color = Purple)
                if (progress >= 0f) {
                    val sec = ((nowMs - startedAt) / 1000).coerceAtLeast(0)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { progress }, modifier = Modifier.fillMaxWidth(),
                        color = Purple, trackColor = Color(0xFF2A1A44)
                    )
                    val pct = (progress * 100).toInt()
                    Text("$pct%%   •   %02d:%02d".format(sec / 60, sec % 60), color = Color.White)
                }
            }
        }
        if (episodes.isNotEmpty()) {
            item(span = full) {
                Column {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = filter == -1, onClick = { filter = -1 }, label = { Text("الكل") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White)
                        )
                        episodes.forEachIndexed { i, ep ->
                            FilterChip(
                                selected = filter == i, onClick = { filter = i },
                                label = { Text(ep.name.take(18)) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("أقل طول للمشهد: ${minSec.toInt()} ثانية")
                    Slider(
                        value = minSec, onValueChange = { minSec = it }, valueRange = 0f..30f,
                        colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
                    )
                    Text("حساسية الدمج الذكي: ${thr.toInt()}%  (أعلى = دمج أكثر)")
                    Slider(
                        value = thr, onValueChange = { thr = it }, valueRange = 0f..40f,
                        colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
                    )
                    Text("المشاهد: ${list.size}   |   المحدد: ${selected.size}", color = Purple, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { selected.clear(); selected.addAll(list.map { it.id }) },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)
                        ) { Text("تحديد الكل", fontSize = 12.sp) }
                        OutlinedButton(
                            onClick = { selected.clear() },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)
                        ) { Text("إلغاء", fontSize = 12.sp) }
                        OutlinedButton(
                            onClick = { episodes = emptyList(); filter = -1 }, enabled = !busy,
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)
                        ) { Text("مسح المكتبة", fontSize = 12.sp) }
                    }
                    Text("جودة التصدير", Modifier.padding(top = 8.dp), color = Purple, fontWeight = FontWeight.Bold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Chip("الأصلية", res == 0) { res = 0 }
                        Chip("تكبير 1080p", res == 1080) { res = 1080 }
                        Chip("تكبير 1440p", res == 1440) { res = 1440 }
                        Chip("تكبير 4K", res == 2160) { res = 2160 }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        Chip("قص دقيق إطار بإطار", precise) { precise = !precise }
                    }
                    OutlinedTextField(
                        value = prefix, onValueChange = { prefix = it }, singleLine = true,
                        label = { Text("اسم ملفات التصدير") },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    )
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            enabled = !busy && selected.isNotEmpty(), onClick = { doExport(false) },
                            modifier = Modifier.weight(1f)
                        ) { Text("تصدير منفصل") }
                        Button(
                            enabled = !busy && selected.size > 1, onClick = { doExport(true) },
                            modifier = Modifier.weight(1f)
                        ) { Text("دمج في ملف") }
                    }
                }
            }
        }
        items(list, key = { it.id }) { item ->
            SceneCell(
                episodes[item.ep], item, item.id in selected,
                onPreview = { preview = item }
            ) {
                if (item.id in selected) selected.remove(item.id) else selected.add(item.id)
            }
        }
    }

    val p = preview
    if (p != null && p.ep < episodes.size) PreviewDialog(episodes[p.ep].uri, p.scene) { preview = null }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White)
    )
}

@Composable
fun SceneCell(ep: Episode, item: Item, checked: Boolean, onPreview: () -> Unit, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, ep.uri, item.scene.start) {
        value = withContext(Dispatchers.IO) { thumb(ctx, ep.uri, item.scene.start) }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(shape).background(CardBg)
            .then(if (checked) Modifier.border(2.dp, Purple, shape) else Modifier)
            .clickable(onClick = onToggle)
    ) {
        bmp?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Text(
            "▶", Modifier.align(Alignment.Center).clickable(onClick = onPreview).padding(14.dp),
            color = Color.White, fontSize = 22.sp
        )
        Text(
            fmt(item.scene.end - item.scene.start),
            Modifier.align(Alignment.BottomEnd).padding(6.dp)
                .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
            color = Color.White, fontSize = 11.sp
        )
        Text(
            "#${item.idx + 1}",
            Modifier.align(Alignment.BottomStart).padding(6.dp),
            color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold
        )
        if (checked) {
            Text(
                "✓",
                Modifier.align(Alignment.TopStart).padding(6.dp)
                    .background(Purple, CircleShape).padding(horizontal = 7.dp, vertical = 1.dp),
                color = Color.White, fontSize = 13.sp
            )
        }
    }
}

@Composable
fun PreviewDialog(uri: Uri, scene: Scene, onClose: () -> Unit) {
    val h = remember { Handler(Looper.getMainLooper()) }
    DisposableEffect(Unit) { onDispose { h.removeCallbacksAndMessages(null) } }
    val s = (scene.start / 1000).toInt()
    val e = (scene.end / 1000).toInt()
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق", color = Purple) } },
        text = {
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(220.dp),
                factory = { c ->
                    VideoView(c).also { v ->
                        v.setVideoURI(uri)
                        v.setOnPreparedListener { v.seekTo(s); v.start() }
                        h.post(object : Runnable {
                            override fun run() {
                                if (v.isPlaying && v.currentPosition >= e) v.seekTo(s)
                                h.postDelayed(this, 200)
                            }
                        })
                    }
                }
            )
        }
    )
}
